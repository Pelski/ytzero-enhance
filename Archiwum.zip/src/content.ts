import { containedMediaRect, DEFAULT_SETTINGS, embeddedPlayerModeForPage, EmbeddedPlayerMode, formatClock, isPreviewEmbedUrl, normalizeSettings, playableLiveRange, playerTimeline, resolveEmbeddedPlayerMode, youtubeVideoId } from "./core";
import { BridgeScreenshotRequest, claimScreenshotRequest, configuredPageMatches, ContentType, embeddedPlayerParameters, EnhanceConfiguration, EnhanceContext, EnhancePlayerCommand, ENHANCE_BRIDGE_EVENTS, ENHANCE_PLAYER_EVENTS, frameStepSeconds, highestQualityAtOrBelow, isContentType, MAX_COMMAND_DETAIL_LENGTH, MAX_CONTEXT_DETAIL_LENGTH, parseBridgeDetail, playerPresentationState, validateEnhanceContext, validatePlayerCommand } from "./contract";
import { EMBEDDED_CONFIGURATION_ID, PAIRED_INSTANCES_KEY, parseEmbeddedConfigurationText } from "./instances";
import { t } from "./i18n";
import { advanceOwnedPlaybackRate, chapterShortcutTarget, DEFAULT_SHORTCUT_BINDINGS, isEditableShortcutEvent, matchingShortcutAction, OwnedPlaybackRate, PARENT_OWNED_SHORTCUT_ACTIONS, shortcutAllowsRepeat, shortcutChordFromEvent, shortcutEventPayload, shortcutOperationBlocked, TemporaryBoostController, type ShortcutAction, type ShortcutBindings } from "./shortcuts";
import { addApiListener, callApi, ext, extensionContextAvailable, isFirefox, onExtensionContextInvalidated } from "./webext";

let config = normalizeSettings(DEFAULT_SETTINGS);
let remoteConfig: EnhanceConfiguration | null = null;
let bridgeContext: EnhanceContext | null = null;
let playerController: ReturnType<typeof enhanceYouTubePlayer> | null = null;
let bridgeCleanup: (() => void) | null = null;
let playerObserver: MutationObserver | null = null;
let configurationObserver: MutationObserver | null = null;
let extensionStatusObserver: MutationObserver | null = null;
let playerBootToken = 0;
let activeInstanceUrl = "";
let lastEmbeddedConfigurationText = "";
type OwnedIframeParameter = { original: string | null; applied: string };
const ownedIframeParameters = new Map<HTMLIFrameElement, Map<string, OwnedIframeParameter>>();

const SVG_NAMESPACE = "http://www.w3.org/2000/svg";
type PlayerIconShape = ["path" | "rect", Record<string, string>];
type PlayerIcon = readonly PlayerIconShape[];

const PLAYER_ICONS = {
  play: [["path", { d: "M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z" }]],
  pause: [["rect", { x: "6", y: "4", width: "4", height: "16", rx: "1" }], ["rect", { x: "14", y: "4", width: "4", height: "16", rx: "1" }]],
  volume: [["path", { d: "M11 5 6 9H2v6h4l5 4z" }], ["path", { d: "M15.5 8.5a5 5 0 0 1 0 7" }], ["path", { d: "M18 6a9 9 0 0 1 0 12" }]],
  muted: [["path", { d: "M11 5 6 9H2v6h4l5 4z" }], ["path", { d: "m22 9-6 6" }], ["path", { d: "m16 9 6 6" }]],
  captions: [["rect", { x: "3", y: "5", width: "18", height: "14", rx: "2" }], ["path", { d: "M10 10.5a2.5 2.5 0 1 0 0 3M17 10.5a2.5 2.5 0 1 0 0 3" }]],
  pip: [["rect", { x: "2", y: "3", width: "20", height: "14", rx: "2" }], ["rect", { x: "12", y: "10", width: "8", height: "5", rx: "1" }]],
  fullscreen: [["path", { d: "M8 3H5a2 2 0 0 0-2 2v3" }], ["path", { d: "M16 3h3a2 2 0 0 1 2 2v3" }], ["path", { d: "M8 21H5a2 2 0 0 1-2-2v-3" }], ["path", { d: "M16 21h3a2 2 0 0 0 2-2v-3" }]],
  minimize: [["path", { d: "M8 3v3a2 2 0 0 1-2 2H3" }], ["path", { d: "M16 3v3a2 2 0 0 0 2 2h3" }], ["path", { d: "M8 21v-3a2 2 0 0 0-2-2H3" }], ["path", { d: "M16 21v-3a2 2 0 0 1 2-2h3" }]],
} satisfies Record<string, PlayerIcon>;
const PLAYER_ICON_STATE = new WeakMap<Element, PlayerIcon>();

function setPlayerIcon(button: Element, iconDefinition: PlayerIcon) {
  if (PLAYER_ICON_STATE.get(button) === iconDefinition) return;
  const icon = document.createElementNS(SVG_NAMESPACE, "svg");
  icon.setAttribute("viewBox", "0 0 24 24");
  for (const [tag, attributes] of iconDefinition) {
    const shape = document.createElementNS(SVG_NAMESPACE, tag);
    for (const [name, value] of Object.entries(attributes)) shape.setAttribute(name, value);
    icon.append(shape);
  }
  button.replaceChildren(icon);
  PLAYER_ICON_STATE.set(button, iconDefinition);
}

void Promise.all([
  callApi<any>(ext.storage.sync, "get", DEFAULT_SETTINGS),
  callApi<any>(ext.runtime, "sendMessage", { type: "ytze-get-configuration-state" }).catch(() => ({ configuration: null })),
]).then(([stored, state]) => {
  config = normalizeSettings(stored);
  remoteConfig = state?.configuration ?? null;
  activeInstanceUrl = state?.instance?.url ?? "";
  boot();
}).catch(() => {});

addApiListener(ext?.storage?.onChanged, (changes: any, area: string) => {
  if (area !== "sync") return;
  const patch = Object.fromEntries(Object.entries(changes).map(([key, value]: any) => [key, value.newValue]));
  config = normalizeSettings({ ...config, ...patch });
  void reloadConfigurationState();
});

addApiListener(ext?.storage?.onChanged, (changes: any, area: string) => {
  if (area !== "local") return;
  if (changes[PAIRED_INSTANCES_KEY]) void reloadConfigurationState();
});

async function reloadConfigurationState() {
  const state = await callApi<any>(ext.runtime, "sendMessage", { type: "ytze-get-configuration-state" }).catch(() => ({ configuration: null }));
  remoteConfig = state?.configuration ?? null;
  activeInstanceUrl = state?.instance?.url ?? "";
  restart();
}

function restart() {
  shutdown(!pageBridgeShouldBeActive());
  boot();
}

function pageBridgeShouldBeActive() {
  return window.top === window && Boolean(config.enhancePlayer && remoteConfig?.enabled && activeInstanceUrl && configuredPageMatches(location.href, activeInstanceUrl));
}

function shutdown(restoreEmbeds = false) {
  playerBootToken++;
  if (window.top !== window && playerController) {
    void callApi(ext.runtime, "sendMessage", { type: "ytze-remove-player-styles", videoId: youtubeVideoId(location.href) }).catch(() => {});
  }
  playerController?.destroy();
  playerController = null;
  bridgeCleanup?.();
  bridgeCleanup = null;
  playerObserver?.disconnect();
  playerObserver = null;
  configurationObserver?.disconnect();
  configurationObserver = null;
  extensionStatusObserver?.disconnect();
  extensionStatusObserver = null;
  bridgeContext = null;
  if (restoreEmbeds) {
    restoreEmbeddedParameters();
    document.getElementById("ytzero-enhance-extension-status")?.setAttribute("data-extension-status", "inactive");
  }
}

onExtensionContextInvalidated(() => shutdown(true));

function boot() {
  if (window.top === window) {
    const isPairedInstance = activeInstanceUrl && configuredPageMatches(location.href, activeInstanceUrl);
    if (isPairedInstance) watchEmbeddedConfiguration();
    bootPageBridge();
    if (isPairedInstance) markExtensionActiveWhenReady();
    return;
  }
  if (!config.enhancePlayer || !remoteConfig?.enabled || !youtubeVideoId(location.href)) return;
  const videoId = youtubeVideoId(location.href)!;
  const token = ++playerBootToken;
  const authorize = async () => {
    const retryDelays = [0, 100, 250, 500, 1_000, 2_000];
    for (const delay of retryDelays) {
      if (delay) await new Promise((resolve) => window.setTimeout(resolve, delay));
      if (token !== playerBootToken || !config.enhancePlayer || !remoteConfig?.enabled) return null;
      const authorization = await callApi<any>(ext.runtime, "sendMessage", { type: "ytze-authorize-player-frame", videoId }).catch(() => null);
      if (authorization?.authorized) return authorization;
    }
    return null;
  };
  void authorize().then((authorization) => {
    if (token !== playerBootToken || !authorization?.authorized || !config.enhancePlayer || !remoteConfig?.enabled) {
      if (authorization?.authorized) void callApi(ext.runtime, "sendMessage", { type: "ytze-remove-player-styles", videoId }).catch(() => {});
      return;
    }
    const start = () => {
      const video = document.querySelector<HTMLVideoElement>("video.html5-main-video, video");
      if (!video || playerController) return;
      playerController = enhanceYouTubePlayer(video);
      playerController.setMode(authorization.mode);
      void callApi(ext.runtime, "sendMessage", { type: "ytze-player-initialized", videoId }).catch(() => {});
    };
    start();
    playerObserver = new MutationObserver(start);
    playerObserver.observe(document.documentElement, { childList: true, subtree: true });
  });
}

function markExtensionActiveWhenReady() {
  const markExtensionActive = () => {
    const element = document.getElementById("ytzero-enhance-extension-status");
    if (!element) return false;
    element.setAttribute("data-extension-status", "active");
    return true;
  };
  if (markExtensionActive() || !document.body) return;
  extensionStatusObserver = new MutationObserver(() => {
    if (markExtensionActive()) {
      extensionStatusObserver?.disconnect();
      extensionStatusObserver = null;
    }
  });
  extensionStatusObserver.observe(document.body, { childList: true, subtree: true });
}

function watchEmbeddedConfiguration() {
  const read = () => {
    const text = document.body?.querySelector<HTMLElement>(`#${EMBEDDED_CONFIGURATION_ID}`)?.textContent?.trim() ?? "";
    if (!text || text === lastEmbeddedConfigurationText) return;
    const validation = parseEmbeddedConfigurationText(text);
    lastEmbeddedConfigurationText = text;
    if (!validation.ok) {
      void callApi(ext.runtime, "sendMessage", { type: "ytze-page-configuration-error", diagnostic: validation.diagnostic, blocked: Boolean(validation.unsupportedVersion) }).catch(() => {});
      return;
    }
    void callApi(ext.runtime, "sendMessage", { type: "ytze-page-configuration", configuration: validation.value }).catch(() => {});
  };
  read();
  configurationObserver = new MutationObserver(read);
  configurationObserver.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
}

function bootPageBridge() {
  if (!config.enhancePlayer || !remoteConfig?.enabled || !activeInstanceUrl || !configuredPageMatches(location.href, activeInstanceUrl)) return;
  const configureEmbeds = (context?: EnhanceContext) => {
    for (const iframe of ownedIframeParameters.keys()) if (!iframe.isConnected) ownedIframeParameters.delete(iframe);
    for (const iframe of document.querySelectorAll<HTMLIFrameElement>('iframe[src*="youtube.com/embed/"], iframe[src*="youtube-nocookie.com/embed/"]')) {
      try {
        if (context && youtubeVideoId(iframe.src) !== context.video.id) continue;
        const url = new URL(iframe.src);
        const desired = embeddedPlayerParameters(remoteConfig!);
        if (remoteConfig!.player.preferredQuality !== "auto") desired.vq = remoteConfig!.player.preferredQuality;
        const captions = context?.playback.captions ?? remoteConfig!.player.captions;
        desired.cc_load_policy = captions.enabledByDefault ? "1" : "0";
        if (captions.language) desired.cc_lang_pref = captions.language;
        let changed = false;
        const owned = ownedIframeParameters.get(iframe) ?? new Map<string, OwnedIframeParameter>();
        for (const [key, value] of Object.entries(desired)) {
          const current = url.searchParams.get(key);
          const previous = owned.get(key);
          const original = previous && current === previous.applied ? previous.original : current;
          if (current === value) continue;
          owned.set(key, { original, applied: value });
          url.searchParams.set(key, value);
          changed = true;
        }
        if (owned.size) ownedIframeParameters.set(iframe, owned);
        if (changed) iframe.src = url.toString();
      } catch {}
    }
  };
  const onContext = (event: Event) => {
    const raw = parseBridgeDetail<any>(event as CustomEvent, MAX_CONTEXT_DETAIL_LENGTH);
    const fallback: ContentType = embeddedPlayerModeForPage(location.href) === "shorts" ? "short" : "default";
    const contentTypeAuthoritative = isContentType(raw?.video?.contentType);
    const context = validateEnhanceContext(raw, fallback);
    if (context) {
      configureEmbeds(context);
      void callApi(ext.runtime, "sendMessage", { type: "ytze-bridge-context", context, contentTypeAuthoritative }).catch(() => {});
    }
  };
  const onScreenshot = (event: Event) => {
    const request = claimScreenshotRequest(event as CustomEvent, location.href, activeInstanceUrl);
    if (!request) return;
    void callApi<any>(ext.runtime, "sendMessage", { type: "ytze-bridge-screenshot", request })
      .then((result) => dispatchScreenshotResult(result?.ok ? "saved" : "error", result?.error))
      .catch((error) => dispatchScreenshotResult("error", error.message));
  };
  const onPlayerCommand = (event: Event) => {
    const command = validatePlayerCommand(parseBridgeDetail(event as CustomEvent, MAX_COMMAND_DETAIL_LENGTH));
    if (!command) return;
    event.preventDefault();
    void callApi<any>(ext.runtime, "sendMessage", { type: "ytze-player-command", command })
      .then((result) => dispatchPlayerEvent({
        version: 1, videoId: command.videoId, type: "command-result", timestamp: Date.now(),
        payload: { requestId: command.requestId, command: command.command, ...result },
      }))
      .catch((error) => dispatchPlayerEvent({
        version: 1, videoId: command.videoId, type: "command-result", timestamp: Date.now(),
        payload: { requestId: command.requestId, command: command.command, ok: false, error: error.message },
      }));
  };
  document.addEventListener(ENHANCE_BRIDGE_EVENTS.context, onContext);
  document.addEventListener(ENHANCE_BRIDGE_EVENTS.screenshotRequest, onScreenshot);
  document.addEventListener(ENHANCE_PLAYER_EVENTS.command, onPlayerCommand);
  configureEmbeds();
  const observer = new MutationObserver(() => configureEmbeds());
  observer.observe(document.documentElement, { childList: true, subtree: true });
  const contextInterval = window.setInterval(extensionContextAvailable, 2_000);
  document.dispatchEvent(new Event(ENHANCE_BRIDGE_EVENTS.ready));
  bridgeCleanup = () => {
    document.removeEventListener(ENHANCE_BRIDGE_EVENTS.context, onContext);
    document.removeEventListener(ENHANCE_BRIDGE_EVENTS.screenshotRequest, onScreenshot);
    document.removeEventListener(ENHANCE_PLAYER_EVENTS.command, onPlayerCommand);
    observer.disconnect();
    clearInterval(contextInterval);
  };
}

function restoreEmbeddedParameters() {
  for (const [iframe, owned] of ownedIframeParameters) {
    if (!iframe.isConnected) continue;
    try {
      const url = new URL(iframe.src);
      let changed = false;
      for (const [key, value] of owned) {
        if (url.searchParams.get(key) !== value.applied) continue;
        if (value.original == null) url.searchParams.delete(key);
        else url.searchParams.set(key, value.original);
        changed = true;
      }
      if (changed) iframe.src = url.toString();
    } catch {}
  }
  ownedIframeParameters.clear();
}

function dispatchPlayerEvent(detail: Record<string, unknown>) {
  document.dispatchEvent(new CustomEvent(ENHANCE_PLAYER_EVENTS.event, { detail: JSON.stringify(detail) }));
}

function dispatchScreenshotResult(status: "saved" | "error", error?: string) {
  document.dispatchEvent(new CustomEvent(ENHANCE_BRIDGE_EVENTS.screenshotResult, {
    detail: JSON.stringify({ version: 1, status, ...(error ? { error: String(error).slice(0, 300) } : {}) }),
  }));
}

function enhanceYouTubePlayer(video: HTMLVideoElement) {
  const presentation = playerPresentationState(config.enhancePlayer, true, remoteConfig, false);
  if (presentation.active) document.documentElement.classList.add("ytze-active");
  if (presentation.replaceControls) document.documentElement.classList.add("ytze-replace-controls");
  const host = document.createElement("div");
  host.id = "ytze-player-controls";
  const shadow = host.attachShadow({ mode: "open" });
  const create = (tag: string, className = "") => {
    const element = document.createElement(tag);
    if (className) element.className = className;
    return element;
  };
  const iconButton = (className: string, label: string, icon: PlayerIcon) => {
    const button = create("button", className) as HTMLButtonElement;
    button.type = "button";
    button.setAttribute("aria-label", label);
    setPlayerIcon(button, icon);
    return button;
  };
  const styleElement = create("style");
  styleElement.textContent = CONTROL_STYLES;
  const bigPlayElement = iconButton("big-play", t("play"), PLAYER_ICONS.play);
  const controlsElement = create("div", "controls");
  controlsElement.setAttribute("role", "group");
  controlsElement.setAttribute("aria-label", t("playerControls"));
  const progressElement = create("div", "progress");
  for (const [name, value] of Object.entries({ role: "slider", tabindex: "0", "aria-label": t("progress"), "aria-valuemin": "0", "aria-valuemax": "1000", "aria-valuenow": "0" })) progressElement.setAttribute(name, value);
  const progressTrack = create("div", "progress-track");
  const bufferedElement = create("div", "buffered");
  const markersElement = create("div", "markers");
  markersElement.setAttribute("aria-hidden", "true");
  const playedElement = create("div", "played");
  progressTrack.append(bufferedElement, markersElement, playedElement);
  const knobElement = create("div", "knob");
  const tooltipElement = create("div", "progress-tooltip");
  const chapterElement = create("span", "chapter");
  const hoverTimeElement = create("span", "hover-time");
  hoverTimeElement.textContent = "0:00";
  tooltipElement.append(chapterElement, hoverTimeElement);
  progressElement.append(progressTrack, knobElement, tooltipElement);
  const buttonsElement = create("div", "buttons");
  const playElement = iconButton("play", t("playPause"), PLAYER_ICONS.play);
  const volumeWrap = create("div", "volume-wrap");
  const muteElement = iconButton("mute", t("mute"), PLAYER_ICONS.volume);
  const volumeElement = create("input", "volume") as HTMLInputElement;
  Object.assign(volumeElement, { type: "range", min: "0", max: "1", step: "0.05", value: "1" });
  volumeElement.setAttribute("aria-label", t("volume"));
  volumeWrap.append(muteElement, volumeElement);
  const timeElement = create("span", "time");
  timeElement.textContent = "0:00 / 0:00";
  const liveEdgeElement = create("button", "live-edge") as HTMLButtonElement;
  liveEdgeElement.type = "button";
  liveEdgeElement.setAttribute("aria-label", t("goLive"));
  const liveDotElement = create("span", "live-dot");
  const liveLabelElement = create("span");
  liveLabelElement.textContent = t("live");
  liveEdgeElement.append(liveDotElement, liveLabelElement);
  liveEdgeElement.hidden = true;
  const spacerElement = create("span", "spacer");
  const captionMenuWrapElement = create("div", "caption-menu-wrap");
  const captionsElement = iconButton("captions", t("captionsShortcut"), PLAYER_ICONS.captions);
  captionsElement.setAttribute("aria-haspopup", "dialog");
  captionsElement.setAttribute("aria-expanded", "false");
  const captionMenuElement = create("div", "caption-menu");
  captionMenuElement.setAttribute("role", "dialog");
  captionMenuElement.setAttribute("aria-label", t("captions"));
  captionMenuElement.hidden = true;
  const captionToggleElement = create("div", "caption-toggle");
  const captionToggleLabel = create("span");
  captionToggleLabel.textContent = t("captions");
  const captionSwitchElement = create("button", "caption-switch") as HTMLButtonElement;
  captionSwitchElement.type = "button";
  captionSwitchElement.setAttribute("role", "switch");
  captionSwitchElement.setAttribute("aria-checked", "false");
  captionSwitchElement.setAttribute("aria-label", t("captions"));
  captionSwitchElement.append(create("span"));
  captionToggleElement.append(captionToggleLabel, captionSwitchElement);
  const captionListElement = create("div", "caption-list");
  captionListElement.setAttribute("role", "listbox");
  captionListElement.setAttribute("aria-label", t("captions"));
  captionMenuElement.append(captionToggleElement, captionListElement);
  captionMenuWrapElement.append(captionsElement, captionMenuElement);
  const pipElement = iconButton("pip", t("pictureInPicture"), PLAYER_ICONS.pip);
  const fullscreenElement = iconButton("fullscreen", t("fullscreen"), PLAYER_ICONS.fullscreen);
  buttonsElement.append(playElement, volumeWrap, timeElement, liveEdgeElement, spacerElement, captionMenuWrapElement, pipElement, fullscreenElement);
  controlsElement.append(progressElement, buttonsElement);
  const toastElement = create("div", "toast");
  toastElement.setAttribute("aria-live", "polite");
  shadow.append(styleElement, bigPlayElement, controlsElement, toastElement);
  document.documentElement.append(host);
  const q = <T extends Element>(selector: string) => shadow.querySelector<T>(selector)!;
  const play = q<HTMLButtonElement>(".play");
  const bigPlay = q<HTMLButtonElement>(".big-play");
  const time = q<HTMLElement>(".time");
  const progress = q<HTMLElement>(".progress");
  const played = q<HTMLElement>(".played");
  const buffered = q<HTMLElement>(".buffered");
  const knob = q<HTMLElement>(".knob");
  const tooltip = q<HTMLElement>(".progress-tooltip");
  const hoverTime = q<HTMLElement>(".hover-time");
  const chapter = q<HTMLElement>(".chapter");
  const mute = q<HTMLButtonElement>(".mute");
  const volume = q<HTMLInputElement>(".volume");
  const captions = q<HTMLButtonElement>(".captions");
  const captionMenuWrap = q<HTMLElement>(".caption-menu-wrap");
  const captionMenu = q<HTMLElement>(".caption-menu");
  const captionSwitch = q<HTMLButtonElement>(".caption-switch");
  const captionList = q<HTMLElement>(".caption-list");
  const fullscreen = q<HTMLButtonElement>(".fullscreen");
  const toast = q<HTMLElement>(".toast");
  let toastTimer = 0;
  let idleTimer = 0;
  let qualityInterval = 0;
  let scrubbing = false;
  let temporaryBoostController: TemporaryBoostController | null = null;
  let shortcutBindings: ShortcutBindings = { ...DEFAULT_SHORTCUT_BINDINGS };
  let lastSkippedSegment = "";
  const ownedRate = new OwnedPlaybackRate(remoteConfig?.player.defaultPlaybackRate ?? 1);
  let subtitleSize = remoteConfig?.player.captions.style.fontSizePx ?? 19;
  let selectedCaptionLanguage = new URL(location.href).searchParams.get("cc_lang_pref") || remoteConfig?.player.captions.language || "en";
  let captionLanguageUserSelected = false;
  const initialCaptionButton = document.querySelector<HTMLElement>(".ytmClosedCaptioningButtonButton, .ytp-subtitles-button");
  const initialCaptionPressed = initialCaptionButton?.getAttribute("aria-pressed");
  let captionsEnabled = initialCaptionPressed === "true" || (initialCaptionPressed == null && (
    new URL(location.href).searchParams.get("cc_load_policy") === "1" || remoteConfig?.player.captions.enabledByDefault === true
  ));
  let captionMenuOpen = false;
  let captionDefaultTimer = 0;
  let captionDefaultsApplied = false;
  let captionUserOverride = false;
  let captionOperationQueue: Promise<unknown> = Promise.resolve();
  let lastStateEmit = 0;
  let requestedPlayerMode: EmbeddedPlayerMode = "standard";
  let contentTypeAuthoritative = false;
  let playerMode: EmbeddedPlayerMode = "standard";
  const previewEmbed = isPreviewEmbedUrl(location.href);
  let observedLivePlayableEnd = 0;
  const lifecycle = new AbortController();
  const signal = lifecycle.signal;
  const videoId = youtubeVideoId(location.href)!;
  const playerState = () => ({
    paused: video.paused,
    ended: video.ended,
    currentTime: Number.isFinite(video.currentTime) ? video.currentTime : 0,
    duration: Number.isFinite(video.duration) ? video.duration : 0,
    volume: video.volume,
    muted: video.muted,
    playbackRate: video.playbackRate,
    captionSize: subtitleSize,
    captionsEnabled,
    fullscreen: Boolean(document.fullscreenElement),
    pictureInPicture: document.pictureInPictureElement === video,
  });
  const emitPlayerEvent = (type: "ready" | "state" | "shortcut" | "captions-toggle-request" | "ended", payload: Record<string, unknown>) => {
    void callApi(ext.runtime, "sendMessage", {
      type: "ytze-player-event",
      event: { version: 1, videoId, type, timestamp: Date.now(), payload },
    }).catch(() => {});
  };
  const emitState = (reason: string, force = false) => {
    const now = Date.now();
    if (!force && now - lastStateEmit < 1_000) return;
    lastStateEmit = now;
    emitPlayerEvent("state", { reason, state: playerState() });
  };
  const applyPreferredQuality = () => {
    const player = document.querySelector(".html5-video-player") as any;
    const selected = highestQualityAtOrBelow(player?.getAvailableQualityLevels?.(), remoteConfig?.player.preferredQuality ?? "auto");
    if (selected) {
      player.setPlaybackQualityRange?.(selected, selected);
      player.setPlaybackQuality?.(selected);
    }
    void callApi(ext.runtime, "sendMessage", { type: "ytze-apply-preferred-quality" }).catch(() => {});
  };

  const playbackSettings = () => bridgeContext?.video.id === youtubeVideoId(location.href) ? bridgeContext.playback : {
    rate: remoteConfig?.player.defaultPlaybackRate ?? 1,
    keyboardSeekSeconds: remoteConfig?.player.keyboardSeekSeconds ?? config.seekSeconds,
    frameStepFps: remoteConfig?.player.frameStepFps ?? config.frameRate,
    keyboardShortcuts: shortcutBindings,
    transportLocked: false,
    captions: remoteConfig?.player.captions ?? { enabledByDefault: false, language: "en", availableLanguages: [], style: { fontSizePx: 19, color: "#ffffff", backgroundOpacityPercent: 75 } },
    chapters: [], sponsorBlockSegments: [],
  };

  const applyContext = (context: EnhanceContext, authoritative = true) => {
    if (context.video.id !== youtubeVideoId(location.href)) return;
    bridgeContext = context;
    shortcutBindings = context.playback.keyboardShortcuts;
    setContentType(context.video.contentType, authoritative);
    ownedRate.reset(context.playback.rate, playerMode === "live");
    if (!temporaryBoostController?.active) video.playbackRate = ownedRate.value;
    if (context.playback.transportLocked || context.video.contentType === "livestream"
      || (temporaryBoostController?.chord != null && context.playback.keyboardShortcuts.temporaryBoost !== temporaryBoostController.chord)) {
      temporaryBoostController?.reset();
    }
    if (!captionLanguageUserSelected) selectedCaptionLanguage = context.playback.captions.language || selectedCaptionLanguage;
    subtitleSize = context.playback.captions.style.fontSizePx;
    if (!previewEmbed) {
      applyCaptionPreferences(context.playback.captions);
      scheduleCaptionDefaults(300);
      renderMarkers(context);
    }
  };

  const say = (message: string, duration = 1500) => {
    if (playerMode === "preview") return;
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove("show"), duration);
  };
  const captionLanguages = () => remoteConfig?.player.captions.availableLanguages ?? [];
  const captionsAreEnabled = () => captionsEnabled;
  const setCaptionMenuOpen = (open: boolean) => {
    captionMenuOpen = open;
    captionMenu.hidden = !open;
    captions.setAttribute("aria-expanded", String(open));
    if (open) showControls();
  };
  const syncCaptionControls = () => {
    const enabled = captionsAreEnabled();
    captions.classList.toggle("active", enabled);
    captionSwitch.classList.toggle("active", enabled);
    captionSwitch.setAttribute("aria-checked", String(enabled));
    for (const option of captionList.querySelectorAll<HTMLButtonElement>("button[data-language]")) {
      const selected = option.dataset.language === selectedCaptionLanguage;
      option.classList.toggle("is-selected", selected);
      option.setAttribute("aria-selected", String(selected));
      option.querySelector(".caption-option-status")!.textContent = selected ? "✓" : "";
    }
  };
  const setYouTubeCaptions = (enabled: boolean, language = selectedCaptionLanguage, userInitiated = true) => {
    if (userInitiated) {
      captionUserOverride = true;
      captionLanguageUserSelected = true;
      clearTimeout(captionDefaultTimer);
      captionDefaultTimer = 0;
    }
    const operation = async () => {
      const configured = captionLanguages().find((item) => item.code === language);
      const response = await callApi<any>(ext.runtime, "sendMessage", {
        type: "ytze-set-youtube-captions",
        enabled,
        language,
        label: configured?.label ?? language,
      }).catch((error) => ({ ok: false, error: error.message }));
      if (!response?.ok || typeof response.enabled !== "boolean") {
        if (typeof response?.enabled === "boolean") captionsEnabled = response.enabled;
        if (userInitiated) say(`${t("captionsUnavailable")}: ${response?.error || t("unknown")}`);
        syncCaptionControls();
        return false;
      }
      captionsEnabled = response.enabled;
      if (response.enabled) selectedCaptionLanguage = language;
      setCaptionMenuOpen(false);
      window.setTimeout(() => { update(); syncCaptionControls(); emitState("captions", true); }, 150);
      return true;
    };
    const pending = captionOperationQueue.then(operation, operation);
    captionOperationQueue = pending.then(() => undefined, () => undefined);
    return pending;
  };
  const scheduleCaptionDefaults = (delay: number) => {
    if (previewEmbed || captionDefaultsApplied || captionUserOverride) return;
    clearTimeout(captionDefaultTimer);
    captionDefaultTimer = window.setTimeout(() => {
      captionDefaultTimer = 0;
      if (captionDefaultsApplied || captionUserOverride) return;
      captionDefaultsApplied = true;
      const defaults = playbackSettings().captions;
      void setYouTubeCaptions(defaults.enabledByDefault, defaults.language || selectedCaptionLanguage, false);
    }, delay);
  };
  const renderCaptionLanguageMenu = () => {
    const languages = captionLanguages();
    captionList.replaceChildren();
    for (const language of languages) {
      const option = document.createElement("button");
      option.type = "button";
      option.dataset.language = language.code;
      option.setAttribute("role", "option");
      const label = document.createElement("span");
      label.textContent = language.label;
      const status = document.createElement("span");
      status.className = "caption-option-status";
      option.append(label, status);
      option.addEventListener("click", () => void setYouTubeCaptions(true, language.code), { signal });
      captionList.append(option);
    }
    syncCaptionControls();
  };
  const showControls = () => {
    host.classList.add("visible");
    document.documentElement.classList.remove("ytze-idle");
    clearTimeout(idleTimer);
    if (!video.paused) idleTimer = window.setTimeout(() => {
      if (captionMenuOpen) return;
      host.classList.remove("visible");
      document.documentElement.classList.add("ytze-idle");
    }, 2600);
  };
  const hideControls = () => {
    clearTimeout(idleTimer);
    host.classList.remove("visible");
    document.documentElement.classList.add("ytze-idle");
  };
  const nativeLivePlayback = () => video.duration === Infinity
    || document.querySelector(".html5-video-player")?.classList.contains("ytp-live") === true;
  const liveSeekRange = () => {
    if (!video.seekable.length) return null;
    const seekableIndex = video.seekable.length - 1;
    const start = video.seekable.start(seekableIndex);
    const end = video.seekable.end(seekableIndex);
    let bufferedEnd: number | null = null;
    for (let index = 0; index < video.buffered.length; index++) {
      const candidate = video.buffered.end(index);
      if (video.buffered.start(index) <= end && candidate >= start) bufferedEnd = Math.max(bufferedEnd ?? start, candidate);
    }
    observedLivePlayableEnd = Math.max(observedLivePlayableEnd, video.currentTime);
    const range = playableLiveRange(start, end, video.currentTime, bufferedEnd, observedLivePlayableEnd);
    if (range) observedLivePlayableEnd = Math.max(observedLivePlayableEnd, range.end);
    return range;
  };
  const applyPlayerMode = (mode: EmbeddedPlayerMode) => {
    if (playerMode === mode) return;
    playerMode = mode;
    host.classList.toggle("mode-live", mode === "live");
    host.classList.toggle("mode-shorts", mode === "shorts");
    host.classList.toggle("mode-preview", mode === "preview");
    liveEdgeElement.hidden = mode !== "live";
    if (mode === "preview") {
      video.autoplay = true;
      video.loop = true;
      video.muted = true;
      video.defaultMuted = true;
      setCaptionMenuOpen(false);
      void video.play().catch(() => {});
    } else if (mode === "live") {
      ownedRate.reset(1, true);
      temporaryBoostController?.reset();
      video.playbackRate = 1;
      setCaptionMenuOpen(false);
    } else {
      ownedRate.reset(playbackSettings().rate);
      video.playbackRate = ownedRate.value;
    }
  };
  const setContentType = (type: ContentType, authoritative = true) => {
    requestedPlayerMode = type === "livestream" ? "live" : type === "short" ? "shorts" : "standard";
    contentTypeAuthoritative = authoritative;
    refreshPlayerMode();
    if (requestedPlayerMode === "shorts") {
      setCaptionMenuOpen(false);
      (shadow.activeElement as HTMLElement | null)?.blur?.();
      hideControls();
    }
  };
  const refreshPlayerMode = () => {
    applyPlayerMode(
      previewEmbed
        ? "preview"
        : resolveEmbeddedPlayerMode(
            requestedPlayerMode,
            contentTypeAuthoritative,
            nativeLivePlayback(),
          ),
    );
  };
  const goLive = () => {
    const range = liveSeekRange();
    if (range) video.currentTime = Math.max(range.start, range.end - .1);
    void video.play().catch(() => {});
    showControls();
  };
  const togglePlay = () => video.paused ? video.play().catch(() => {}) : video.pause();
  const toggleFullscreen = () => {
    const safariVideo = video as HTMLVideoElement & {
      webkitEnterFullscreen?: () => void;
      webkitExitFullscreen?: () => void;
      webkitDisplayingFullscreen?: boolean;
    };
    if (document.fullscreenElement) void document.exitFullscreen();
    else if (safariVideo.webkitDisplayingFullscreen) safariVideo.webkitExitFullscreen?.();
    else if (document.documentElement.requestFullscreen) void document.documentElement.requestFullscreen();
    else safariVideo.webkitEnterFullscreen?.();
  };
  const togglePictureInPicture = async () => {
    if (document.pictureInPictureElement) {
      if (!document.exitPictureInPicture) return false;
      await document.exitPictureInPicture();
      return true;
    }
    if (!video.requestPictureInPicture) return false;
    await video.requestPictureInPicture();
    return true;
  };
  const toggleCaptions = () => {
    const currentEnabled = captionsAreEnabled();
    emitPlayerEvent("captions-toggle-request", {
      action: "toggle",
      currentEnabled,
      requestedEnabled: !currentEnabled,
    });
  };
  const requestCapture = async (bridgeRequest?: BridgeScreenshotRequest) => {
    const bounds = video.getBoundingClientRect();
    const fitted = getComputedStyle(video).objectFit === "fill"
      ? { x: bounds.x, y: bounds.y, width: bounds.width, height: bounds.height }
      : containedMediaRect(bounds, video.videoWidth, video.videoHeight);
    const title = document.querySelector<HTMLElement>(".ytp-title-link")?.innerText?.trim() || document.title.replace(/\s*-\s*YouTube$/, "");
    const channel = document.querySelector<HTMLElement>(".ytp-title-channel")?.textContent?.trim() || "YouTube";
    const metadata = bridgeRequest ? {
      title: bridgeRequest.video.title, channel: bridgeRequest.video.channelTitle, videoId: bridgeRequest.video.id, seconds: bridgeRequest.video.seconds,
    } : { title, channel, videoId: youtubeVideoId(location.href), seconds: video.currentTime };
    const contextScreenshot = bridgeContext?.video.id === youtubeVideoId(location.href) ? bridgeContext.screenshot : null;
    const defaultCaptureSettings = contextScreenshot ?? (remoteConfig ? {
      format: remoteConfig.screenshots.format,
      quality: remoteConfig.screenshots.jpegQuality,
      filenameTemplate: remoteConfig.screenshots.filenameTemplate,
    } : undefined);
    const response = await callApi<any>(ext.runtime, "sendMessage", {
      type: "ytze-capture-frame",
      videoId: youtubeVideoId(location.href),
      rect: fitted,
      viewport: { width: innerWidth, height: innerHeight },
      metadata,
      captureSettings: bridgeRequest?.screenshot ?? defaultCaptureSettings,
    }).catch((error) => ({ ok: false, error: error.message }));
    say(response?.ok ? `${t("saved")}: ${response.filename}` : `${t("captureError")}: ${response?.error || t("unknown")}`);
    return response;
  };
  const executeCommand = async (command: EnhancePlayerCommand) => {
    const payload = command.payload as Record<string, any>;
    if (playerMode === "preview" && !["seek-by", "seek-to", "set-muted", "toggle-muted", "capture-frame"].includes(command.command)) {
      return { ok: false, error: `${command.command} is unavailable for previews`, state: playerState() };
    }
    if (playerMode === "live" && command.command === "set-playback-rate") {
      return { ok: false, error: "set-playback-rate is unavailable for livestreams", state: playerState() };
    }
    if (playerMode === "live" && (command.command === "seek-by" || command.command === "seek-to") && !liveSeekRange()) {
      return { ok: false, error: `${command.command} is unavailable without a DVR window`, state: playerState() };
    }
    if (command.command === "play") await video.play();
    else if (command.command === "pause") video.pause();
    else if (command.command === "toggle-play") await (video.paused ? video.play() : Promise.resolve(video.pause()));
    else if (command.command === "seek-by") seekBy(Number(payload.seconds));
    else if (command.command === "seek-to") {
      const range = playerMode === "live" ? liveSeekRange() : null;
      video.currentTime = Math.min(Math.max(range?.start ?? 0, Number(payload.seconds)), range?.end ?? (video.duration || Infinity));
    }
    else if (command.command === "set-volume") { video.volume = Number(payload.volume); video.muted = false; }
    else if (command.command === "set-muted") video.muted = Boolean(payload.enabled);
    else if (command.command === "toggle-muted") video.muted = !video.muted;
    else if (command.command === "set-playback-rate") {
      ownedRate.reset(Number(payload.rate));
      if (!temporaryBoostController?.active) video.playbackRate = ownedRate.value;
    }
    else if (command.command === "set-captions") await setYouTubeCaptions(Boolean(payload.enabled));
    else if (command.command === "toggle-captions") await setYouTubeCaptions(!captionsAreEnabled());
    else if (command.command === "set-caption-size") { subtitleSize = Number(payload.pixels); document.documentElement.style.setProperty("--ytze-caption-size", `${subtitleSize}px`); }
    else if (command.command === "capture-frame") await requestCapture();
    else if (command.command === "toggle-fullscreen") toggleFullscreen();
    else if (command.command === "enter-fullscreen" && !document.fullscreenElement) toggleFullscreen();
    else if (command.command === "exit-fullscreen" && document.fullscreenElement) await document.exitFullscreen();
    else if (command.command === "toggle-picture-in-picture" && !(await togglePictureInPicture())) {
      return { ok: false, error: "Picture-in-picture is unavailable", state: playerState() };
    }
    update();
    emitState("command", true);
    return { ok: true, state: playerState() };
  };
  const update = () => {
    refreshPlayerMode();
    if (playerMode === "shorts" && video.videoWidth > 0 && video.videoHeight > 0) {
      const stage = containedMediaRect(video.getBoundingClientRect(), video.videoWidth, video.videoHeight);
      host.style.setProperty("--ytze-short-left", `${Math.max(0, stage.x)}px`);
      host.style.setProperty("--ytze-short-right", `${Math.max(0, innerWidth - stage.x - stage.width)}px`);
    }
    const liveRange = playerMode === "live" ? liveSeekRange() : null;
    const duration = Number.isFinite(video.duration) ? video.duration : 0;
    const timeline = playerTimeline(video.currentTime, video.duration, liveRange);
    const timelineStart = timeline.start;
    const timelineDuration = timeline.length;
    const fraction = timeline.fraction;
    if (!scrubbing) {
      played.style.width = `${fraction * 100}%`;
      knob.style.left = `${fraction * 100}%`;
      progress.setAttribute("aria-valuenow", String(Math.round(fraction * 1000)));
    }
    let bufferedEnd = 0;
    for (let index = 0; index < video.buffered.length; index++) if (video.buffered.start(index) <= video.currentTime + .2) bufferedEnd = Math.max(bufferedEnd, video.buffered.end(index));
    buffered.style.width = `${timelineDuration ? Math.min(100, Math.max(0, (bufferedEnd - timelineStart) / timelineDuration * 100)) : 0}%`;
    time.textContent = `${formatClock(video.currentTime).replace(/-/g, ":")} / ${formatClock(duration).replace(/-/g, ":")}`;
    const liveDelay = timeline.liveDelay;
    const atLiveEdge = liveDelay != null && liveDelay <= 2;
    liveEdgeElement.classList.toggle("active", atLiveEdge);
    liveEdgeElement.setAttribute("aria-label", atLiveEdge ? t("live") : liveDelay == null ? t("goLive") : `${t("goLive")} (−${formatClock(liveDelay).replace(/-/g, ":")})`);
    progress.classList.toggle("unavailable", playerMode === "live" && !liveRange);
    progress.setAttribute("aria-disabled", String(playerMode === "live" && !liveRange));
    setPlayerIcon(play, video.paused ? PLAYER_ICONS.play : PLAYER_ICONS.pause);
    bigPlay.hidden = !video.paused || video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA;
    setPlayerIcon(mute, video.muted || video.volume === 0 ? PLAYER_ICONS.muted : PLAYER_ICONS.volume);
    volume.value = String(video.muted ? 0 : video.volume);
    syncCaptionControls();
    setPlayerIcon(fullscreen, document.fullscreenElement ? PLAYER_ICONS.minimize : PLAYER_ICONS.fullscreen);
    const playback = playbackSettings();
    if (playerMode !== "preview" && remoteConfig?.sponsorBlock.enabled) {
      const segment = playback.sponsorBlockSegments.find((item) => item.actionType === "skip" && video.currentTime >= item.segment[0] && video.currentTime < item.segment[1] - .25);
      if (segment && segment.UUID !== lastSkippedSegment) {
        lastSkippedSegment = segment.UUID;
        video.currentTime = segment.segment[1];
        say(`${t("skipped")}: ${segment.category}`);
      }
    }
    emitState("timeupdate");
  };
  const seekBy = (seconds: number) => {
    const range = playerMode === "live" ? liveSeekRange() : null;
    video.currentTime = Math.min(Math.max(range?.start ?? 0, video.currentTime + seconds), range?.end ?? (video.duration || Infinity));
  };
  const progressFraction = (clientX: number) => {
    const bounds = progress.getBoundingClientRect();
    return Math.min(1, Math.max(0, (clientX - bounds.left) / Math.max(1, bounds.width)));
  };
  const scrubTo = (clientX: number) => {
    const range = playerMode === "live" ? liveSeekRange() : null;
    const duration = range ? range.end - range.start : video.duration;
    if (!Number.isFinite(duration) || duration <= 0) return;
    const fraction = progressFraction(clientX);
    video.currentTime = (range?.start ?? 0) + fraction * duration;
    played.style.width = `${fraction * 100}%`;
    knob.style.left = `${fraction * 100}%`;
  };
  const showProgressTooltip = (clientX: number) => {
    if (playerMode === "preview") return;
    const range = playerMode === "live" ? liveSeekRange() : null;
    const duration = range ? range.end - range.start : video.duration;
    if (!Number.isFinite(duration) || duration <= 0) return;
    const fraction = progressFraction(clientX);
    const seconds = (range?.start ?? 0) + fraction * duration;
    tooltip.style.left = `${fraction * 100}%`;
    hoverTime.textContent = range
      ? `−${formatClock(Math.max(0, range.end - seconds)).replace(/-/g, ":")}`
      : formatClock(seconds).replace(/-/g, ":");
    const activeChapter = [...(bridgeContext?.playback.chapters ?? [])].reverse().find((item) => item.start <= seconds);
    chapter.textContent = activeChapter?.title ?? "";
    chapter.hidden = !activeChapter;
    tooltip.classList.add("show");
  };
  const emitShortcut = (action: ShortcutAction, event: Parameters<typeof shortcutEventPayload>[1], value?: number) => {
    emitPlayerEvent("shortcut", shortcutEventPayload(action, event, value));
  };
  const consumeShortcut = (event: KeyboardEvent) => {
    event.preventDefault();
    event.stopPropagation();
  };
  temporaryBoostController = new TemporaryBoostController({
    schedule: (callback, delay) => window.setTimeout(callback, delay),
    cancel: (timer) => window.clearTimeout(timer),
    isBlocked: () => shortcutOperationBlocked("temporaryBoost", playerMode === "live", playbackSettings().transportLocked),
    togglePlay,
    setRate: (rate) => {
      video.playbackRate = rate;
      if (rate === 2) say("2×");
    },
    effectiveRate: () => ownedRate.value,
    applied: (event) => emitShortcut("temporaryBoost", event),
  });
  const onKey = (event: KeyboardEvent) => {
    if (playerMode === "preview" || isEditableShortcutEvent(event)) return;
    const action = matchingShortcutAction(event, shortcutBindings);
    if (!action) {
      const chord = shortcutChordFromEvent(event);
      if (playerMode !== "shorts" || (chord !== "ArrowUp" && chord !== "ArrowDown")) return;
      consumeShortcut(event);
      if (!event.repeat && !playbackSettings().transportLocked) {
        void callApi(ext.runtime, "sendMessage", {
          type: "ytze-player-page-shortcut",
          key: chord === "ArrowUp" ? "shorts-prev" : "shorts-next",
        }).catch(() => {});
      }
      return;
    }

    consumeShortcut(event);
    if (event.repeat && !shortcutAllowsRepeat(action)) return;
    if (shortcutOperationBlocked(action, playerMode === "live", playbackSettings().transportLocked)) return;
    if (PARENT_OWNED_SHORTCUT_ACTIONS.has(action)) {
      emitShortcut(action, event);
      return;
    }

    if (action === "temporaryBoost") {
      temporaryBoostController?.keydown(event);
      return;
    }
    if (action === "togglePlay") togglePlay();
    else if (action === "seekBack10" || action === "seekForward10") {
      seekBy(action === "seekBack10" ? -10 : 10);
      say(`${action === "seekBack10" ? "−" : "+"}10 s`);
    } else if (action === "seekBack" || action === "seekForward") {
      const seconds = playbackSettings().keyboardSeekSeconds;
      seekBy(action === "seekBack" ? -seconds : seconds);
      say(`${action === "seekBack" ? "−" : "+"}${seconds} s`);
    } else if (action === "previousFrame" || action === "nextFrame") {
      if (!video.paused) return;
      const seconds = frameStepSeconds(playbackSettings().frameStepFps);
      seekBy(action === "previousFrame" ? -seconds : seconds);
      say(t(action === "previousFrame" ? "oneFrameBack" : "oneFrameForward"));
    } else if (action === "speedDown" || action === "speedUp") {
      const nextRate = advanceOwnedPlaybackRate(ownedRate, action === "speedDown" ? -1 : 1, (rate) => {
        video.playbackRate = rate;
      });
      say(`${nextRate}×`);
      emitShortcut(action, event, nextRate);
      update();
      return;
    } else if (action === "seekPercent") {
      if (!/^Digit[0-9]$/.test(event.code) || !Number.isFinite(video.duration) || video.duration <= 0) return;
      video.currentTime = Number(event.code.slice(-1)) / 10 * video.duration;
    } else if (action === "previousChapter" || action === "nextChapter") {
      const target = chapterShortcutTarget(action, video.currentTime, playbackSettings().chapters);
      if (target == null) return;
      video.currentTime = target;
    } else if (action === "volumeUp" || action === "volumeDown") {
      video.volume = Math.min(1, Math.max(0, video.volume + (action === "volumeUp" ? .05 : -.05)));
      if (action === "volumeUp" && video.volume > 0) video.muted = false;
      say(`${Math.round(video.volume * 100)}%`);
    } else if (action === "toggleCaptions") {
      void setYouTubeCaptions(!captionsAreEnabled()).then((applied) => {
        if (applied) emitShortcut(action, event);
      });
      return;
    } else if (action === "subtitleLarger" || action === "subtitleSmaller") {
      subtitleSize = Math.min(48, Math.max(12, subtitleSize + (action === "subtitleLarger" ? 1 : -1)));
      document.documentElement.style.setProperty("--ytze-caption-size", `${subtitleSize}px`);
      say(`${subtitleSize}px`);
    } else if (action === "toggleFullscreen") toggleFullscreen();
    else if (action === "togglePictureInPicture") {
      void togglePictureInPicture().then((applied) => {
        if (applied) emitShortcut(action, event);
      }).catch(() => {});
      return;
    }
    else if (action === "toggleMute") video.muted = !video.muted;
    else if (action === "screenshot") {
      if (isFirefox) {
        say(t("firefoxCaptureShortcut"), 4000);
        return;
      }
      void requestCapture().then((response) => {
        if (response?.ok) emitShortcut(action, event);
      });
      return;
    }

    emitShortcut(action, event);
    update();
  };
  const onKeyUp = (event: KeyboardEvent) => {
    if (playerMode === "preview" || !temporaryBoostController?.keyup(event)) return;
    consumeShortcut(event);
    update();
  };
  const onSurfaceClick = (event: MouseEvent) => {
    if (playerMode === "preview") return;
    const target = event.target as Element | null;
    if (!target || target.closest("#ytze-player-controls") || !target.closest(".html5-video-player")) return;
    event.preventDefault(); event.stopImmediatePropagation(); togglePlay(); showControls();
  };
  const onSurfaceDoubleClick = (event: MouseEvent) => {
    if (playerMode === "preview") return;
    const target = event.target as Element | null;
    if (!target || target.closest("#ytze-player-controls")) return;
    event.preventDefault(); event.stopImmediatePropagation(); toggleFullscreen();
  };

  play.addEventListener("click", togglePlay, { signal });
  bigPlay.addEventListener("click", togglePlay, { signal });
  liveEdgeElement.addEventListener("click", goLive, { signal });
  progress.addEventListener("pointerdown", (event) => { scrubbing = true; progress.setPointerCapture(event.pointerId); scrubTo(event.clientX); if (playerMode !== "preview") showProgressTooltip(event.clientX); }, { signal });
  progress.addEventListener("pointermove", (event) => { if (playerMode !== "preview") showProgressTooltip(event.clientX); if (scrubbing) scrubTo(event.clientX); }, { signal });
  progress.addEventListener("pointerup", (event) => { scrubbing = false; progress.releasePointerCapture(event.pointerId); }, { signal });
  progress.addEventListener("pointerleave", () => { if (!scrubbing) tooltip.classList.remove("show"); }, { signal });
  const togglePreviewMuted = () => {
    if (video.muted) {
      if (video.volume === 0) video.volume = 1;
      video.muted = false;
      void video.play().catch(() => {});
    } else {
      video.muted = true;
    }

    update();
  };
  mute.addEventListener("pointerdown", (event) => {
    if (playerMode !== "preview") return;

    event.preventDefault();
    event.stopPropagation();
    togglePreviewMuted();
  }, { signal });
  mute.addEventListener("click", (event) => {
    if (playerMode === "preview") {
      event.preventDefault();
      event.stopPropagation();
      return;
    }

    video.muted = !video.muted;
    update();
  }, { signal });
  volume.addEventListener("input", () => { video.volume = Number(volume.value); video.muted = false; update(); }, { signal });
  captions.addEventListener("click", () => setCaptionMenuOpen(!captionMenuOpen), { signal });
  captionSwitch.addEventListener("click", () => void setYouTubeCaptions(!captionsAreEnabled()), { signal });
  q(".pip").addEventListener("click", () => void togglePictureInPicture().then((applied) => {
    if (!applied) say(t("pipUnavailable"));
  }).catch(() => say(t("pipUnavailable"))), { signal });
  fullscreen.addEventListener("click", toggleFullscreen, { signal });
  document.addEventListener("keydown", onKey, { capture: true, signal });
  document.addEventListener("keyup", onKeyUp, { capture: true, signal });
  document.addEventListener("click", onSurfaceClick, { capture: true, signal });
  document.addEventListener("dblclick", onSurfaceDoubleClick, { capture: true, signal });
  document.addEventListener("pointerdown", (event) => {
    if (captionMenuOpen && !event.composedPath().includes(captionMenuWrap)) setCaptionMenuOpen(false);
  }, { capture: true, signal });
  document.addEventListener("mousemove", showControls, { passive: true, signal });
  video.addEventListener("play", () => { if (playerMode !== "shorts" && playerMode !== "preview") showControls(); applyPreferredQuality(); emitState("play", true); }, { signal });
  video.addEventListener("pause", () => {
    if (playerMode === "preview") void video.play().catch(() => {});
    else if (playerMode !== "shorts") showControls();
    emitState("pause", true);
  }, { signal });
  video.addEventListener("volumechange", () => emitState("volumechange", true), { signal });
  video.addEventListener("loadedmetadata", () => {
    refreshPlayerMode();
    if (!temporaryBoostController?.active && Math.abs(video.playbackRate - ownedRate.value) > .001) video.playbackRate = ownedRate.value;
  }, { signal });
  video.addEventListener("ratechange", () => {
    if (!temporaryBoostController?.active && Math.abs(video.playbackRate - ownedRate.value) > .001) queueMicrotask(() => {
      if (!temporaryBoostController?.active) video.playbackRate = ownedRate.value;
    });
    emitState("ratechange", true);
  }, { signal });
  video.addEventListener("ended", () => {
    emitPlayerEvent("ended", { state: playerState() });
    void callApi(ext.runtime, "sendMessage", { type: "ytze-player-ended" }).catch(() => {});
  }, { signal });
  video.addEventListener("enterpictureinpicture", () => emitState("enterpictureinpicture", true), { signal });
  video.addEventListener("leavepictureinpicture", () => emitState("leavepictureinpicture", true), { signal });
  document.addEventListener("fullscreenchange", () => { update(); emitState("fullscreenchange", true); }, { signal });
  const interval = window.setInterval(update, 250);
  qualityInterval = window.setInterval(applyPreferredQuality, 5_000);
  refreshPlayerMode();
  ownedRate.reset(playbackSettings().rate, nativeLivePlayback());
  video.playbackRate = ownedRate.value;
  if (!previewEmbed) {
    applyCaptionPreferences(playbackSettings().captions);
    renderCaptionLanguageMenu();
    scheduleCaptionDefaults(800);
  }
  const removeLandscapeFullscreen = previewEmbed ? () => {} : installLandscapeFullscreen(video);
  applyPreferredQuality();
  update();
  emitPlayerEvent("ready", { state: playerState() });
  return {
    capture: requestCapture,
    applyContext,
    command: executeCommand,
    setMode: (mode: EmbeddedPlayerMode) => {
      requestedPlayerMode = mode === "live" || mode === "shorts" ? mode : "standard";
      contentTypeAuthoritative = false;
      refreshPlayerMode();
      if (requestedPlayerMode === "shorts") {
        setCaptionMenuOpen(false);
        (shadow.activeElement as HTMLElement | null)?.blur?.();
        hideControls();
      } else showControls();
      update();
    },
    setContentType,
    setHidden: (hidden: boolean) => host.classList.toggle("capture-hidden", hidden),
    destroy: () => {
      clearInterval(interval);
      clearInterval(qualityInterval);
      clearTimeout(toastTimer);
      clearTimeout(idleTimer);
      temporaryBoostController?.reset();
      temporaryBoostController = null;
      clearTimeout(captionDefaultTimer);
      document.removeEventListener("keydown", onKey, true);
      document.removeEventListener("mousemove", showControls);
      removeLandscapeFullscreen();
      lifecycle.abort();
      document.documentElement.classList.remove("ytze-active", "ytze-replace-controls", "ytze-idle");
      host.remove();
    },
  };
}

function applyCaptionPreferences(captions: { style: { fontSizePx: number; color: string; backgroundOpacityPercent: number } }) {
  document.documentElement.style.setProperty("--ytze-caption-size", `${captions.style.fontSizePx}px`);
  document.documentElement.style.setProperty("--ytze-caption-color", captions.style.color);
  document.documentElement.style.setProperty("--ytze-caption-background", `rgba(0,0,0,${captions.style.backgroundOpacityPercent / 100})`);
}

function renderMarkers(context: EnhanceContext) {
  const controllerHost = document.querySelector<HTMLElement>("#ytze-player-controls");
  const root = controllerHost?.shadowRoot;
  const markers = root?.querySelector<HTMLElement>(".markers");
  if (!markers || context.video.duration <= 0) return;
  markers.replaceChildren();
  for (const chapter of context.playback.chapters) {
    if (chapter.start <= 0 || chapter.start >= context.video.duration) continue;
    const marker = document.createElement("i");
    marker.className = "chapter-marker";
    marker.style.left = `${chapter.start / context.video.duration * 100}%`;
    markers.append(marker);
  }
  if (remoteConfig?.sponsorBlock.enabled) for (const segment of context.playback.sponsorBlockSegments) {
    const marker = document.createElement("i");
    marker.className = "sponsor-marker";
    marker.style.left = `${segment.segment[0] / context.video.duration * 100}%`;
    marker.style.width = `${Math.max(.25, (segment.segment[1] - segment.segment[0]) / context.video.duration * 100)}%`;
    marker.style.background = SPONSOR_COLORS[segment.category] ?? "#888888";
    markers.append(marker);
  }
}

const SPONSOR_COLORS: Record<string, string> = {
  sponsor: "#00d400", selfpromo: "#ffff00", interaction: "#cc00ff", intro: "#00ffff",
  outro: "#0202ed", preview: "#008fd6", music_offtopic: "#ff9900", filler: "#7300ab",
};

function installLandscapeFullscreen(video: HTMLVideoElement) {
  if (!remoteConfig?.player.autoFullscreenLandscape || typeof matchMedia !== "function") return () => {};
  const query = matchMedia("(orientation: landscape) and (max-width: 1024px)");
  const enter = () => {
    if (!query.matches || document.fullscreenElement) return;
    const safariVideo = video as HTMLVideoElement & { webkitEnterFullscreen?: () => void };
    void document.documentElement.requestFullscreen?.().catch(() => safariVideo.webkitEnterFullscreen?.());
  };
  query.addEventListener?.("change", enter);
  return () => query.removeEventListener?.("change", enter);
}

addApiListener(ext?.runtime?.onMessage, (message: any, _sender: any, sendResponse: (value: any) => void) => {
  const respond = (value: any) => { try { sendResponse(value); } catch {} };
  if (message?.type === "ytze-execute-player-command" && playerController) {
    const command = validatePlayerCommand(message.command);
    if (!command || command.videoId !== youtubeVideoId(location.href)) { respond({ ok: false, error: "Invalid player command" }); return; }
    void playerController.command(command).then(respond, (error) => respond({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === "ytze-trigger-capture" && playerController) {
    void playerController.capture().then(respond, (error) => respond({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === "ytze-capture-with-settings" && playerController) {
    void playerController.capture(message.request).then(respond, (error) => respond({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === "ytze-apply-context" && playerController) {
    const context = validateEnhanceContext(message.context);
    if (context && context.video.id === youtubeVideoId(location.href)) playerController.applyContext(context, message.contentTypeAuthoritative === true);
    respond({ ok: Boolean(context) });
  }
  if (message?.type === "ytze-apply-player-mode" && playerController) {
    const mode: EmbeddedPlayerMode = message.mode === "live" || message.mode === "shorts" ? message.mode : "standard";
    playerController.setMode(mode);
    respond({ ok: true, mode });
  }
  if (message?.type === "ytze-request-context" && window.top === window && activeInstanceUrl && configuredPageMatches(location.href, activeInstanceUrl)) {
    document.dispatchEvent(new Event(ENHANCE_BRIDGE_EVENTS.ready));
    respond({ ok: true });
  }
  if (message?.type === "ytze-capture-visibility" && playerController) { playerController.setHidden(Boolean(message.hidden)); respond({ ok: true }); }
  if (message?.type === "ytze-resolve-frame" && window.top === window) {
    const frames = [...document.querySelectorAll<HTMLIFrameElement>("iframe")];
    const frame = frames.find((item) => youtubeVideoId(item.src) === message.videoId && visible(item))
      ?? frames.find((item) => youtubeVideoId(item.src) === message.videoId);
    if (!frame) { respond({ rect: null }); return; }
    const outer = frame.getBoundingClientRect();
    const inner = message.innerRect;
    const viewport = message.innerViewport;
    const scaleX = outer.width / Math.max(1, viewport.width);
    const scaleY = outer.height / Math.max(1, viewport.height);
    respond({ rect: {
      x: outer.x + inner.x * scaleX,
      y: outer.y + inner.y * scaleY,
      width: inner.width * scaleX,
      height: inner.height * scaleY,
    }});
  }
  if (message?.type === "ytze-crop-download" && window.top === window) {
    void cropAndDownload(message).then(() => respond({ ok: true }), (error) => respond({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === "ytze-exit-fullscreen" && window.top === window) {
    if (document.fullscreenElement) document.exitFullscreen?.().catch(() => {});
    respond({ ok: true });
  }
  if (message?.type === "ytze-dispatch-page-shortcut" && window.top === window && ["shorts-prev", "shorts-next"].includes(message.key)) {
    const key = message.key === "shorts-prev" ? "ArrowUp" : "ArrowDown";
    const code = key;
    document.dispatchEvent(new KeyboardEvent("keydown", { key, code, bubbles: true }));
    respond({ ok: true });
  }
  if (message?.type === "ytze-dispatch-player-event" && window.top === window) {
    dispatchPlayerEvent(message.event);
    if (message.event?.type === "captions-toggle-request") {
      document.dispatchEvent(new CustomEvent(ENHANCE_PLAYER_EVENTS.captionsToggleRequest, {
        detail: JSON.stringify({ version: 1, videoId: message.event.videoId, ...message.event.payload }),
      }));
    }
    respond({ ok: true });
  }
});

function visible(element: HTMLElement) {
  const rect = element.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0 && rect.bottom > 0 && rect.right > 0 && rect.top < innerHeight && rect.left < innerWidth;
}

async function cropAndDownload(message: any) {
  const image = new Image();
  image.src = message.imageUrl;
  await image.decode();
  const scaleX = image.naturalWidth / innerWidth;
  const scaleY = image.naturalHeight / innerHeight;
  const rect = message.rect;
  const sx = Math.max(0, Math.round(rect.x * scaleX));
  const sy = Math.max(0, Math.round(rect.y * scaleY));
  const sw = Math.min(image.naturalWidth - sx, Math.max(1, Math.round(rect.width * scaleX)));
  const sh = Math.min(image.naturalHeight - sy, Math.max(1, Math.round(rect.height * scaleY)));
  const canvas = document.createElement("canvas");
  canvas.width = sw;
  canvas.height = sh;
  const context = canvas.getContext("2d");
  if (!context) throw new Error(t("canvasUnavailable"));
  context.drawImage(image, sx, sy, sw, sh, 0, 0, sw, sh);
  const mime = message.format === "jpeg" ? "image/jpeg" : message.format === "webp" ? "image/webp" : "image/png";
  const blob = await new Promise<Blob>((resolve, reject) => canvas.toBlob((value) => value ? resolve(value) : reject(new Error(t("imageEncodingFailed"))), mime, message.quality));
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = message.filename;
  link.style.display = "none";
  document.documentElement.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30_000);
}

const CONTROL_STYLES = `
  :host { position: fixed; z-index: 2147483647; inset: 0; pointer-events: none; font: 400 14px "Roboto", -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif; color: #fff; }
  :host(.capture-hidden) { opacity: 0 !important; }
  .controls { position: absolute; left: 0; right: 0; bottom: 0; padding: 26px 12px 8px; background: linear-gradient(to top, rgba(0,0,0,.85), rgba(0,0,0,.4) 60%, transparent); opacity: 0; transition: opacity .2s ease; pointer-events: none; }
  :host(.visible) .controls, .controls:focus-within { opacity: 1; pointer-events: auto; }
  .buttons { display: flex; align-items: center; gap: 4px; margin-top: 2px; }
  button { display: inline-flex; align-items: center; justify-content: center; color: inherit; background: transparent; border: 0; border-radius: 6px; width: 38px; height: 34px; padding: 0; font: inherit; cursor: pointer; opacity: .92; }
  button:hover { opacity: 1; background: rgba(255,255,255,.14); }
  button.active { opacity: 1; background: rgba(255,255,255,.2); }
  button[hidden] { display: none; }
  button:focus-visible, input:focus-visible, .progress:focus-visible { outline: 2px solid #3ea6ff; outline-offset: 2px; }
  button svg { width: 20px; height: 20px; fill: none; stroke: currentColor; stroke-width: 1.8; stroke-linecap: round; stroke-linejoin: round; }
  .play svg path, .play svg rect, .big-play svg path { fill: currentColor; stroke: none; }
  .big-play { position: absolute; left: 50%; top: 50%; transform: translate(-50%,-50%); width: 68px; height: 68px; border-radius: 50%; background: rgba(0,0,0,.65); pointer-events: auto; opacity: 1; transition: background .15s ease, transform .15s ease; }
  .big-play:hover { background: rgba(0,0,0,.85); transform: translate(-50%,-50%) scale(1.06); }
  .big-play svg { width: 30px; height: 30px; }
  .big-play[hidden] { display: none; }
  .time { margin-left: 8px; white-space: nowrap; font-size: 12.5px; font-variant-numeric: tabular-nums; color: rgba(255,255,255,.95); }
  .live-edge { width: auto; min-width: 68px; padding: 0 10px; gap: 7px; color: rgba(255,255,255,.78); font-size: 11px; font-weight: 750; letter-spacing: .04em; }
  .live-edge.active { color: #fff; background: rgba(242,41,58,.24); }
  .live-dot { width: 8px; height: 8px; border-radius: 50%; background: #f2293a; box-shadow: 0 0 0 0 rgba(242,41,58,.7); }
  .live-edge.active .live-dot { animation: live-pulse 1.6s ease-out infinite; }
  @keyframes live-pulse { 70% { box-shadow: 0 0 0 7px rgba(242,41,58,0); } 100% { box-shadow: 0 0 0 0 rgba(242,41,58,0); } }
  .spacer { flex: 1; }
  input[type=range] { accent-color: #fff; cursor: pointer; }
  .progress { position: relative; height: 16px; display: flex; align-items: center; cursor: pointer; touch-action: none; }
  .progress.unavailable { opacity: .35; pointer-events: none; }
  .progress-track { position: relative; width: 100%; height: 3px; border-radius: 2px; background: rgba(255,255,255,.25); overflow: hidden; transition: height .12s ease; }
  .progress:hover .progress-track, .progress:focus-visible .progress-track { height: 5px; }
  .buffered, .played { position: absolute; inset: 0 auto 0 0; }
  .buffered { background: rgba(255,255,255,.35); }
  .played { background: #f2293a; z-index: 2; }
  .markers { position: absolute; inset: 0; pointer-events: none; z-index: 1; }
  .markers i { position: absolute; top: 0; bottom: 0; display: block; pointer-events: auto; }
  .chapter-marker { width: 2px; background: rgba(0,0,0,.7); }
  .sponsor-marker { min-width: 2px; border-radius: 2px; background: #00d400; opacity: .9; }
  .knob { position: absolute; top: 50%; width: 12px; height: 12px; border-radius: 50%; background: #f2293a; transform: translate(-50%,-50%) scale(0); transition: transform .12s ease; pointer-events: none; z-index: 3; }
  .progress:hover .knob, .progress:focus-visible .knob { transform: translate(-50%,-50%) scale(1); }
  .progress-tooltip { position: absolute; bottom: 22px; transform: translateX(-50%); padding: 4px 8px; border-radius: 5px; background: rgba(0,0,0,.85); color: #fff; font-size: 11.5px; white-space: nowrap; display: flex; flex-direction: column; align-items: center; gap: 2px; opacity: 0; pointer-events: none; }
  .progress-tooltip.show { opacity: 1; }
  .chapter { max-width: 220px; overflow: hidden; text-overflow: ellipsis; font-weight: 500; }
  .volume-wrap { display: flex; align-items: center; }
  .volume { width: 0; opacity: 0; transition: width .18s ease, opacity .18s ease; }
  .volume-wrap:hover .volume, .volume:focus-visible { width: 64px; opacity: 1; }
  .caption-menu-wrap { position: relative; display: flex; }
  .caption-menu { position: absolute; right: 0; bottom: 42px; width: 230px; max-height: min(300px, 70vh); padding: 7px; display: flex; flex-direction: column; gap: 8px; color: #fff; background: rgba(22,22,27,.98); border-radius: 14px; box-shadow: 0 18px 42px rgba(0,0,0,.58); pointer-events: auto; overflow: hidden; }
  .caption-menu[hidden] { display: none; }
  .caption-toggle { display: flex; align-items: center; justify-content: space-between; padding: 5px 5px 9px; border-bottom: 1px solid rgba(255,255,255,.09); color: rgba(255,255,255,.72); font-size: 12px; }
  button.caption-switch { position: relative; width: 32px; height: 18px; padding: 0; border-radius: 999px; background: rgba(255,255,255,.22); opacity: 1; }
  button.caption-switch:hover { background: rgba(255,255,255,.3); }
  button.caption-switch.active { background: #3ea6ff; }
  .caption-switch span { position: absolute; left: 3px; top: 3px; width: 12px; height: 12px; border-radius: 50%; background: #fff; transition: transform .16s ease; }
  .caption-switch.active span { transform: translateX(14px); }
  .caption-list { min-height: 0; overflow-y: auto; overscroll-behavior: contain; scrollbar-color: rgba(255,255,255,.28) transparent; padding-top: 4px; }
  .caption-list button { display: flex; align-items: center; justify-content: space-between; gap: 8px; width: 100%; height: auto; min-height: 32px; padding: 7px 8px; border-radius: 8px; color: #fff; font-size: 13px; text-align: left; opacity: 1; }
  .caption-list button:hover { background: rgba(255,255,255,.09); }
  .caption-list button.is-selected { color: #3ea6ff; font-weight: 500; background: color-mix(in srgb, #3ea6ff 14%, transparent); }
  .caption-option-status { display: inline-flex; align-items: center; justify-content: flex-end; min-width: 14px; font-size: 14px; }
  .toast { position: absolute; left: 50%; bottom: 74px; transform: translate(-50%, 5px) scale(.94); padding: 7px 10px; border-radius: 999px; background: rgba(10,10,10,.62); color: #fff; backdrop-filter: blur(7px); opacity: 0; transition: .18s ease; max-width: 80vw; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-size: 13px; font-weight: 650; }
  .toast.show { opacity: 1; transform: translate(-50%, 0); }
  :host(.mode-live) .controls { background: linear-gradient(to top, rgba(8,8,10,.94), rgba(8,8,10,.48) 62%, transparent); }
  :host(.mode-live) .time { display: none; }
  :host(.mode-live) .played, :host(.mode-live) .knob { background: #f2293a; }
  :host(.mode-shorts) .controls { left: calc(var(--ytze-short-left, 0px) + 7px); right: calc(var(--ytze-short-right, 0px) + 7px); bottom: calc(7px + env(safe-area-inset-bottom, 0px)); padding: 38px max(9px, env(safe-area-inset-right, 0px)) max(8px, env(safe-area-inset-bottom, 0px)) max(9px, env(safe-area-inset-left, 0px)); border-radius: 18px; background: linear-gradient(to top, rgba(8,8,10,.92), rgba(8,8,10,.46) 64%, transparent); }
  :host(.mode-shorts) .buttons { gap: 7px; }
  :host(.mode-shorts) .buttons > button, :host(.mode-shorts) .volume-wrap > button, :host(.mode-shorts) .caption-menu-wrap > button { width: 40px; height: 40px; border-radius: 50%; background: rgba(20,20,24,.58); backdrop-filter: blur(8px); }
  :host(.mode-shorts) .buttons > button:hover, :host(.mode-shorts) .volume-wrap > button:hover, :host(.mode-shorts) .caption-menu-wrap > button:hover { background: rgba(255,255,255,.2); }
  :host(.mode-shorts) .volume, :host(.mode-shorts) .time, :host(.mode-shorts) .pip { display: none; }
  :host(.mode-shorts) .progress { height: 12px; }
  :host(.mode-shorts) .progress-track { height: 2px; }
  :host(.mode-shorts) .progress:hover .progress-track, :host(.mode-shorts) .progress:focus-visible .progress-track { height: 4px; }
  :host(.mode-shorts) .caption-menu { bottom: 48px; max-height: min(260px, 58vh); }
  :host(.mode-shorts) .toast { bottom: 78px; }
  :host(.mode-shorts) .big-play { width: 58px; height: 58px; background: rgba(12,12,15,.58); backdrop-filter: blur(8px); }
  :host(.mode-shorts):not(.visible) .big-play { display: none; }
  @media (max-width: 480px) { .time, .pip { display: none; } .buttons { gap: 1px; } button { width: 34px; } .controls { padding-inline: 8px; } }
  @media (prefers-reduced-motion: reduce) { .controls, .toast, .knob, .progress-track { transition: none; } .live-edge.active .live-dot { animation: none; } }
  :host(.mode-preview) .controls {
    align-items: center;
    background:
      linear-gradient(
        to top,
        rgba(0, 0, 0, 0.85),
        rgba(0, 0, 0, 0.4) 60%,
        transparent
      );
    bottom: 0;
    display: flex;
    gap: 8px;
    left: 0;
    opacity: 1;
    padding: 18px 8px 7px;
    pointer-events: auto;
    right: 0;
  }

  :host(.mode-preview) .progress {
    flex: 1;
    height: 16px;
    min-width: 0;
  }

  :host(.mode-preview) .progress-track {
    background: rgba(255, 255, 255, 0.25);
    border-radius: 999px;
    height: 3px;
    overflow: hidden;
    transition: height 0.12s ease;
  }

  :host(.mode-preview) .progress:hover .progress-track,
  :host(.mode-preview) .progress:focus-visible .progress-track {
    height: 5px;
  }

  :host(.mode-preview) .played {
    background: #f2293a;
    border-radius: 999px;
  }

  :host(.mode-preview) .knob {
    background: #f2293a;
    border-radius: 50%;
    height: 12px;
    transform: translate(-50%, -50%) scale(0);
    transition: transform 0.12s ease;
    width: 12px;
  }

  :host(.mode-preview) .progress:hover .knob,
  :host(.mode-preview) .progress:focus-visible .knob {
    transform: translate(-50%, -50%) scale(1);
  }

  :host(.mode-preview) .buttons {
    align-items: center;
    display: flex;
    flex: 0 0 auto;
    gap: 0;
    margin: 0;
  }

  :host(.mode-preview) .buttons > :not(.volume-wrap) {
    display: none;
  }

  :host(.mode-preview) .volume-wrap {
    align-items: center;
    display: flex;
  }

  :host(.mode-preview) .volume {
    display: none;
  }

  :host(.mode-preview) .mute {
    background: transparent;
    border-radius: 6px;
    color: #fff;
    height: 34px;
    min-height: 34px;
    min-width: 38px;
    opacity: 0.92;
    padding: 0;
    width: 38px;
  }

  :host(.mode-preview) .mute:hover,
  :host(.mode-preview) .mute:focus-visible {
    background: rgba(255, 255, 255, 0.14);
    opacity: 1;
  }

  :host(.mode-preview) .mute svg {
    height: 20px;
    width: 20px;
  }

  :host(.mode-preview) .big-play,
  :host(.mode-preview) .play,
  :host(.mode-preview) .time,
  :host(.mode-preview) .live-edge,
  :host(.mode-preview) .spacer,
  :host(.mode-preview) .caption-menu-wrap,
  :host(.mode-preview) .pip,
  :host(.mode-preview) .fullscreen,
  :host(.mode-preview) .volume,
  :host(.mode-preview) .buffered,
  :host(.mode-preview) .markers,
  :host(.mode-preview) .progress-tooltip,
  :host(.mode-preview) .toast {
    display: none !important;
  }

  @media (prefers-reduced-motion: reduce) {
    :host(.mode-preview) .progress-track,
    :host(.mode-preview) .knob {
      transition: none;
    }
  }
`;
