(() => {
  // src/core.ts
  var DEFAULT_SETTINGS = {
    instanceUrl: "",
    redirectEnabled: false,
    enhancePlayer: true,
    replaceControls: true,
    screenshotFormat: "png",
    screenshotQuality: 0.92,
    screenshotFilename: "{channel}_{title}_{timestamp_ms}",
    seekSeconds: 5,
    frameRate: 30
  };
  var VIDEO_ID = /^[A-Za-z0-9_-]{11}$/;
  var CHANNEL_ID = /^UC[A-Za-z0-9_-]{22}$/;
  var PLAYLIST_ID = /^[A-Za-z0-9_-]{10,80}$/;
  var YT_NO_REDIRECT_MARKER = "ytNoRedirect";
  function youtubeUrl(input) {
    try {
      const url = new URL(input);
      const host = url.hostname.replace(/^www\./, "").toLowerCase();
      if (!["youtube.com", "m.youtube.com", "music.youtube.com", "youtube-nocookie.com", "youtu.be"].includes(host))
        return null;
      return /^https?:$/.test(url.protocol) ? url : null;
    } catch {
      return null;
    }
  }
  function localBase(instanceUrl) {
    try {
      const base = new URL(instanceUrl);
      return /^https?:$/.test(base.protocol) ? base : null;
    } catch {
      return null;
    }
  }
  function withInstancePath(instanceUrl, path, search = "") {
    const base = localBase(instanceUrl);
    if (!base)
      return null;
    const prefix = base.pathname.replace(/\/$/, "");
    base.pathname = `${prefix}${path}`.replace(/\/{2,}/g, "/");
    base.search = search;
    base.hash = "";
    return base.toString();
  }
  function hasNoRedirectMarker(input) {
    const url = youtubeUrl(input);
    return Boolean(url?.hash.slice(1).split("&").includes(YT_NO_REDIRECT_MARKER));
  }
  function embeddedPlayerModeForPage(input) {
    try {
      return /\/shorts(?:\/|$)/.test(new URL(input).pathname) ? "shorts" : "standard";
    } catch {
      return "standard";
    }
  }
  function resolveEmbeddedPlayerMode(requested, authoritative, nativeLive) {
    if (requested === "preview")
      return "preview";
    return requested === "live" || !authoritative && nativeLive ? "live" : requested;
  }
  function isPreviewEmbedUrl(input) {
    try {
      const url = new URL(input);
      const host = url.hostname.replace(/^www\./, "").toLowerCase();
      return ["youtube.com", "youtube-nocookie.com"].includes(host) && /^\/embed\/[A-Za-z0-9_-]{11}$/.test(url.pathname) && url.searchParams.get("ytzero_preview") === "1";
    } catch {
      return false;
    }
  }
  function playerTimeline(currentTime, duration, liveRange) {
    const finiteDuration = Number.isFinite(duration) && duration > 0 ? duration : 0;
    const live = liveRange && Number.isFinite(liveRange.start) && Number.isFinite(liveRange.end) && liveRange.end > liveRange.start ? liveRange : null;
    const start = live?.start ?? 0;
    const end = live?.end ?? finiteDuration;
    const length = Math.max(0, end - start);
    const fraction = length ? Math.min(1, Math.max(0, (currentTime - start) / length)) : 0;
    return { start, end, length, fraction, liveDelay: live ? Math.max(0, live.end - currentTime) : null };
  }
  function playableLiveRange(seekableStart, seekableEnd, currentTime, bufferedEnd, observedPlayableEnd, safetySeconds = 0.5) {
    if (!Number.isFinite(seekableStart) || !Number.isFinite(seekableEnd) || seekableEnd <= seekableStart)
      return null;
    const buffered = bufferedEnd != null && Number.isFinite(bufferedEnd) ? bufferedEnd - Math.max(0, safetySeconds) : seekableStart;
    const playableEnd = Math.min(seekableEnd, Math.max(currentTime, observedPlayableEnd, buffered));
    return playableEnd > seekableStart ? { start: seekableStart, end: playableEnd } : null;
  }
  function parseTimestamp(value) {
    if (!value)
      return 0;
    if (/^\d+$/.test(value))
      return Number(value);
    const match = value.toLowerCase().match(/^(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s?)?$/);
    if (!match)
      return 0;
    return Number(match[1] || 0) * 3600 + Number(match[2] || 0) * 60 + Number(match[3] || 0);
  }
  function youtubeVideoId(input) {
    let url;
    try {
      url = new URL(input);
    } catch {
      return null;
    }
    const host = url.hostname.replace(/^www\./, "").toLowerCase();
    let id = null;
    if (host === "youtu.be")
      id = url.pathname.split("/").filter(Boolean)[0] ?? null;
    if (["youtube.com", "m.youtube.com", "music.youtube.com", "youtube-nocookie.com"].includes(host)) {
      if (url.pathname === "/watch")
        id = url.searchParams.get("v");
      else {
        const match = url.pathname.match(/^\/(?:shorts|live|embed)\/([^/?#]+)/);
        id = match?.[1] ?? null;
      }
    }
    return id && VIDEO_ID.test(id) ? id : null;
  }
  function youtubePlaylistId(input) {
    const url = youtubeUrl(input);
    if (!url)
      return null;
    let id = url.pathname === "/playlist" || url.pathname === "/watch" ? url.searchParams.get("list") : null;
    if (!id)
      id = url.pathname.match(/^\/show\/VL([A-Za-z0-9_-]+)(?:\/|$)/)?.[1] ?? null;
    return id && PLAYLIST_ID.test(id) ? id : null;
  }
  function isRedirectableYouTubeUrl(input) {
    const url = youtubeUrl(input);
    if (!url || hasNoRedirectMarker(input))
      return false;
    if (/^\/embed\//.test(url.pathname))
      return false;
    return youtubeVideoId(input) !== null || youtubePlaylistId(input) !== null;
  }
  function localWatchUrl(input, instanceUrl) {
    if (!isRedirectableYouTubeUrl(input))
      return null;
    const id = youtubeVideoId(input);
    if (!id)
      return null;
    let source;
    try {
      source = new URL(input);
    } catch {
      return null;
    }
    const seconds = parseTimestamp(source.searchParams.get("t") ?? source.searchParams.get("start"));
    const playlistId = youtubePlaylistId(input);
    const path = playlistId ? `/watch/${id}/playlist/${encodeURIComponent(playlistId)}` : `/watch/${id}`;
    return withInstancePath(instanceUrl, path, seconds > 0 ? `?t=${seconds}` : "");
  }
  function localContentUrl(input, instanceUrl, resolvedChannelId) {
    const source = youtubeUrl(input);
    if (!source)
      return null;
    const unmarked = new URL(source);
    unmarked.hash = "";
    const video = youtubeVideoId(unmarked.toString());
    if (video && !/^\/embed\//.test(source.pathname))
      return localWatchUrl(unmarked.toString(), instanceUrl);
    const playlistId = youtubePlaylistId(unmarked.toString());
    if (playlistId)
      return withInstancePath(instanceUrl, `/playlist/${encodeURIComponent(playlistId)}`);
    const directChannelId = source.pathname.match(/^\/channel\/([^/?#]+)/)?.[1] ?? "";
    const channelId = resolvedChannelId && CHANNEL_ID.test(resolvedChannelId) ? resolvedChannelId : directChannelId;
    if (CHANNEL_ID.test(channelId))
      return withInstancePath(instanceUrl, `/channel/${channelId}`);
    const channelPath = source.pathname.match(/^\/(?:@([^/?#]+)|(?:c|user)\/([^/?#]+))(?:\/|$)/);
    const channelQuery = channelPath?.[1] ? `@${channelPath[1]}` : channelPath?.[2];
    if (channelQuery)
      return withInstancePath(instanceUrl, "/search", `?q=${encodeURIComponent(channelQuery)}`);
    return null;
  }
  function formatClock(seconds, milliseconds = false) {
    const safe = Math.max(0, Number.isFinite(seconds) ? seconds : 0);
    const hours = Math.floor(safe / 3600);
    const minutes = Math.floor(safe % 3600 / 60);
    const secs = Math.floor(safe % 60);
    const base = `${hours ? `${String(hours).padStart(2, "0")}-` : ""}${String(minutes).padStart(2, "0")}-${String(secs).padStart(2, "0")}`;
    return milliseconds ? `${base}-${String(Math.floor(safe % 1 * 1000)).padStart(3, "0")}` : base;
  }
  function safeFilename(value) {
    const sanitized = value.replace(/[<>:"/\\|?*\u0000-\u001f]/g, "_").replace(/\s+/g, " ").replace(/[. ]+$/g, "").trim().slice(0, 180) || "ytzero-frame";
    return /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(sanitized) ? `_${sanitized}` : sanitized;
  }
  function screenshotFilename(template, values, extension) {
    const seconds = Math.max(0, values.seconds ?? 0);
    const replacements = {
      channel: values.channel || "YouTube",
      title: values.title || values.videoId || "video",
      video_id: values.videoId || "unknown",
      timestamp: formatClock(seconds),
      timestamp_ms: formatClock(seconds, true)
    };
    const expanded = template.replace(/\{(channel|title|video_id|timestamp|timestamp_ms)\}/g, (_, key) => replacements[key]);
    return `${safeFilename(expanded)}.${extension}`;
  }
  function normalizeSettings(input) {
    const merged = { ...DEFAULT_SETTINGS, ...input ?? {} };
    merged.instanceUrl = String(merged.instanceUrl || DEFAULT_SETTINGS.instanceUrl).replace(/\/$/, "");
    merged.screenshotFormat = merged.screenshotFormat === "jpeg" || merged.screenshotFormat === "webp" ? merged.screenshotFormat : "png";
    merged.screenshotQuality = Math.min(1, Math.max(0.1, Number(merged.screenshotQuality) || 0.92));
    merged.seekSeconds = Math.min(60, Math.max(1, Number(merged.seekSeconds) || 5));
    merged.frameRate = Math.min(120, Math.max(1, Number(merged.frameRate) || 30));
    return merged;
  }
  function containedMediaRect(element, mediaWidth, mediaHeight) {
    if (element.width <= 0 || element.height <= 0 || mediaWidth <= 0 || mediaHeight <= 0)
      return element;
    const elementRatio = element.width / element.height;
    const mediaRatio = mediaWidth / mediaHeight;
    if (elementRatio > mediaRatio) {
      const width = element.height * mediaRatio;
      return { x: element.x + (element.width - width) / 2, y: element.y, width, height: element.height };
    }
    const height = element.width / mediaRatio;
    return { x: element.x, y: element.y + (element.height - height) / 2, width: element.width, height };
  }

  // src/shortcuts.ts
  var SHORTCUT_ACTIONS = [
    "togglePlay",
    "temporaryBoost",
    "seekBack10",
    "seekForward10",
    "previousVideo",
    "nextVideo",
    "previousFrame",
    "nextFrame",
    "speedDown",
    "speedUp",
    "seekPercent",
    "previousChapter",
    "nextChapter",
    "seekBack",
    "seekForward",
    "volumeUp",
    "volumeDown",
    "toggleCaptions",
    "subtitleLarger",
    "subtitleSmaller",
    "toggleFullscreen",
    "toggleTheater",
    "togglePictureInPicture",
    "close",
    "toggleMute",
    "screenshot"
  ];
  var DEFAULT_SHORTCUT_BINDINGS = {
    togglePlay: "KeyK",
    temporaryBoost: "Space",
    seekBack10: "KeyJ",
    seekForward10: "KeyL",
    previousVideo: "Shift+KeyP",
    nextVideo: "Shift+KeyN",
    previousFrame: "Comma",
    nextFrame: "Period",
    speedDown: "Shift+Comma",
    speedUp: "Shift+Period",
    seekPercent: "Digit0-9",
    previousChapter: "Alt+ArrowLeft",
    nextChapter: "Alt+ArrowRight",
    seekBack: "ArrowLeft",
    seekForward: "ArrowRight",
    volumeUp: "ArrowUp",
    volumeDown: "ArrowDown",
    toggleCaptions: "KeyC",
    subtitleLarger: "Shift+Equal",
    subtitleSmaller: "Minus",
    toggleFullscreen: "KeyF",
    toggleTheater: "KeyT",
    togglePictureInPicture: "KeyI",
    close: "Escape",
    toggleMute: "KeyM",
    screenshot: "KeyS"
  };
  var ACTION_IDS = new Set(SHORTCUT_ACTIONS);
  var MODIFIER_ORDER = ["Ctrl", "Alt", "Shift", "Meta"];
  var MODIFIERS = new Set(MODIFIER_ORDER);
  var CODE = /^(?:Key[A-Z]|Digit[0-9]|Digit0-9|F(?:[1-9]|1[0-2])|Numpad(?:Add|Subtract)|Arrow(?:Left|Right|Up|Down)|Space|Escape|Enter|Tab|Backspace|Delete|Home|End|PageUp|PageDown|Comma|Period|Minus|Equal|BracketLeft|BracketRight|Semicolon|Quote|Backslash|Slash|Backquote)$/;
  function normalizeShortcutChord(value) {
    if (value === null)
      return null;
    if (typeof value !== "string" || value.length > 80)
      return;
    const parts = value.split("+");
    const code = parts.pop();
    if (!code || !CODE.test(code) || parts.some((part, index) => !MODIFIERS.has(part) || parts.indexOf(part) !== index))
      return;
    return [...MODIFIER_ORDER.filter((modifier) => parts.includes(modifier)), code].join("+");
  }
  function resolveShortcutBindings(value, diagnostic = (message) => console.warn(message)) {
    if (value === undefined)
      return { ...DEFAULT_SHORTCUT_BINDINGS };
    const bindings = Object.fromEntries(SHORTCUT_ACTIONS.map((action) => [action, null]));
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      diagnostic("YT Zero Enhance ignored a malformed keyboard shortcut map");
      return bindings;
    }
    const input = value;
    for (const [action, rawChord] of Object.entries(input)) {
      if (!ACTION_IDS.has(action))
        continue;
      const chord = normalizeShortcutChord(rawChord);
      if (chord === undefined) {
        diagnostic(`YT Zero Enhance disabled malformed keyboard shortcut: ${action}`);
        continue;
      }
      bindings[action] = chord;
    }
    return bindings;
  }
  function shortcutChordFromEvent(event) {
    if (!CODE.test(event.code) || event.code === "Digit0-9")
      return null;
    return [event.ctrlKey && "Ctrl", event.altKey && "Alt", event.shiftKey && "Shift", event.metaKey && "Meta", event.code].filter(Boolean).join("+");
  }
  function shortcutMatches(event, chord) {
    if (!chord)
      return false;
    const eventChord = shortcutChordFromEvent(event);
    if (chord.endsWith("Digit0-9")) {
      const prefix = chord.slice(0, -"Digit0-9".length);
      return /^Digit[0-9]$/.test(event.code) && eventChord === `${prefix}${event.code}`;
    }
    return eventChord === chord;
  }
  function matchingShortcutAction(event, bindings) {
    for (const action of SHORTCUT_ACTIONS)
      if (shortcutMatches(event, bindings[action]))
        return action;
    return null;
  }

  class ShortcutRegistry {
    #bindings = { ...DEFAULT_SHORTCUT_BINDINGS };
    constructor(value = undefined, diagnostic) {
      this.replace(value, diagnostic);
    }
    replace(value, diagnostic) {
      this.#bindings = resolveShortcutBindings(value, diagnostic);
    }
    match(event) {
      return matchingShortcutAction(event, this.#bindings);
    }
    binding(action) {
      return this.#bindings[action];
    }
  }
  function isEditableShortcutEvent(event) {
    const path = typeof event.composedPath === "function" ? event.composedPath() : [event.target];
    return path.some((target) => {
      const element = target;
      const tag = String(element?.tagName ?? "").toLowerCase();
      return tag === "input" || tag === "textarea" || tag === "select" || Boolean(element?.isContentEditable) || Boolean(element?.closest?.("[contenteditable]"));
    });
  }
  var REPEATABLE_ACTIONS = new Set([
    "seekBack10",
    "seekForward10",
    "seekBack",
    "seekForward",
    "volumeUp",
    "volumeDown"
  ]);
  function shortcutAllowsRepeat(action) {
    return REPEATABLE_ACTIONS.has(action);
  }
  var PARENT_OWNED_SHORTCUT_ACTIONS = new Set([
    "previousVideo",
    "nextVideo",
    "toggleTheater",
    "close"
  ]);
  var TRANSPORT_ACTIONS = new Set([
    "togglePlay",
    "temporaryBoost",
    "seekBack10",
    "seekForward10",
    "previousVideo",
    "nextVideo",
    "previousFrame",
    "nextFrame",
    "speedDown",
    "speedUp",
    "seekPercent",
    "previousChapter",
    "nextChapter",
    "seekBack",
    "seekForward"
  ]);
  var LIVESTREAM_BLOCKED_ACTIONS = new Set([
    "temporaryBoost",
    "previousFrame",
    "nextFrame",
    "speedDown",
    "speedUp",
    "seekPercent"
  ]);
  function shortcutOperationBlocked(action, livestream, transportLocked) {
    return transportLocked && TRANSPORT_ACTIONS.has(action) || livestream && LIVESTREAM_BLOCKED_ACTIONS.has(action);
  }
  function stepShortcutPlaybackRate(current, direction) {
    const safeCurrent = Number.isFinite(current) ? current : 1;
    const stepped = Math.round((safeCurrent + direction * 0.25) / 0.25) * 0.25;
    return Math.min(2, Math.max(0.25, stepped));
  }

  class OwnedPlaybackRate {
    #value = 1;
    constructor(rate = 1, livestream = false) {
      this.reset(rate, livestream);
    }
    get value() {
      return this.#value;
    }
    reset(rate, livestream = false) {
      const safeRate = Number.isFinite(rate) ? rate : 1;
      this.#value = livestream ? 1 : Math.min(4, Math.max(0.25, safeRate));
      return this.#value;
    }
    step(direction) {
      this.#value = stepShortcutPlaybackRate(this.#value, direction);
      return this.#value;
    }
  }
  function advanceOwnedPlaybackRate(ownedRate, direction, applyPlaybackRate) {
    const nextRate = ownedRate.step(direction);
    Promise.resolve(applyPlaybackRate(nextRate)).catch(() => {});
    return nextRate;
  }
  function chapterShortcutTarget(action, currentTime, chapters) {
    if (!Number.isFinite(currentTime) || !chapters.length)
      return null;
    const starts = chapters.map((chapter) => chapter.start).filter(Number.isFinite).sort((a, b) => a - b);
    if (!starts.length)
      return null;
    if (action === "previousChapter")
      return [...starts].reverse().find((start) => start < currentTime - 1) ?? 0;
    return starts.find((start) => start > currentTime + 1) ?? null;
  }
  function shortcutEventPayload(action, event, value) {
    return {
      action,
      key: event.key,
      code: event.code,
      repeat: event.repeat,
      ...typeof value === "number" ? { value } : {},
      modifiers: { alt: event.altKey, ctrl: event.ctrlKey, meta: event.metaKey, shift: event.shiftKey }
    };
  }

  class TemporaryBoostController {
    dependencies;
    #timer = 0;
    #active = false;
    #chord = null;
    #event = null;
    constructor(dependencies) {
      this.dependencies = dependencies;
    }
    get active() {
      return this.#active;
    }
    get pending() {
      return this.#timer !== 0;
    }
    get chord() {
      return this.#chord;
    }
    keydown(event) {
      if (event.repeat || this.#timer || this.#active || this.dependencies.isBlocked())
        return;
      this.#chord = shortcutChordFromEvent(event);
      this.#event = event;
      this.#timer = this.dependencies.schedule(() => {
        this.#timer = 0;
        if (this.dependencies.isBlocked()) {
          this.#chord = null;
          this.#event = null;
          return;
        }
        this.#active = true;
        this.dependencies.setRate(2);
        if (this.#event)
          this.dependencies.applied(this.#event, 2);
      }, 220);
    }
    keyup(event) {
      if (!this.#chord || shortcutChordFromEvent(event) !== this.#chord)
        return false;
      const pressedEvent = this.#event;
      this.#chord = null;
      this.#event = null;
      if (this.#timer) {
        this.dependencies.cancel(this.#timer);
        this.#timer = 0;
        this.dependencies.togglePlay();
        if (pressedEvent)
          this.dependencies.applied(pressedEvent);
      } else if (this.#active) {
        this.#active = false;
        this.dependencies.setRate(this.dependencies.effectiveRate());
      }
      return true;
    }
    reset() {
      if (this.#timer)
        this.dependencies.cancel(this.#timer);
      if (this.#active)
        this.dependencies.setRate(this.dependencies.effectiveRate());
      this.#timer = 0;
      this.#active = false;
      this.#chord = null;
      this.#event = null;
    }
  }

  // src/i18n.ts
  var EN = {
    tagline: "Your videos, your settings",
    extensionState: "Extension status",
    firstRun: "First run",
    connectInstance: "Connect your instance",
    onboardingLead: "Open any page on your YT Zero instance. Once it is loaded, return here and connect the active tab.",
    pairingAria: "How to connect YT Zero",
    stepOpenInstance: "Open your YT Zero instance",
    stepClickBelow: "Click the button below",
    pairThisTab: "Connect this tab",
    defaultInstance: "Default instance",
    settingsSynced: "Settings synchronized",
    quickSettings: "Quick extension settings",
    redirectLinks: "Redirect links",
    redirectLinksDescription: "Supported video and playlist links will open in the default instance",
    redirectTo: "Redirect to",
    enhancePlayer: "Enhance the player",
    enhancePlayerDescription: "Appearance and behavior consistent with YT Zero",
    saveFrame: "Save frame",
    openYtZero: "Open YT Zero",
    pairAnother: "+ Connect the current tab as another instance",
    instancesAndSettings: "Instances and settings",
    browserExtension: "Browser extension",
    optionsIntro: "Connected instances and active profile settings.",
    connectFirstInstance: "Connect your first instance",
    connectFirstHelp: "Open any page on YT Zero, click the extension icon and choose “Connect this tab”.",
    yourYtZero: "Your YT Zero",
    connectedInstances: "Connected instances",
    addAnotherHelp: "To add another one, open it and use the extension icon.",
    playerSettings: "Player settings",
    changeInYtZero: "Change in YT Zero",
    readonlyNote: "These values come from the active YT Zero profile and are read-only here.",
    integration: "Integration",
    ytZeroControls: "YT Zero controls",
    quality: "Quality",
    speed: "Speed",
    seek: "Seeking",
    frameStep: "Frame stepping",
    captions: "Captions",
    screenshots: "Screenshots",
    defaultInstanceTip: "Redirected video links go to this instance. The player on every connected instance uses its own profile.",
    connectYtZero: "Connect to YT Zero",
    enhancementsDisabled: "Enhancements are disabled in YT Zero",
    findingSettings: "Looking for YT Zero settings in this tab…",
    openPageFirst: "Open a page on your YT Zero instance first.",
    openSpecificPage: "Open a page on your YT Zero instance and try again.",
    settingsNotReady: "YT Zero has not exposed its settings yet. Wait for the page to load and try again.",
    permissionNeeded: "Access to this instance is required to synchronize settings.",
    pairFailed: "Could not connect the instance.",
    pairedReloading: "Connected. Reloading the page…",
    saved: "Saved",
    capturing: "Capturing…",
    frameSaved: "Frame saved",
    noActivePlayer: "No active player",
    enabled: "Enabled",
    disabled: "Disabled",
    automatic: "Automatic",
    disabledByDefault: "Disabled by default",
    category: "category",
    categories: "categories",
    defaultBadge: "Default",
    open: "Open",
    makeDefault: "Make default",
    remove: "Remove",
    settings: "Settings",
    seconds: "seconds",
    defaultChanged: "Default instance changed.",
    instanceRemoved: "Instance removed.",
    removeConnection: "Remove connection to",
    play: "Play",
    playPause: "Play or pause",
    mute: "Mute",
    volume: "Volume",
    progress: "Video position",
    playerControls: "YT Zero player",
    captionsShortcut: "Captions (C)",
    saveFrameShortcut: "Save frame (S)",
    firefoxCaptureShortcut: "In Firefox, use Alt+Shift+S (physical Control+Shift+S on macOS) to save a frame.",
    cinemaMode: "Cinema mode",
    cinemaModeShortcut: "Cinema mode (T)",
    pictureInPicture: "Picture in picture",
    fullscreen: "Fullscreen",
    live: "LIVE",
    goLive: "Go live",
    captionsUnavailable: "Captions unavailable",
    invalidCaptionLanguage: "Invalid caption language",
    pipUnavailable: "Picture in picture unavailable",
    captureError: "Capture error",
    unknown: "unknown",
    skipped: "Skipped",
    oneFrameBack: "−1 frame",
    oneFrameForward: "+1 frame",
    canvasUnavailable: "Canvas unavailable",
    imageEncodingFailed: "Image encoding failed",
    embeddedSettingsReadFailed: "Could not read the settings embedded on the YT Zero page.",
    unknownConfigurationFormat: "The instance returned an unknown YT Zero Enhance configuration format.",
    invalidConfigurationVersion: "The instance returned an invalid configuration version.",
    newerExtensionRequired: "This configuration requires a newer extension version.",
    unsupportedBridge: "The instance uses an unsupported YT Zero Enhance bridge version.",
    incompatibleBridgeEvents: "The instance returned incompatible bridge event names.",
    invalidPlayerFrame: "Invalid player frame",
    missingQualityConfiguration: "Missing quality configuration",
    unpairedPage: "This YT Zero page is not connected to the extension",
    pairingOnlyFromExtension: "Pairing can only be started from the extension window",
    invalidInstanceAddress: "Could not recognize the instance address",
    pairedInstanceNotFound: "Connected instance not found",
    invalidBridgeContext: "Invalid bridge context",
    invalidScreenshotRequest: "Invalid bridge screenshot request",
    activeEmbeddedPlayerNotFound: "No active embedded player found",
    activeTabNotFound: "No active tab found",
    captureOutsideYouTubeRejected: "A capture outside the embedded player was rejected",
    playerPositionFailed: "Could not determine the player position"
  };
  function uiLanguage() {
    let language = globalThis.navigator?.language || "en";
    try {
      language = (globalThis.browser ?? globalThis.chrome)?.i18n?.getUILanguage?.() || language;
    } catch {}
    return /^pl\b/i.test(language) ? "pl" : /^de\b/i.test(language) ? "de" : "en";
  }
  function t(key) {
    try {
      const localized = (globalThis.browser ?? globalThis.chrome)?.i18n?.getMessage?.(key);
      return localized || EN[key] || key;
    } catch {
      return EN[key] || key;
    }
  }
  function localizeDocument(root = document) {
    if (typeof document !== "undefined")
      document.documentElement.lang = uiLanguage();
    root.querySelectorAll("[data-i18n]").forEach((element) => {
      element.textContent = t(element.dataset.i18n);
    });
    root.querySelectorAll("[data-i18n-aria]").forEach((element) => {
      element.setAttribute("aria-label", t(element.dataset.i18nAria));
    });
    root.querySelectorAll("[data-i18n-title]").forEach((element) => {
      element.title = t(element.dataset.i18nTitle);
    });
  }

  // src/contract.ts
  var ENHANCE_CONFIGURATION_FORMAT = "ytzero.enhance-configuration";
  var ENHANCE_CONFIGURATION_VERSION = 1;
  var MAX_CONFIGURATION_DETAIL_LENGTH = 256000;
  var MAX_CONTEXT_DETAIL_LENGTH = 256000;
  var MAX_SCREENSHOT_DETAIL_LENGTH = 16384;
  var MAX_COMMAND_DETAIL_LENGTH = 8192;
  var ENHANCE_BRIDGE_EVENTS = {
    ready: "ytzero:enhance:ready",
    context: "ytzero:enhance:context",
    screenshotRequest: "ytzero:enhance:screenshot-request",
    screenshotResult: "ytzero:enhance:screenshot-result"
  };
  var ENHANCE_PLAYER_EVENTS = {
    captionsToggleRequest: "ytzero:enhance:captions-toggle-request",
    event: "ytzero:enhance:player-event",
    command: "ytzero:enhance:player-command"
  };
  var ENHANCE_PLAYER_COMMANDS = [
    "play",
    "pause",
    "toggle-play",
    "seek-by",
    "seek-to",
    "set-volume",
    "set-muted",
    "toggle-muted",
    "set-playback-rate",
    "set-captions",
    "toggle-captions",
    "set-caption-size",
    "capture-frame",
    "toggle-fullscreen",
    "enter-fullscreen",
    "exit-fullscreen",
    "toggle-picture-in-picture",
    "request-state"
  ];
  var CONTENT_TYPES = ["default", "short", "livestream"];
  function playerPresentationState(localEnabled, localReplaceControls, configuration, nativeControlsVisible) {
    const active = localEnabled && configuration?.enabled === true;
    return { active, replaceControls: active && localReplaceControls && configuration.player.replaceControls && !nativeControlsVisible };
  }
  function embeddedPlayerParameters(configuration) {
    return {
      hl: configuration.player.language,
      controls: configuration.player.replaceControls ? "0" : "1",
      disablekb: configuration.player.replaceControls ? "1" : "0",
      iv_load_policy: "3",
      playsinline: "1",
      modestbranding: "1",
      rel: "0"
    };
  }
  var PLAYBACK_QUALITY_ORDER = ["highres", "hd4320", "hd2880", "hd2160", "hd1440", "hd1080", "hd720", "large", "medium", "small", "tiny"];
  function highestQualityAtOrBelow(available, maximum) {
    if (!Array.isArray(available))
      return null;
    const levels = available.filter((value) => typeof value === "string" && PLAYBACK_QUALITY_ORDER.includes(value));
    if (!levels.length)
      return null;
    const maximumIndex = maximum === "auto" ? 0 : PLAYBACK_QUALITY_ORDER.indexOf(maximum);
    const threshold = maximumIndex < 0 ? 0 : maximumIndex;
    return PLAYBACK_QUALITY_ORDER.slice(threshold).find((quality) => levels.includes(quality)) ?? null;
  }
  var VIDEO_ID2 = /^[A-Za-z0-9_-]{11}$/;
  var COLOR = /^#[0-9a-f]{6}$/i;
  var QUALITY = /^[A-Za-z0-9_-]{1,32}$/;
  var object = (value) => value && typeof value === "object" && !Array.isArray(value) ? value : null;
  function isContentType(value) {
    return CONTENT_TYPES.includes(value);
  }
  function normalizeContentType(value, legacyFallback) {
    return isContentType(value) ? value : legacyFallback;
  }
  function validatePlayerCommand(value) {
    const root = object(value);
    if (root?.version !== 1 || typeof root.requestId !== "string" || !root.requestId.trim() || root.requestId.length > 120 || typeof root.videoId !== "string" || !VIDEO_ID2.test(root.videoId) || !ENHANCE_PLAYER_COMMANDS.includes(root.command))
      return null;
    const input = object(root.payload) ?? {};
    let payload = {};
    if (root.command === "seek-by" || root.command === "seek-to")
      payload = { seconds: finite(input.seconds, 0, -86400 * 30, 86400 * 30) };
    else if (root.command === "set-volume")
      payload = { volume: finite(input.volume, 1, 0, 1) };
    else if (root.command === "set-muted" || root.command === "set-captions")
      payload = { enabled: input.enabled === true };
    else if (root.command === "set-playback-rate")
      payload = { rate: finite(input.rate, 1, 0.25, 4) };
    else if (root.command === "set-caption-size")
      payload = { pixels: finite(input.pixels, 19, 12, 48) };
    return { version: 1, requestId: root.requestId.trim(), videoId: root.videoId, command: root.command, payload };
  }
  function validatePlayerEvent(value) {
    const root = object(value);
    const types = ["ready", "state", "shortcut", "captions-toggle-request", "ended", "command-result"];
    if (root?.version !== 1 || typeof root.videoId !== "string" || !VIDEO_ID2.test(root.videoId) || typeof root.type !== "string" || !types.includes(root.type))
      return null;
    return { version: 1, videoId: root.videoId, type: root.type, timestamp: finite(root.timestamp, Date.now(), 0, Number.MAX_SAFE_INTEGER), payload: object(root.payload) ?? {} };
  }
  var finite = (value, fallback, min, max) => {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? Math.min(max, Math.max(min, parsed)) : fallback;
  };
  var text = (value, fallback, max = 200) => typeof value === "string" && value.trim() ? value.trim().slice(0, max) : fallback;
  var format = (value, fallback = "png") => value === "jpeg" || value === "webp" || value === "png" ? value : fallback;
  var style = (value) => {
    const input = object(value) ?? {};
    return {
      fontSizePx: finite(input.fontSizePx, 19, 12, 48),
      color: typeof input.color === "string" && COLOR.test(input.color) ? input.color : "#ffffff",
      backgroundOpacityPercent: finite(input.backgroundOpacityPercent, 75, 0, 100)
    };
  };
  function captionLanguages(value) {
    return Array.isArray(value) ? value.flatMap((entry) => {
      if (!entry || typeof entry !== "object")
        return [];
      const language = entry;
      if (typeof language.code !== "string" || typeof language.label !== "string")
        return [];
      const code = language.code.trim().slice(0, 32);
      const label = language.label.trim().slice(0, 120);
      return code && label ? [{ code, label }] : [];
    }).slice(0, 250) : [];
  }
  function configuredPageMatches(pageUrl, instanceUrl) {
    try {
      const page = new URL(pageUrl);
      const instance = new URL(instanceUrl);
      const prefix = instance.pathname.replace(/\/$/, "");
      return page.origin === instance.origin && (page.pathname === prefix || page.pathname.startsWith(`${prefix}/`));
    } catch {
      return false;
    }
  }
  function hostPermissionPattern(instanceUrl) {
    try {
      const url = new URL(instanceUrl);
      return /^https?:$/.test(url.protocol) ? `${url.origin}/*` : null;
    } catch {
      return null;
    }
  }
  function validateEnhanceConfiguration(value) {
    const root = object(value);
    if (!root || root.format !== ENHANCE_CONFIGURATION_FORMAT)
      return { ok: false, diagnostic: t("unknownConfigurationFormat") };
    const version = Number(root.version);
    if (!Number.isInteger(version) || version < 1)
      return { ok: false, diagnostic: t("invalidConfigurationVersion") };
    if (version > ENHANCE_CONFIGURATION_VERSION)
      return { ok: false, diagnostic: `${t("newerExtensionRequired")} (v${version})`, unsupportedVersion: version };
    const player = object(root.player) ?? {};
    const captions = object(player.captions) ?? {};
    const screenshots = object(root.screenshots) ?? {};
    const sponsorBlock = object(root.sponsorBlock) ?? {};
    const bridge = object(root.bridge) ?? {};
    if (bridge.version !== 1 || bridge.detailEncoding !== "json-string")
      return { ok: false, diagnostic: t("unsupportedBridge") };
    const eventInput = object(bridge.events) ?? {};
    if (Object.entries(ENHANCE_BRIDGE_EVENTS).some(([key, name]) => eventInput[key] !== name))
      return { ok: false, diagnostic: t("incompatibleBridgeEvents") };
    return { ok: true, value: {
      format: ENHANCE_CONFIGURATION_FORMAT,
      version: 1,
      enabled: root.enabled === true,
      player: {
        replaceControls: player.replaceControls === true,
        language: text(player.language, "en", 16),
        preferredQuality: typeof player.preferredQuality === "string" && QUALITY.test(player.preferredQuality) ? player.preferredQuality : "auto",
        defaultPlaybackRate: finite(player.defaultPlaybackRate, 1, 0.25, 4),
        keyboardSeekSeconds: finite(player.keyboardSeekSeconds, 5, 1, 120),
        frameStepFps: finite(player.frameStepFps, 30, 1, 240),
        autoFullscreenLandscape: player.autoFullscreenLandscape === true,
        captions: {
          enabledByDefault: captions.enabledByDefault === true,
          language: text(captions.language, text(player.language, "en", 16), 16),
          availableLanguages: captionLanguages(captions.availableLanguages),
          style: style(captions.style)
        }
      },
      screenshots: {
        format: format(screenshots.format),
        jpegQuality: finite(screenshots.jpegQuality, 0.92, 0.1, 1),
        filenameTemplate: text(screenshots.filenameTemplate, "{channel}_{title}_{timestamp_ms}", 300),
        templateFields: Array.isArray(screenshots.templateFields) ? screenshots.templateFields.filter((item) => typeof item === "string").slice(0, 20) : []
      },
      sponsorBlock: {
        enabled: sponsorBlock.enabled === true,
        categories: Array.isArray(sponsorBlock.categories) ? sponsorBlock.categories.filter((item) => typeof item === "string" && item.length <= 40).slice(0, 20) : []
      },
      bridge: { version: 1, detailEncoding: "json-string", events: ENHANCE_BRIDGE_EVENTS }
    } };
  }
  function validateEnhanceContext(value, legacyFallback = "default") {
    const root = object(value), video = object(root?.video), playback = object(root?.playback), captions = object(playback?.captions), screenshot = object(root?.screenshot);
    if (root?.version !== 1 || root.active !== true || !video || !VIDEO_ID2.test(String(video.id ?? "")) || !playback || !captions || !screenshot)
      return null;
    const chapters = Array.isArray(playback.chapters) ? playback.chapters.flatMap((item) => {
      const chapter = object(item), start = Number(chapter?.start);
      return chapter && typeof chapter.title === "string" && Number.isFinite(start) && start >= 0 ? [{ title: chapter.title.slice(0, 200), start }] : [];
    }).slice(0, 500) : [];
    const sponsorBlockSegments = Array.isArray(playback.sponsorBlockSegments) ? playback.sponsorBlockSegments.flatMap((item) => {
      const segment = object(item), bounds = segment?.segment;
      const start = Number(bounds?.[0]), end = Number(bounds?.[1]);
      return segment && Array.isArray(bounds) && Number.isFinite(start) && Number.isFinite(end) && start >= 0 && end > start && typeof segment.category === "string" ? [{ category: segment.category.slice(0, 40), actionType: text(segment.actionType, "skip", 40), segment: [start, end], UUID: text(segment.UUID, `${start}-${end}`, 200) }] : [];
    }).slice(0, 500) : [];
    return {
      version: 1,
      active: true,
      video: {
        id: String(video.id),
        title: text(video.title, "YouTube", 300),
        channelId: text(video.channelId, "", 200),
        channelTitle: text(video.channelTitle, "YouTube", 200),
        duration: finite(video.duration, 0, 0, 86400 * 30),
        contentType: normalizeContentType(video.contentType, legacyFallback)
      },
      playback: {
        rate: finite(playback.rate, 1, 0.25, 4),
        keyboardSeekSeconds: finite(playback.keyboardSeekSeconds, 5, 1, 120),
        frameStepFps: finite(playback.frameStepFps, 30, 1, 240),
        keyboardShortcuts: resolveShortcutBindings(playback.keyboardShortcuts),
        transportLocked: playback.transportLocked === true,
        captions: { enabledByDefault: captions.enabledByDefault === true, language: text(captions.language, "en", 16), style: style(captions.style) },
        chapters,
        sponsorBlockSegments
      },
      screenshot: { format: format(screenshot.format), quality: finite(screenshot.quality, 0.92, 0.1, 1), filenameTemplate: text(screenshot.filenameTemplate, "{channel}_{title}_{timestamp_ms}", 300) }
    };
  }
  function parseBridgeDetail(event, maxLength = MAX_CONTEXT_DETAIL_LENGTH) {
    if (typeof event.detail !== "string" || event.detail.length > maxLength)
      return null;
    try {
      return JSON.parse(event.detail);
    } catch {
      return null;
    }
  }
  function validateScreenshotRequest(value) {
    const root = object(value), video = object(root?.video), screenshot = object(root?.screenshot);
    if (root?.version !== 1 || !video || !VIDEO_ID2.test(String(video.id ?? "")) || !screenshot)
      return null;
    return {
      version: 1,
      video: { id: String(video.id), title: text(video.title, "YouTube", 300), channelTitle: text(video.channelTitle, "YouTube", 200), seconds: finite(video.seconds, 0, 0, 86400 * 30) },
      screenshot: { format: format(screenshot.format), quality: finite(screenshot.quality, 0.92, 0.1, 1), filenameTemplate: text(screenshot.filenameTemplate, "{channel}_{title}_{timestamp_ms}", 300) }
    };
  }
  function claimScreenshotRequest(event, pageUrl, instanceUrl) {
    if (!configuredPageMatches(pageUrl, instanceUrl))
      return null;
    const request = validateScreenshotRequest(parseBridgeDetail(event, MAX_SCREENSHOT_DETAIL_LENGTH));
    if (!request)
      return null;
    event.preventDefault();
    return request;
  }
  function frameStepSeconds(fps) {
    return 1 / finite(fps, 30, 1, 240);
  }

  // src/instances.ts
  var PAIRED_INSTANCES_KEY = "ytzePairedInstances";
  var EMBEDDED_CONFIGURATION_ID = "ytzero-enhance-configuration";
  function parseEmbeddedConfigurationText(value) {
    if (value.length > MAX_CONFIGURATION_DETAIL_LENGTH)
      return { ok: false, diagnostic: t("configurationPayloadTooLarge") };
    try {
      return validateEnhanceConfiguration(JSON.parse(value));
    } catch {
      return { ok: false, diagnostic: t("embeddedSettingsReadFailed") };
    }
  }
  function inferInstanceUrl(pageUrl, applicationResourceUrl = "") {
    try {
      const url = new URL(pageUrl);
      if (!/^https?:$/.test(url.protocol))
        return null;
      if (applicationResourceUrl) {
        const resource = new URL(applicationResourceUrl, url);
        if (resource.origin === url.origin && /^https?:$/.test(resource.protocol)) {
          const resourcePath = resource.pathname.match(/^(.*)\/(?:manifest\.webmanifest|favicon\.svg)$/);
          if (resourcePath) {
            url.pathname = resourcePath[1] || "/";
            url.search = "";
            url.hash = "";
            return url.toString().replace(/\/$/, "");
          }
        }
      }
      const pathname = url.pathname.replace(/\/+$/, "");
      const route = pathname.match(/^(.*)\/(?:search|discovery|shorts|live|watch|channel|subscriptions|playlists|playlist|followed-playlists|watchlist|downloads|liked|history|archive|cleanup|insights|settings|import|restore)(?:\/.*)?$/);
      url.pathname = route ? route[1] || "/" : pathname || "/";
      url.search = "";
      url.hash = "";
      return url.toString().replace(/\/$/, "");
    } catch {
      return null;
    }
  }
  function friendlyInstanceName(pageTitle, instanceUrl) {
    const cleaned = pageTitle.replace(/\s*[—|·-]\s*YT Zero.*$/i, "").trim();
    if (cleaned && !/^(watch|ustawienia|settings)$/i.test(cleaned))
      return cleaned.slice(0, 60);
    try {
      return new URL(instanceUrl).hostname;
    } catch {
      return "YT Zero";
    }
  }
  function pairedInstanceForPage(instances, pageUrl) {
    return Object.values(instances).filter((instance) => configuredPageMatches(pageUrl, instance.url)).sort((a, b) => b.url.length - a.url.length)[0] ?? null;
  }
  function defaultPairedInstance(instances, defaultUrl) {
    return instances[defaultUrl] ?? Object.values(instances).sort((a, b) => a.pairedAt - b.pairedAt)[0] ?? null;
  }
  function instanceSettingsUrl(instanceUrl) {
    const url = new URL(instanceUrl);
    url.pathname = `${url.pathname.replace(/\/$/, "")}/settings`.replace(/\/{2,}/g, "/");
    url.search = "?tab=display";
    url.hash = "";
    return url.toString();
  }

  // src/webext.ts
  var ext = globalThis.browser ?? globalThis.chrome;
  var isFirefox = typeof globalThis.browser !== "undefined";
  var INVALIDATED_MESSAGE = "Extension context invalidated";
  var invalidationListeners = new Set;
  var contextInvalidated = false;
  function isInvalidation(error) {
    return String(error?.message ?? error).toLowerCase().includes("extension context invalidated");
  }
  function markContextInvalidated() {
    if (contextInvalidated)
      return;
    contextInvalidated = true;
    for (const listener of invalidationListeners) {
      try {
        listener();
      } catch {}
    }
    invalidationListeners.clear();
  }
  function onExtensionContextInvalidated(listener) {
    if (contextInvalidated) {
      queueMicrotask(listener);
      return () => {};
    }
    invalidationListeners.add(listener);
    return () => invalidationListeners.delete(listener);
  }
  function extensionContextAvailable() {
    try {
      const available = Boolean(ext?.runtime?.id);
      if (!available)
        markContextInvalidated();
      return available;
    } catch {
      markContextInvalidated();
      return false;
    }
  }
  function callApi(owner, method, ...args) {
    return new Promise((resolve, reject) => {
      try {
        if (!extensionContextAvailable() || !owner || typeof owner[method] !== "function") {
          markContextInvalidated();
          reject(new Error(INVALIDATED_MESSAGE));
          return;
        }
        if (isFirefox) {
          Promise.resolve(owner[method](...args)).then(resolve, (error) => {
            if (isInvalidation(error))
              markContextInvalidated();
            reject(error);
          });
          return;
        }
        owner[method](...args, (result) => {
          try {
            const error = ext?.runtime?.lastError;
            if (error) {
              const runtimeError = new Error(error.message);
              if (isInvalidation(runtimeError))
                markContextInvalidated();
              reject(runtimeError);
            } else
              resolve(result);
          } catch (error) {
            if (isInvalidation(error))
              markContextInvalidated();
            reject(error);
          }
        });
      } catch (error) {
        if (isInvalidation(error))
          markContextInvalidated();
        reject(error);
      }
    });
  }
  function addApiListener(event, listener) {
    try {
      if (!extensionContextAvailable() || typeof event?.addListener !== "function")
        return false;
      event.addListener(listener);
      return true;
    } catch {
      return false;
    }
  }

  // src/content.ts
  var config = normalizeSettings(DEFAULT_SETTINGS);
  var remoteConfig = null;
  var bridgeContext = null;
  var playerController = null;
  var bridgeCleanup = null;
  var playerObserver = null;
  var configurationObserver = null;
  var extensionStatusObserver = null;
  var playerBootToken = 0;
  var activeInstanceUrl = "";
  var lastEmbeddedConfigurationText = "";
  var ownedIframeParameters = new Map;
  var SVG_NAMESPACE = "http://www.w3.org/2000/svg";
  var PLAYER_ICONS = {
    play: [["path", { d: "M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z" }]],
    pause: [["rect", { x: "6", y: "4", width: "4", height: "16", rx: "1" }], ["rect", { x: "14", y: "4", width: "4", height: "16", rx: "1" }]],
    volume: [["path", { d: "M11 5 6 9H2v6h4l5 4z" }], ["path", { d: "M15.5 8.5a5 5 0 0 1 0 7" }], ["path", { d: "M18 6a9 9 0 0 1 0 12" }]],
    muted: [["path", { d: "M11 5 6 9H2v6h4l5 4z" }], ["path", { d: "m22 9-6 6" }], ["path", { d: "m16 9 6 6" }]],
    captions: [["rect", { x: "3", y: "5", width: "18", height: "14", rx: "2" }], ["path", { d: "M10 10.5a2.5 2.5 0 1 0 0 3M17 10.5a2.5 2.5 0 1 0 0 3" }]],
    pip: [["rect", { x: "2", y: "3", width: "20", height: "14", rx: "2" }], ["rect", { x: "12", y: "10", width: "8", height: "5", rx: "1" }]],
    fullscreen: [["path", { d: "M8 3H5a2 2 0 0 0-2 2v3" }], ["path", { d: "M16 3h3a2 2 0 0 1 2 2v3" }], ["path", { d: "M8 21H5a2 2 0 0 1-2-2v-3" }], ["path", { d: "M16 21h3a2 2 0 0 0 2-2v-3" }]],
    minimize: [["path", { d: "M8 3v3a2 2 0 0 1-2 2H3" }], ["path", { d: "M16 3v3a2 2 0 0 0 2 2h3" }], ["path", { d: "M8 21v-3a2 2 0 0 0-2-2H3" }], ["path", { d: "M16 21v-3a2 2 0 0 1 2-2h3" }]]
  };
  var PLAYER_ICON_STATE = new WeakMap;
  function setPlayerIcon(button, iconDefinition) {
    if (PLAYER_ICON_STATE.get(button) === iconDefinition)
      return;
    const icon = document.createElementNS(SVG_NAMESPACE, "svg");
    icon.setAttribute("viewBox", "0 0 24 24");
    for (const [tag, attributes] of iconDefinition) {
      const shape = document.createElementNS(SVG_NAMESPACE, tag);
      for (const [name, value] of Object.entries(attributes))
        shape.setAttribute(name, value);
      icon.append(shape);
    }
    button.replaceChildren(icon);
    PLAYER_ICON_STATE.set(button, iconDefinition);
  }
  Promise.all([
    callApi(ext.storage.sync, "get", DEFAULT_SETTINGS),
    callApi(ext.runtime, "sendMessage", { type: "ytze-get-configuration-state" }).catch(() => ({ configuration: null }))
  ]).then(([stored, state]) => {
    config = normalizeSettings(stored);
    remoteConfig = state?.configuration ?? null;
    activeInstanceUrl = state?.instance?.url ?? "";
    boot();
  }).catch(() => {});
  addApiListener(ext?.storage?.onChanged, (changes, area) => {
    if (area !== "sync")
      return;
    const patch = Object.fromEntries(Object.entries(changes).map(([key, value]) => [key, value.newValue]));
    config = normalizeSettings({ ...config, ...patch });
    reloadConfigurationState();
  });
  addApiListener(ext?.storage?.onChanged, (changes, area) => {
    if (area !== "local")
      return;
    if (changes[PAIRED_INSTANCES_KEY])
      reloadConfigurationState();
  });
  async function reloadConfigurationState() {
    const state = await callApi(ext.runtime, "sendMessage", { type: "ytze-get-configuration-state" }).catch(() => ({ configuration: null }));
    remoteConfig = state?.configuration ?? null;
    activeInstanceUrl = state?.instance?.url ?? "";
    restart();
  }
  function restart() {
    shutdown(!pageBridgeShouldBeActive());
    boot();
  }
  function pageBridgeShouldBeActive() {
    return window.top === window && Boolean(config.enhancePlayer && remoteConfig?.enabled && activeInstanceUrl && configuredPageMatches(location.href, activeInstanceUrl));
  }
  function shutdown(restoreEmbeds = false) {
    playerBootToken++;
    if (window.top !== window && playerController) {
      callApi(ext.runtime, "sendMessage", { type: "ytze-remove-player-styles", videoId: youtubeVideoId(location.href) }).catch(() => {});
    }
    playerController?.destroy();
    playerController = null;
    bridgeCleanup?.();
    bridgeCleanup = null;
    playerObserver?.disconnect();
    playerObserver = null;
    configurationObserver?.disconnect();
    configurationObserver = null;
    extensionStatusObserver?.disconnect();
    extensionStatusObserver = null;
    bridgeContext = null;
    if (restoreEmbeds) {
      restoreEmbeddedParameters();
      document.getElementById("ytzero-enhance-extension-status")?.setAttribute("data-extension-status", "inactive");
    }
  }
  onExtensionContextInvalidated(() => shutdown(true));
  function boot() {
    if (window.top === window) {
      const isPairedInstance = activeInstanceUrl && configuredPageMatches(location.href, activeInstanceUrl);
      if (isPairedInstance)
        watchEmbeddedConfiguration();
      bootPageBridge();
      if (isPairedInstance)
        markExtensionActiveWhenReady();
      return;
    }
    if (!config.enhancePlayer || !remoteConfig?.enabled || !youtubeVideoId(location.href))
      return;
    const videoId = youtubeVideoId(location.href);
    const token = ++playerBootToken;
    const authorize = async () => {
      const retryDelays = [0, 100, 250, 500, 1000, 2000];
      for (const delay of retryDelays) {
        if (delay)
          await new Promise((resolve) => window.setTimeout(resolve, delay));
        if (token !== playerBootToken || !config.enhancePlayer || !remoteConfig?.enabled)
          return null;
        const authorization = await callApi(ext.runtime, "sendMessage", { type: "ytze-authorize-player-frame", videoId }).catch(() => null);
        if (authorization?.authorized)
          return authorization;
      }
      return null;
    };
    authorize().then((authorization) => {
      if (token !== playerBootToken || !authorization?.authorized || !config.enhancePlayer || !remoteConfig?.enabled) {
        if (authorization?.authorized)
          callApi(ext.runtime, "sendMessage", { type: "ytze-remove-player-styles", videoId }).catch(() => {});
        return;
      }
      const start = () => {
        const video = document.querySelector("video.html5-main-video, video");
        if (!video || playerController)
          return;
        playerController = enhanceYouTubePlayer(video);
        playerController.setMode(authorization.mode);
        callApi(ext.runtime, "sendMessage", { type: "ytze-player-initialized", videoId }).catch(() => {});
      };
      start();
      playerObserver = new MutationObserver(start);
      playerObserver.observe(document.documentElement, { childList: true, subtree: true });
    });
  }
  function markExtensionActiveWhenReady() {
    const markExtensionActive = () => {
      const element = document.getElementById("ytzero-enhance-extension-status");
      if (!element)
        return false;
      element.setAttribute("data-extension-status", "active");
      return true;
    };
    if (markExtensionActive() || !document.body)
      return;
    extensionStatusObserver = new MutationObserver(() => {
      if (markExtensionActive()) {
        extensionStatusObserver?.disconnect();
        extensionStatusObserver = null;
      }
    });
    extensionStatusObserver.observe(document.body, { childList: true, subtree: true });
  }
  function watchEmbeddedConfiguration() {
    const read = () => {
      const text2 = document.body?.querySelector(`#${EMBEDDED_CONFIGURATION_ID}`)?.textContent?.trim() ?? "";
      if (!text2 || text2 === lastEmbeddedConfigurationText)
        return;
      const validation = parseEmbeddedConfigurationText(text2);
      lastEmbeddedConfigurationText = text2;
      if (!validation.ok) {
        callApi(ext.runtime, "sendMessage", { type: "ytze-page-configuration-error", diagnostic: validation.diagnostic, blocked: Boolean(validation.unsupportedVersion) }).catch(() => {});
        return;
      }
      callApi(ext.runtime, "sendMessage", { type: "ytze-page-configuration", configuration: validation.value }).catch(() => {});
    };
    read();
    configurationObserver = new MutationObserver(read);
    configurationObserver.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  }
  function bootPageBridge() {
    if (!config.enhancePlayer || !remoteConfig?.enabled || !activeInstanceUrl || !configuredPageMatches(location.href, activeInstanceUrl))
      return;
    const configureEmbeds = (context) => {
      for (const iframe of ownedIframeParameters.keys())
        if (!iframe.isConnected)
          ownedIframeParameters.delete(iframe);
      for (const iframe of document.querySelectorAll('iframe[src*="youtube.com/embed/"], iframe[src*="youtube-nocookie.com/embed/"]')) {
        try {
          if (context && youtubeVideoId(iframe.src) !== context.video.id)
            continue;
          const url = new URL(iframe.src);
          const desired = embeddedPlayerParameters(remoteConfig);
          if (remoteConfig.player.preferredQuality !== "auto")
            desired.vq = remoteConfig.player.preferredQuality;
          const captions = context?.playback.captions ?? remoteConfig.player.captions;
          desired.cc_load_policy = captions.enabledByDefault ? "1" : "0";
          if (captions.language)
            desired.cc_lang_pref = captions.language;
          let changed = false;
          const owned = ownedIframeParameters.get(iframe) ?? new Map;
          for (const [key, value] of Object.entries(desired)) {
            const current = url.searchParams.get(key);
            const previous = owned.get(key);
            const original = previous && current === previous.applied ? previous.original : current;
            if (current === value)
              continue;
            owned.set(key, { original, applied: value });
            url.searchParams.set(key, value);
            changed = true;
          }
          if (owned.size)
            ownedIframeParameters.set(iframe, owned);
          if (changed)
            iframe.src = url.toString();
        } catch {}
      }
    };
    const onContext = (event) => {
      const raw = parseBridgeDetail(event, MAX_CONTEXT_DETAIL_LENGTH);
      const fallback = embeddedPlayerModeForPage(location.href) === "shorts" ? "short" : "default";
      const contentTypeAuthoritative = isContentType(raw?.video?.contentType);
      const context = validateEnhanceContext(raw, fallback);
      if (context) {
        configureEmbeds(context);
        callApi(ext.runtime, "sendMessage", { type: "ytze-bridge-context", context, contentTypeAuthoritative }).catch(() => {});
      }
    };
    const onScreenshot = (event) => {
      const request = claimScreenshotRequest(event, location.href, activeInstanceUrl);
      if (!request)
        return;
      callApi(ext.runtime, "sendMessage", { type: "ytze-bridge-screenshot", request }).then((result) => dispatchScreenshotResult(result?.ok ? "saved" : "error", result?.error)).catch((error) => dispatchScreenshotResult("error", error.message));
    };
    const onPlayerCommand = (event) => {
      const command = validatePlayerCommand(parseBridgeDetail(event, MAX_COMMAND_DETAIL_LENGTH));
      if (!command)
        return;
      event.preventDefault();
      callApi(ext.runtime, "sendMessage", { type: "ytze-player-command", command }).then((result) => dispatchPlayerEvent({
        version: 1,
        videoId: command.videoId,
        type: "command-result",
        timestamp: Date.now(),
        payload: { requestId: command.requestId, command: command.command, ...result }
      })).catch((error) => dispatchPlayerEvent({
        version: 1,
        videoId: command.videoId,
        type: "command-result",
        timestamp: Date.now(),
        payload: { requestId: command.requestId, command: command.command, ok: false, error: error.message }
      }));
    };
    document.addEventListener(ENHANCE_BRIDGE_EVENTS.context, onContext);
    document.addEventListener(ENHANCE_BRIDGE_EVENTS.screenshotRequest, onScreenshot);
    document.addEventListener(ENHANCE_PLAYER_EVENTS.command, onPlayerCommand);
    configureEmbeds();
    const observer = new MutationObserver(() => configureEmbeds());
    observer.observe(document.documentElement, { childList: true, subtree: true });
    const contextInterval = window.setInterval(extensionContextAvailable, 2000);
    document.dispatchEvent(new Event(ENHANCE_BRIDGE_EVENTS.ready));
    bridgeCleanup = () => {
      document.removeEventListener(ENHANCE_BRIDGE_EVENTS.context, onContext);
      document.removeEventListener(ENHANCE_BRIDGE_EVENTS.screenshotRequest, onScreenshot);
      document.removeEventListener(ENHANCE_PLAYER_EVENTS.command, onPlayerCommand);
      observer.disconnect();
      clearInterval(contextInterval);
    };
  }
  function restoreEmbeddedParameters() {
    for (const [iframe, owned] of ownedIframeParameters) {
      if (!iframe.isConnected)
        continue;
      try {
        const url = new URL(iframe.src);
        let changed = false;
        for (const [key, value] of owned) {
          if (url.searchParams.get(key) !== value.applied)
            continue;
          if (value.original == null)
            url.searchParams.delete(key);
          else
            url.searchParams.set(key, value.original);
          changed = true;
        }
        if (changed)
          iframe.src = url.toString();
      } catch {}
    }
    ownedIframeParameters.clear();
  }
  function dispatchPlayerEvent(detail) {
    document.dispatchEvent(new CustomEvent(ENHANCE_PLAYER_EVENTS.event, { detail: JSON.stringify(detail) }));
  }
  function dispatchScreenshotResult(status, error) {
    document.dispatchEvent(new CustomEvent(ENHANCE_BRIDGE_EVENTS.screenshotResult, {
      detail: JSON.stringify({ version: 1, status, ...error ? { error: String(error).slice(0, 300) } : {} })
    }));
  }
  function enhanceYouTubePlayer(video) {
    const presentation = playerPresentationState(config.enhancePlayer, true, remoteConfig, false);
    if (presentation.active)
      document.documentElement.classList.add("ytze-active");
    if (presentation.replaceControls)
      document.documentElement.classList.add("ytze-replace-controls");
    const host = document.createElement("div");
    host.id = "ytze-player-controls";
    const shadow = host.attachShadow({ mode: "open" });
    const create = (tag, className = "") => {
      const element = document.createElement(tag);
      if (className)
        element.className = className;
      return element;
    };
    const iconButton = (className, label, icon) => {
      const button = create("button", className);
      button.type = "button";
      button.setAttribute("aria-label", label);
      setPlayerIcon(button, icon);
      return button;
    };
    const styleElement = create("style");
    styleElement.textContent = CONTROL_STYLES;
    const bigPlayElement = iconButton("big-play", t("play"), PLAYER_ICONS.play);
    const controlsElement = create("div", "controls");
    controlsElement.setAttribute("role", "group");
    controlsElement.setAttribute("aria-label", t("playerControls"));
    const progressElement = create("div", "progress");
    for (const [name, value] of Object.entries({ role: "slider", tabindex: "0", "aria-label": t("progress"), "aria-valuemin": "0", "aria-valuemax": "1000", "aria-valuenow": "0" }))
      progressElement.setAttribute(name, value);
    const progressTrack = create("div", "progress-track");
    const bufferedElement = create("div", "buffered");
    const markersElement = create("div", "markers");
    markersElement.setAttribute("aria-hidden", "true");
    const playedElement = create("div", "played");
    progressTrack.append(bufferedElement, markersElement, playedElement);
    const knobElement = create("div", "knob");
    const tooltipElement = create("div", "progress-tooltip");
    const chapterElement = create("span", "chapter");
    const hoverTimeElement = create("span", "hover-time");
    hoverTimeElement.textContent = "0:00";
    tooltipElement.append(chapterElement, hoverTimeElement);
    progressElement.append(progressTrack, knobElement, tooltipElement);
    const buttonsElement = create("div", "buttons");
    const playElement = iconButton("play", t("playPause"), PLAYER_ICONS.play);
    const volumeWrap = create("div", "volume-wrap");
    const muteElement = iconButton("mute", t("mute"), PLAYER_ICONS.volume);
    const volumeElement = create("input", "volume");
    Object.assign(volumeElement, { type: "range", min: "0", max: "1", step: "0.05", value: "1" });
    volumeElement.setAttribute("aria-label", t("volume"));
    volumeWrap.append(muteElement, volumeElement);
    const timeElement = create("span", "time");
    timeElement.textContent = "0:00 / 0:00";
    const liveEdgeElement = create("button", "live-edge");
    liveEdgeElement.type = "button";
    liveEdgeElement.setAttribute("aria-label", t("goLive"));
    const liveDotElement = create("span", "live-dot");
    const liveLabelElement = create("span");
    liveLabelElement.textContent = t("live");
    liveEdgeElement.append(liveDotElement, liveLabelElement);
    liveEdgeElement.hidden = true;
    const spacerElement = create("span", "spacer");
    const captionMenuWrapElement = create("div", "caption-menu-wrap");
    const captionsElement = iconButton("captions", t("captionsShortcut"), PLAYER_ICONS.captions);
    captionsElement.setAttribute("aria-haspopup", "dialog");
    captionsElement.setAttribute("aria-expanded", "false");
    const captionMenuElement = create("div", "caption-menu");
    captionMenuElement.setAttribute("role", "dialog");
    captionMenuElement.setAttribute("aria-label", t("captions"));
    captionMenuElement.hidden = true;
    const captionToggleElement = create("div", "caption-toggle");
    const captionToggleLabel = create("span");
    captionToggleLabel.textContent = t("captions");
    const captionSwitchElement = create("button", "caption-switch");
    captionSwitchElement.type = "button";
    captionSwitchElement.setAttribute("role", "switch");
    captionSwitchElement.setAttribute("aria-checked", "false");
    captionSwitchElement.setAttribute("aria-label", t("captions"));
    captionSwitchElement.append(create("span"));
    captionToggleElement.append(captionToggleLabel, captionSwitchElement);
    const captionListElement = create("div", "caption-list");
    captionListElement.setAttribute("role", "listbox");
    captionListElement.setAttribute("aria-label", t("captions"));
    captionMenuElement.append(captionToggleElement, captionListElement);
    captionMenuWrapElement.append(captionsElement, captionMenuElement);
    const pipElement = iconButton("pip", t("pictureInPicture"), PLAYER_ICONS.pip);
    const fullscreenElement = iconButton("fullscreen", t("fullscreen"), PLAYER_ICONS.fullscreen);
    buttonsElement.append(playElement, volumeWrap, timeElement, liveEdgeElement, spacerElement, captionMenuWrapElement, pipElement, fullscreenElement);
    controlsElement.append(progressElement, buttonsElement);
    const toastElement = create("div", "toast");
    toastElement.setAttribute("aria-live", "polite");
    shadow.append(styleElement, bigPlayElement, controlsElement, toastElement);
    document.documentElement.append(host);
    const q = (selector) => shadow.querySelector(selector);
    const play = q(".play");
    const bigPlay = q(".big-play");
    const time = q(".time");
    const progress = q(".progress");
    const played = q(".played");
    const buffered = q(".buffered");
    const knob = q(".knob");
    const tooltip = q(".progress-tooltip");
    const hoverTime = q(".hover-time");
    const chapter = q(".chapter");
    const mute = q(".mute");
    const volume = q(".volume");
    const captions = q(".captions");
    const captionMenuWrap = q(".caption-menu-wrap");
    const captionMenu = q(".caption-menu");
    const captionSwitch = q(".caption-switch");
    const captionList = q(".caption-list");
    const fullscreen = q(".fullscreen");
    const toast = q(".toast");
    let toastTimer = 0;
    let idleTimer = 0;
    let qualityInterval = 0;
    let scrubbing = false;
    let temporaryBoostController = null;
    let shortcutBindings = { ...DEFAULT_SHORTCUT_BINDINGS };
    let lastSkippedSegment = "";
    const ownedRate = new OwnedPlaybackRate(remoteConfig?.player.defaultPlaybackRate ?? 1);
    let subtitleSize = remoteConfig?.player.captions.style.fontSizePx ?? 19;
    let selectedCaptionLanguage = new URL(location.href).searchParams.get("cc_lang_pref") || remoteConfig?.player.captions.language || "en";
    let captionLanguageUserSelected = false;
    const initialCaptionButton = document.querySelector(".ytmClosedCaptioningButtonButton, .ytp-subtitles-button");
    const initialCaptionPressed = initialCaptionButton?.getAttribute("aria-pressed");
    let captionsEnabled = initialCaptionPressed === "true" || initialCaptionPressed == null && (new URL(location.href).searchParams.get("cc_load_policy") === "1" || remoteConfig?.player.captions.enabledByDefault === true);
    let captionMenuOpen = false;
    let captionDefaultTimer = 0;
    let captionDefaultsApplied = false;
    let captionUserOverride = false;
    let captionOperationQueue = Promise.resolve();
    let lastStateEmit = 0;
    let requestedPlayerMode = "standard";
    let contentTypeAuthoritative = false;
    let playerMode = "standard";
    const previewEmbed = isPreviewEmbedUrl(location.href);
    let observedLivePlayableEnd = 0;
    const lifecycle = new AbortController;
    const signal = lifecycle.signal;
    const videoId = youtubeVideoId(location.href);
    const playerState = () => ({
      paused: video.paused,
      ended: video.ended,
      currentTime: Number.isFinite(video.currentTime) ? video.currentTime : 0,
      duration: Number.isFinite(video.duration) ? video.duration : 0,
      volume: video.volume,
      muted: video.muted,
      playbackRate: video.playbackRate,
      captionSize: subtitleSize,
      captionsEnabled,
      fullscreen: Boolean(document.fullscreenElement),
      pictureInPicture: document.pictureInPictureElement === video
    });
    const emitPlayerEvent = (type, payload) => {
      callApi(ext.runtime, "sendMessage", {
        type: "ytze-player-event",
        event: { version: 1, videoId, type, timestamp: Date.now(), payload }
      }).catch(() => {});
    };
    const emitState = (reason, force = false) => {
      const now = Date.now();
      if (!force && now - lastStateEmit < 1000)
        return;
      lastStateEmit = now;
      emitPlayerEvent("state", { reason, state: playerState() });
    };
    const applyPreferredQuality = () => {
      const player = document.querySelector(".html5-video-player");
      const selected = highestQualityAtOrBelow(player?.getAvailableQualityLevels?.(), remoteConfig?.player.preferredQuality ?? "auto");
      if (selected) {
        player.setPlaybackQualityRange?.(selected, selected);
        player.setPlaybackQuality?.(selected);
      }
      callApi(ext.runtime, "sendMessage", { type: "ytze-apply-preferred-quality" }).catch(() => {});
    };
    const playbackSettings = () => bridgeContext?.video.id === youtubeVideoId(location.href) ? bridgeContext.playback : {
      rate: remoteConfig?.player.defaultPlaybackRate ?? 1,
      keyboardSeekSeconds: remoteConfig?.player.keyboardSeekSeconds ?? config.seekSeconds,
      frameStepFps: remoteConfig?.player.frameStepFps ?? config.frameRate,
      keyboardShortcuts: shortcutBindings,
      transportLocked: false,
      captions: remoteConfig?.player.captions ?? { enabledByDefault: false, language: "en", availableLanguages: [], style: { fontSizePx: 19, color: "#ffffff", backgroundOpacityPercent: 75 } },
      chapters: [],
      sponsorBlockSegments: []
    };
    const applyContext = (context, authoritative = true) => {
      if (context.video.id !== youtubeVideoId(location.href))
        return;
      bridgeContext = context;
      shortcutBindings = context.playback.keyboardShortcuts;
      setContentType(context.video.contentType, authoritative);
      ownedRate.reset(context.playback.rate, playerMode === "live");
      if (!temporaryBoostController?.active)
        video.playbackRate = ownedRate.value;
      if (context.playback.transportLocked || context.video.contentType === "livestream" || temporaryBoostController?.chord != null && context.playback.keyboardShortcuts.temporaryBoost !== temporaryBoostController.chord) {
        temporaryBoostController?.reset();
      }
      if (!captionLanguageUserSelected)
        selectedCaptionLanguage = context.playback.captions.language || selectedCaptionLanguage;
      subtitleSize = context.playback.captions.style.fontSizePx;
      if (!previewEmbed) {
        applyCaptionPreferences(context.playback.captions);
        scheduleCaptionDefaults(300);
        renderMarkers(context);
      }
    };
    const say = (message, duration = 1500) => {
      if (playerMode === "preview")
        return;
      toast.textContent = message;
      toast.classList.add("show");
      clearTimeout(toastTimer);
      toastTimer = window.setTimeout(() => toast.classList.remove("show"), duration);
    };
    const captionLanguages2 = () => remoteConfig?.player.captions.availableLanguages ?? [];
    const captionsAreEnabled = () => captionsEnabled;
    const setCaptionMenuOpen = (open) => {
      captionMenuOpen = open;
      captionMenu.hidden = !open;
      captions.setAttribute("aria-expanded", String(open));
      if (open)
        showControls();
    };
    const syncCaptionControls = () => {
      const enabled = captionsAreEnabled();
      captions.classList.toggle("active", enabled);
      captionSwitch.classList.toggle("active", enabled);
      captionSwitch.setAttribute("aria-checked", String(enabled));
      for (const option of captionList.querySelectorAll("button[data-language]")) {
        const selected = option.dataset.language === selectedCaptionLanguage;
        option.classList.toggle("is-selected", selected);
        option.setAttribute("aria-selected", String(selected));
        option.querySelector(".caption-option-status").textContent = selected ? "✓" : "";
      }
    };
    const setYouTubeCaptions = (enabled, language = selectedCaptionLanguage, userInitiated = true) => {
      if (userInitiated) {
        captionUserOverride = true;
        captionLanguageUserSelected = true;
        clearTimeout(captionDefaultTimer);
        captionDefaultTimer = 0;
      }
      const operation = async () => {
        const configured = captionLanguages2().find((item) => item.code === language);
        const response = await callApi(ext.runtime, "sendMessage", {
          type: "ytze-set-youtube-captions",
          enabled,
          language,
          label: configured?.label ?? language
        }).catch((error) => ({ ok: false, error: error.message }));
        if (!response?.ok || typeof response.enabled !== "boolean") {
          if (typeof response?.enabled === "boolean")
            captionsEnabled = response.enabled;
          if (userInitiated)
            say(`${t("captionsUnavailable")}: ${response?.error || t("unknown")}`);
          syncCaptionControls();
          return false;
        }
        captionsEnabled = response.enabled;
        if (response.enabled)
          selectedCaptionLanguage = language;
        setCaptionMenuOpen(false);
        window.setTimeout(() => {
          update();
          syncCaptionControls();
          emitState("captions", true);
        }, 150);
        return true;
      };
      const pending = captionOperationQueue.then(operation, operation);
      captionOperationQueue = pending.then(() => {
        return;
      }, () => {
        return;
      });
      return pending;
    };
    const scheduleCaptionDefaults = (delay) => {
      if (previewEmbed || captionDefaultsApplied || captionUserOverride)
        return;
      clearTimeout(captionDefaultTimer);
      captionDefaultTimer = window.setTimeout(() => {
        captionDefaultTimer = 0;
        if (captionDefaultsApplied || captionUserOverride)
          return;
        captionDefaultsApplied = true;
        const defaults = playbackSettings().captions;
        setYouTubeCaptions(defaults.enabledByDefault, defaults.language || selectedCaptionLanguage, false);
      }, delay);
    };
    const renderCaptionLanguageMenu = () => {
      const languages = captionLanguages2();
      captionList.replaceChildren();
      for (const language of languages) {
        const option = document.createElement("button");
        option.type = "button";
        option.dataset.language = language.code;
        option.setAttribute("role", "option");
        const label = document.createElement("span");
        label.textContent = language.label;
        const status = document.createElement("span");
        status.className = "caption-option-status";
        option.append(label, status);
        option.addEventListener("click", () => void setYouTubeCaptions(true, language.code), { signal });
        captionList.append(option);
      }
      syncCaptionControls();
    };
    const showControls = () => {
      host.classList.add("visible");
      document.documentElement.classList.remove("ytze-idle");
      clearTimeout(idleTimer);
      if (!video.paused)
        idleTimer = window.setTimeout(() => {
          if (captionMenuOpen)
            return;
          host.classList.remove("visible");
          document.documentElement.classList.add("ytze-idle");
        }, 2600);
    };
    const hideControls = () => {
      clearTimeout(idleTimer);
      host.classList.remove("visible");
      document.documentElement.classList.add("ytze-idle");
    };
    const nativeLivePlayback = () => video.duration === Infinity || document.querySelector(".html5-video-player")?.classList.contains("ytp-live") === true;
    const liveSeekRange = () => {
      if (!video.seekable.length)
        return null;
      const seekableIndex = video.seekable.length - 1;
      const start = video.seekable.start(seekableIndex);
      const end = video.seekable.end(seekableIndex);
      let bufferedEnd = null;
      for (let index = 0;index < video.buffered.length; index++) {
        const candidate = video.buffered.end(index);
        if (video.buffered.start(index) <= end && candidate >= start)
          bufferedEnd = Math.max(bufferedEnd ?? start, candidate);
      }
      observedLivePlayableEnd = Math.max(observedLivePlayableEnd, video.currentTime);
      const range = playableLiveRange(start, end, video.currentTime, bufferedEnd, observedLivePlayableEnd);
      if (range)
        observedLivePlayableEnd = Math.max(observedLivePlayableEnd, range.end);
      return range;
    };
    const applyPlayerMode = (mode) => {
      if (playerMode === mode)
        return;
      playerMode = mode;
      host.classList.toggle("mode-live", mode === "live");
      host.classList.toggle("mode-shorts", mode === "shorts");
      host.classList.toggle("mode-preview", mode === "preview");
      liveEdgeElement.hidden = mode !== "live";
      if (mode === "preview") {
        video.autoplay = true;
        video.loop = true;
        video.muted = true;
        video.defaultMuted = true;
        setCaptionMenuOpen(false);
        video.play().catch(() => {});
      } else if (mode === "live") {
        ownedRate.reset(1, true);
        temporaryBoostController?.reset();
        video.playbackRate = 1;
        setCaptionMenuOpen(false);
      } else {
        ownedRate.reset(playbackSettings().rate);
        video.playbackRate = ownedRate.value;
      }
    };
    const setContentType = (type, authoritative = true) => {
      requestedPlayerMode = type === "livestream" ? "live" : type === "short" ? "shorts" : "standard";
      contentTypeAuthoritative = authoritative;
      refreshPlayerMode();
      if (requestedPlayerMode === "shorts") {
        setCaptionMenuOpen(false);
        shadow.activeElement?.blur?.();
        hideControls();
      }
    };
    const refreshPlayerMode = () => {
      applyPlayerMode(previewEmbed ? "preview" : resolveEmbeddedPlayerMode(requestedPlayerMode, contentTypeAuthoritative, nativeLivePlayback()));
    };
    const goLive = () => {
      const range = liveSeekRange();
      if (range)
        video.currentTime = Math.max(range.start, range.end - 0.1);
      video.play().catch(() => {});
      showControls();
    };
    const togglePlay = () => video.paused ? video.play().catch(() => {}) : video.pause();
    const toggleFullscreen = () => {
      const safariVideo = video;
      if (document.fullscreenElement)
        document.exitFullscreen();
      else if (safariVideo.webkitDisplayingFullscreen)
        safariVideo.webkitExitFullscreen?.();
      else if (document.documentElement.requestFullscreen)
        document.documentElement.requestFullscreen();
      else
        safariVideo.webkitEnterFullscreen?.();
    };
    const togglePictureInPicture = async () => {
      if (document.pictureInPictureElement) {
        if (!document.exitPictureInPicture)
          return false;
        await document.exitPictureInPicture();
        return true;
      }
      if (!video.requestPictureInPicture)
        return false;
      await video.requestPictureInPicture();
      return true;
    };
    const toggleCaptions = () => {
      const currentEnabled = captionsAreEnabled();
      emitPlayerEvent("captions-toggle-request", {
        action: "toggle",
        currentEnabled,
        requestedEnabled: !currentEnabled
      });
    };
    const requestCapture = async (bridgeRequest) => {
      const bounds = video.getBoundingClientRect();
      const fitted = getComputedStyle(video).objectFit === "fill" ? { x: bounds.x, y: bounds.y, width: bounds.width, height: bounds.height } : containedMediaRect(bounds, video.videoWidth, video.videoHeight);
      const title = document.querySelector(".ytp-title-link")?.innerText?.trim() || document.title.replace(/\s*-\s*YouTube$/, "");
      const channel = document.querySelector(".ytp-title-channel")?.textContent?.trim() || "YouTube";
      const metadata = bridgeRequest ? {
        title: bridgeRequest.video.title,
        channel: bridgeRequest.video.channelTitle,
        videoId: bridgeRequest.video.id,
        seconds: bridgeRequest.video.seconds
      } : { title, channel, videoId: youtubeVideoId(location.href), seconds: video.currentTime };
      const contextScreenshot = bridgeContext?.video.id === youtubeVideoId(location.href) ? bridgeContext.screenshot : null;
      const defaultCaptureSettings = contextScreenshot ?? (remoteConfig ? {
        format: remoteConfig.screenshots.format,
        quality: remoteConfig.screenshots.jpegQuality,
        filenameTemplate: remoteConfig.screenshots.filenameTemplate
      } : undefined);
      const response = await callApi(ext.runtime, "sendMessage", {
        type: "ytze-capture-frame",
        videoId: youtubeVideoId(location.href),
        rect: fitted,
        viewport: { width: innerWidth, height: innerHeight },
        metadata,
        captureSettings: bridgeRequest?.screenshot ?? defaultCaptureSettings
      }).catch((error) => ({ ok: false, error: error.message }));
      say(response?.ok ? `${t("saved")}: ${response.filename}` : `${t("captureError")}: ${response?.error || t("unknown")}`);
      return response;
    };
    const executeCommand = async (command) => {
      const payload = command.payload;
      if (playerMode === "preview" && !["seek-by", "seek-to", "set-muted", "toggle-muted", "capture-frame"].includes(command.command)) {
        return { ok: false, error: `${command.command} is unavailable for previews`, state: playerState() };
      }
      if (playerMode === "live" && command.command === "set-playback-rate") {
        return { ok: false, error: "set-playback-rate is unavailable for livestreams", state: playerState() };
      }
      if (playerMode === "live" && (command.command === "seek-by" || command.command === "seek-to") && !liveSeekRange()) {
        return { ok: false, error: `${command.command} is unavailable without a DVR window`, state: playerState() };
      }
      if (command.command === "play")
        await video.play();
      else if (command.command === "pause")
        video.pause();
      else if (command.command === "toggle-play")
        await (video.paused ? video.play() : Promise.resolve(video.pause()));
      else if (command.command === "seek-by")
        seekBy(Number(payload.seconds));
      else if (command.command === "seek-to") {
        const range = playerMode === "live" ? liveSeekRange() : null;
        video.currentTime = Math.min(Math.max(range?.start ?? 0, Number(payload.seconds)), range?.end ?? (video.duration || Infinity));
      } else if (command.command === "set-volume") {
        video.volume = Number(payload.volume);
        video.muted = false;
      } else if (command.command === "set-muted")
        video.muted = Boolean(payload.enabled);
      else if (command.command === "toggle-muted")
        video.muted = !video.muted;
      else if (command.command === "set-playback-rate") {
        ownedRate.reset(Number(payload.rate));
        if (!temporaryBoostController?.active)
          video.playbackRate = ownedRate.value;
      } else if (command.command === "set-captions")
        await setYouTubeCaptions(Boolean(payload.enabled));
      else if (command.command === "toggle-captions")
        await setYouTubeCaptions(!captionsAreEnabled());
      else if (command.command === "set-caption-size") {
        subtitleSize = Number(payload.pixels);
        document.documentElement.style.setProperty("--ytze-caption-size", `${subtitleSize}px`);
      } else if (command.command === "capture-frame")
        await requestCapture();
      else if (command.command === "toggle-fullscreen")
        toggleFullscreen();
      else if (command.command === "enter-fullscreen" && !document.fullscreenElement)
        toggleFullscreen();
      else if (command.command === "exit-fullscreen" && document.fullscreenElement)
        await document.exitFullscreen();
      else if (command.command === "toggle-picture-in-picture" && !await togglePictureInPicture()) {
        return { ok: false, error: "Picture-in-picture is unavailable", state: playerState() };
      }
      update();
      emitState("command", true);
      return { ok: true, state: playerState() };
    };
    const update = () => {
      refreshPlayerMode();
      if (playerMode === "shorts" && video.videoWidth > 0 && video.videoHeight > 0) {
        const stage = containedMediaRect(video.getBoundingClientRect(), video.videoWidth, video.videoHeight);
        host.style.setProperty("--ytze-short-left", `${Math.max(0, stage.x)}px`);
        host.style.setProperty("--ytze-short-right", `${Math.max(0, innerWidth - stage.x - stage.width)}px`);
      }
      const liveRange = playerMode === "live" ? liveSeekRange() : null;
      const duration = Number.isFinite(video.duration) ? video.duration : 0;
      const timeline = playerTimeline(video.currentTime, video.duration, liveRange);
      const timelineStart = timeline.start;
      const timelineDuration = timeline.length;
      const fraction = timeline.fraction;
      if (!scrubbing) {
        played.style.width = `${fraction * 100}%`;
        knob.style.left = `${fraction * 100}%`;
        progress.setAttribute("aria-valuenow", String(Math.round(fraction * 1000)));
      }
      let bufferedEnd = 0;
      for (let index = 0;index < video.buffered.length; index++)
        if (video.buffered.start(index) <= video.currentTime + 0.2)
          bufferedEnd = Math.max(bufferedEnd, video.buffered.end(index));
      buffered.style.width = `${timelineDuration ? Math.min(100, Math.max(0, (bufferedEnd - timelineStart) / timelineDuration * 100)) : 0}%`;
      time.textContent = `${formatClock(video.currentTime).replace(/-/g, ":")} / ${formatClock(duration).replace(/-/g, ":")}`;
      const liveDelay = timeline.liveDelay;
      const atLiveEdge = liveDelay != null && liveDelay <= 2;
      liveEdgeElement.classList.toggle("active", atLiveEdge);
      liveEdgeElement.setAttribute("aria-label", atLiveEdge ? t("live") : liveDelay == null ? t("goLive") : `${t("goLive")} (−${formatClock(liveDelay).replace(/-/g, ":")})`);
      progress.classList.toggle("unavailable", playerMode === "live" && !liveRange);
      progress.setAttribute("aria-disabled", String(playerMode === "live" && !liveRange));
      setPlayerIcon(play, video.paused ? PLAYER_ICONS.play : PLAYER_ICONS.pause);
      bigPlay.hidden = !video.paused || video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA;
      setPlayerIcon(mute, video.muted || video.volume === 0 ? PLAYER_ICONS.muted : PLAYER_ICONS.volume);
      volume.value = String(video.muted ? 0 : video.volume);
      syncCaptionControls();
      setPlayerIcon(fullscreen, document.fullscreenElement ? PLAYER_ICONS.minimize : PLAYER_ICONS.fullscreen);
      const playback = playbackSettings();
      if (playerMode !== "preview" && remoteConfig?.sponsorBlock.enabled) {
        const segment = playback.sponsorBlockSegments.find((item) => item.actionType === "skip" && video.currentTime >= item.segment[0] && video.currentTime < item.segment[1] - 0.25);
        if (segment && segment.UUID !== lastSkippedSegment) {
          lastSkippedSegment = segment.UUID;
          video.currentTime = segment.segment[1];
          say(`${t("skipped")}: ${segment.category}`);
        }
      }
      emitState("timeupdate");
    };
    const seekBy = (seconds) => {
      const range = playerMode === "live" ? liveSeekRange() : null;
      video.currentTime = Math.min(Math.max(range?.start ?? 0, video.currentTime + seconds), range?.end ?? (video.duration || Infinity));
    };
    const progressFraction = (clientX) => {
      const bounds = progress.getBoundingClientRect();
      return Math.min(1, Math.max(0, (clientX - bounds.left) / Math.max(1, bounds.width)));
    };
    const scrubTo = (clientX) => {
      const range = playerMode === "live" ? liveSeekRange() : null;
      const duration = range ? range.end - range.start : video.duration;
      if (!Number.isFinite(duration) || duration <= 0)
        return;
      const fraction = progressFraction(clientX);
      video.currentTime = (range?.start ?? 0) + fraction * duration;
      played.style.width = `${fraction * 100}%`;
      knob.style.left = `${fraction * 100}%`;
    };
    const showProgressTooltip = (clientX) => {
      if (playerMode === "preview")
        return;
      const range = playerMode === "live" ? liveSeekRange() : null;
      const duration = range ? range.end - range.start : video.duration;
      if (!Number.isFinite(duration) || duration <= 0)
        return;
      const fraction = progressFraction(clientX);
      const seconds = (range?.start ?? 0) + fraction * duration;
      tooltip.style.left = `${fraction * 100}%`;
      hoverTime.textContent = range ? `−${formatClock(Math.max(0, range.end - seconds)).replace(/-/g, ":")}` : formatClock(seconds).replace(/-/g, ":");
      const activeChapter = [...bridgeContext?.playback.chapters ?? []].reverse().find((item) => item.start <= seconds);
      chapter.textContent = activeChapter?.title ?? "";
      chapter.hidden = !activeChapter;
      tooltip.classList.add("show");
    };
    const emitShortcut = (action, event, value) => {
      emitPlayerEvent("shortcut", shortcutEventPayload(action, event, value));
    };
    const consumeShortcut = (event) => {
      event.preventDefault();
      event.stopPropagation();
    };
    temporaryBoostController = new TemporaryBoostController({
      schedule: (callback, delay) => window.setTimeout(callback, delay),
      cancel: (timer) => window.clearTimeout(timer),
      isBlocked: () => shortcutOperationBlocked("temporaryBoost", playerMode === "live", playbackSettings().transportLocked),
      togglePlay,
      setRate: (rate) => {
        video.playbackRate = rate;
        if (rate === 2)
          say("2×");
      },
      effectiveRate: () => ownedRate.value,
      applied: (event) => emitShortcut("temporaryBoost", event)
    });
    const onKey = (event) => {
      if (playerMode === "preview" || isEditableShortcutEvent(event))
        return;
      const action = matchingShortcutAction(event, shortcutBindings);
      if (!action) {
        const chord = shortcutChordFromEvent(event);
        if (playerMode !== "shorts" || chord !== "ArrowUp" && chord !== "ArrowDown")
          return;
        consumeShortcut(event);
        if (!event.repeat && !playbackSettings().transportLocked) {
          callApi(ext.runtime, "sendMessage", {
            type: "ytze-player-page-shortcut",
            key: chord === "ArrowUp" ? "shorts-prev" : "shorts-next"
          }).catch(() => {});
        }
        return;
      }
      consumeShortcut(event);
      if (event.repeat && !shortcutAllowsRepeat(action))
        return;
      if (shortcutOperationBlocked(action, playerMode === "live", playbackSettings().transportLocked))
        return;
      if (PARENT_OWNED_SHORTCUT_ACTIONS.has(action)) {
        emitShortcut(action, event);
        return;
      }
      if (action === "temporaryBoost") {
        temporaryBoostController?.keydown(event);
        return;
      }
      if (action === "togglePlay")
        togglePlay();
      else if (action === "seekBack10" || action === "seekForward10") {
        seekBy(action === "seekBack10" ? -10 : 10);
        say(`${action === "seekBack10" ? "−" : "+"}10 s`);
      } else if (action === "seekBack" || action === "seekForward") {
        const seconds = playbackSettings().keyboardSeekSeconds;
        seekBy(action === "seekBack" ? -seconds : seconds);
        say(`${action === "seekBack" ? "−" : "+"}${seconds} s`);
      } else if (action === "previousFrame" || action === "nextFrame") {
        if (!video.paused)
          return;
        const seconds = frameStepSeconds(playbackSettings().frameStepFps);
        seekBy(action === "previousFrame" ? -seconds : seconds);
        say(t(action === "previousFrame" ? "oneFrameBack" : "oneFrameForward"));
      } else if (action === "speedDown" || action === "speedUp") {
        const nextRate = advanceOwnedPlaybackRate(ownedRate, action === "speedDown" ? -1 : 1, (rate) => {
          video.playbackRate = rate;
        });
        say(`${nextRate}×`);
        emitShortcut(action, event, nextRate);
        update();
        return;
      } else if (action === "seekPercent") {
        if (!/^Digit[0-9]$/.test(event.code) || !Number.isFinite(video.duration) || video.duration <= 0)
          return;
        video.currentTime = Number(event.code.slice(-1)) / 10 * video.duration;
      } else if (action === "previousChapter" || action === "nextChapter") {
        const target = chapterShortcutTarget(action, video.currentTime, playbackSettings().chapters);
        if (target == null)
          return;
        video.currentTime = target;
      } else if (action === "volumeUp" || action === "volumeDown") {
        video.volume = Math.min(1, Math.max(0, video.volume + (action === "volumeUp" ? 0.05 : -0.05)));
        if (action === "volumeUp" && video.volume > 0)
          video.muted = false;
        say(`${Math.round(video.volume * 100)}%`);
      } else if (action === "toggleCaptions") {
        setYouTubeCaptions(!captionsAreEnabled()).then((applied) => {
          if (applied)
            emitShortcut(action, event);
        });
        return;
      } else if (action === "subtitleLarger" || action === "subtitleSmaller") {
        subtitleSize = Math.min(48, Math.max(12, subtitleSize + (action === "subtitleLarger" ? 1 : -1)));
        document.documentElement.style.setProperty("--ytze-caption-size", `${subtitleSize}px`);
        say(`${subtitleSize}px`);
      } else if (action === "toggleFullscreen")
        toggleFullscreen();
      else if (action === "togglePictureInPicture") {
        togglePictureInPicture().then((applied) => {
          if (applied)
            emitShortcut(action, event);
        }).catch(() => {});
        return;
      } else if (action === "toggleMute")
        video.muted = !video.muted;
      else if (action === "screenshot") {
        if (isFirefox) {
          say(t("firefoxCaptureShortcut"), 4000);
          return;
        }
        requestCapture().then((response) => {
          if (response?.ok)
            emitShortcut(action, event);
        });
        return;
      }
      emitShortcut(action, event);
      update();
    };
    const onKeyUp = (event) => {
      if (playerMode === "preview" || !temporaryBoostController?.keyup(event))
        return;
      consumeShortcut(event);
      update();
    };
    const onSurfaceClick = (event) => {
      if (playerMode === "preview")
        return;
      const target = event.target;
      if (!target || target.closest("#ytze-player-controls") || !target.closest(".html5-video-player"))
        return;
      event.preventDefault();
      event.stopImmediatePropagation();
      togglePlay();
      showControls();
    };
    const onSurfaceDoubleClick = (event) => {
      if (playerMode === "preview")
        return;
      const target = event.target;
      if (!target || target.closest("#ytze-player-controls"))
        return;
      event.preventDefault();
      event.stopImmediatePropagation();
      toggleFullscreen();
    };
    play.addEventListener("click", togglePlay, { signal });
    bigPlay.addEventListener("click", togglePlay, { signal });
    liveEdgeElement.addEventListener("click", goLive, { signal });
    progress.addEventListener("pointerdown", (event) => {
      scrubbing = true;
      progress.setPointerCapture(event.pointerId);
      scrubTo(event.clientX);
      if (playerMode !== "preview")
        showProgressTooltip(event.clientX);
    }, { signal });
    progress.addEventListener("pointermove", (event) => {
      if (playerMode !== "preview")
        showProgressTooltip(event.clientX);
      if (scrubbing)
        scrubTo(event.clientX);
    }, { signal });
    progress.addEventListener("pointerup", (event) => {
      scrubbing = false;
      progress.releasePointerCapture(event.pointerId);
    }, { signal });
    progress.addEventListener("pointerleave", () => {
      if (!scrubbing)
        tooltip.classList.remove("show");
    }, { signal });
    const togglePreviewMuted = () => {
      if (video.muted) {
        if (video.volume === 0)
          video.volume = 1;
        video.muted = false;
        video.play().catch(() => {});
      } else {
        video.muted = true;
      }
      update();
    };
    mute.addEventListener("pointerdown", (event) => {
      if (playerMode !== "preview")
        return;
      event.preventDefault();
      event.stopPropagation();
      togglePreviewMuted();
    }, { signal });
    mute.addEventListener("click", (event) => {
      if (playerMode === "preview") {
        event.preventDefault();
        event.stopPropagation();
        return;
      }
      video.muted = !video.muted;
      update();
    }, { signal });
    volume.addEventListener("input", () => {
      video.volume = Number(volume.value);
      video.muted = false;
      update();
    }, { signal });
    captions.addEventListener("click", () => setCaptionMenuOpen(!captionMenuOpen), { signal });
    captionSwitch.addEventListener("click", () => void setYouTubeCaptions(!captionsAreEnabled()), { signal });
    q(".pip").addEventListener("click", () => void togglePictureInPicture().then((applied) => {
      if (!applied)
        say(t("pipUnavailable"));
    }).catch(() => say(t("pipUnavailable"))), { signal });
    fullscreen.addEventListener("click", toggleFullscreen, { signal });
    document.addEventListener("keydown", onKey, { capture: true, signal });
    document.addEventListener("keyup", onKeyUp, { capture: true, signal });
    document.addEventListener("click", onSurfaceClick, { capture: true, signal });
    document.addEventListener("dblclick", onSurfaceDoubleClick, { capture: true, signal });
    document.addEventListener("pointerdown", (event) => {
      if (captionMenuOpen && !event.composedPath().includes(captionMenuWrap))
        setCaptionMenuOpen(false);
    }, { capture: true, signal });
    document.addEventListener("mousemove", showControls, { passive: true, signal });
    video.addEventListener("play", () => {
      if (playerMode !== "shorts" && playerMode !== "preview")
        showControls();
      applyPreferredQuality();
      emitState("play", true);
    }, { signal });
    video.addEventListener("pause", () => {
      if (playerMode === "preview")
        video.play().catch(() => {});
      else if (playerMode !== "shorts")
        showControls();
      emitState("pause", true);
    }, { signal });
    video.addEventListener("volumechange", () => emitState("volumechange", true), { signal });
    video.addEventListener("loadedmetadata", () => {
      refreshPlayerMode();
      if (!temporaryBoostController?.active && Math.abs(video.playbackRate - ownedRate.value) > 0.001)
        video.playbackRate = ownedRate.value;
    }, { signal });
    video.addEventListener("ratechange", () => {
      if (!temporaryBoostController?.active && Math.abs(video.playbackRate - ownedRate.value) > 0.001)
        queueMicrotask(() => {
          if (!temporaryBoostController?.active)
            video.playbackRate = ownedRate.value;
        });
      emitState("ratechange", true);
    }, { signal });
    video.addEventListener("ended", () => {
      emitPlayerEvent("ended", { state: playerState() });
      callApi(ext.runtime, "sendMessage", { type: "ytze-player-ended" }).catch(() => {});
    }, { signal });
    video.addEventListener("enterpictureinpicture", () => emitState("enterpictureinpicture", true), { signal });
    video.addEventListener("leavepictureinpicture", () => emitState("leavepictureinpicture", true), { signal });
    document.addEventListener("fullscreenchange", () => {
      update();
      emitState("fullscreenchange", true);
    }, { signal });
    const interval = window.setInterval(update, 250);
    qualityInterval = window.setInterval(applyPreferredQuality, 5000);
    refreshPlayerMode();
    ownedRate.reset(playbackSettings().rate, nativeLivePlayback());
    video.playbackRate = ownedRate.value;
    if (!previewEmbed) {
      applyCaptionPreferences(playbackSettings().captions);
      renderCaptionLanguageMenu();
      scheduleCaptionDefaults(800);
    }
    const removeLandscapeFullscreen = previewEmbed ? () => {} : installLandscapeFullscreen(video);
    applyPreferredQuality();
    update();
    emitPlayerEvent("ready", { state: playerState() });
    return {
      capture: requestCapture,
      applyContext,
      command: executeCommand,
      setMode: (mode) => {
        requestedPlayerMode = mode === "live" || mode === "shorts" ? mode : "standard";
        contentTypeAuthoritative = false;
        refreshPlayerMode();
        if (requestedPlayerMode === "shorts") {
          setCaptionMenuOpen(false);
          shadow.activeElement?.blur?.();
          hideControls();
        } else
          showControls();
        update();
      },
      setContentType,
      setHidden: (hidden) => host.classList.toggle("capture-hidden", hidden),
      destroy: () => {
        clearInterval(interval);
        clearInterval(qualityInterval);
        clearTimeout(toastTimer);
        clearTimeout(idleTimer);
        temporaryBoostController?.reset();
        temporaryBoostController = null;
        clearTimeout(captionDefaultTimer);
        document.removeEventListener("keydown", onKey, true);
        document.removeEventListener("mousemove", showControls);
        removeLandscapeFullscreen();
        lifecycle.abort();
        document.documentElement.classList.remove("ytze-active", "ytze-replace-controls", "ytze-idle");
        host.remove();
      }
    };
  }
  function applyCaptionPreferences(captions) {
    document.documentElement.style.setProperty("--ytze-caption-size", `${captions.style.fontSizePx}px`);
    document.documentElement.style.setProperty("--ytze-caption-color", captions.style.color);
    document.documentElement.style.setProperty("--ytze-caption-background", `rgba(0,0,0,${captions.style.backgroundOpacityPercent / 100})`);
  }
  function renderMarkers(context) {
    const controllerHost = document.querySelector("#ytze-player-controls");
    const root = controllerHost?.shadowRoot;
    const markers = root?.querySelector(".markers");
    if (!markers || context.video.duration <= 0)
      return;
    markers.replaceChildren();
    for (const chapter of context.playback.chapters) {
      if (chapter.start <= 0 || chapter.start >= context.video.duration)
        continue;
      const marker = document.createElement("i");
      marker.className = "chapter-marker";
      marker.style.left = `${chapter.start / context.video.duration * 100}%`;
      markers.append(marker);
    }
    if (remoteConfig?.sponsorBlock.enabled)
      for (const segment of context.playback.sponsorBlockSegments) {
        const marker = document.createElement("i");
        marker.className = "sponsor-marker";
        marker.style.left = `${segment.segment[0] / context.video.duration * 100}%`;
        marker.style.width = `${Math.max(0.25, (segment.segment[1] - segment.segment[0]) / context.video.duration * 100)}%`;
        marker.style.background = SPONSOR_COLORS[segment.category] ?? "#888888";
        markers.append(marker);
      }
  }
  var SPONSOR_COLORS = {
    sponsor: "#00d400",
    selfpromo: "#ffff00",
    interaction: "#cc00ff",
    intro: "#00ffff",
    outro: "#0202ed",
    preview: "#008fd6",
    music_offtopic: "#ff9900",
    filler: "#7300ab"
  };
  function installLandscapeFullscreen(video) {
    if (!remoteConfig?.player.autoFullscreenLandscape || typeof matchMedia !== "function")
      return () => {};
    const query = matchMedia("(orientation: landscape) and (max-width: 1024px)");
    const enter = () => {
      if (!query.matches || document.fullscreenElement)
        return;
      const safariVideo = video;
      document.documentElement.requestFullscreen?.().catch(() => safariVideo.webkitEnterFullscreen?.());
    };
    query.addEventListener?.("change", enter);
    return () => query.removeEventListener?.("change", enter);
  }
  addApiListener(ext?.runtime?.onMessage, (message, _sender, sendResponse) => {
    const respond = (value) => {
      try {
        sendResponse(value);
      } catch {}
    };
    if (message?.type === "ytze-execute-player-command" && playerController) {
      const command = validatePlayerCommand(message.command);
      if (!command || command.videoId !== youtubeVideoId(location.href)) {
        respond({ ok: false, error: "Invalid player command" });
        return;
      }
      playerController.command(command).then(respond, (error) => respond({ ok: false, error: error.message }));
      return true;
    }
    if (message?.type === "ytze-trigger-capture" && playerController) {
      playerController.capture().then(respond, (error) => respond({ ok: false, error: error.message }));
      return true;
    }
    if (message?.type === "ytze-capture-with-settings" && playerController) {
      playerController.capture(message.request).then(respond, (error) => respond({ ok: false, error: error.message }));
      return true;
    }
    if (message?.type === "ytze-apply-context" && playerController) {
      const context = validateEnhanceContext(message.context);
      if (context && context.video.id === youtubeVideoId(location.href))
        playerController.applyContext(context, message.contentTypeAuthoritative === true);
      respond({ ok: Boolean(context) });
    }
    if (message?.type === "ytze-apply-player-mode" && playerController) {
      const mode = message.mode === "live" || message.mode === "shorts" ? message.mode : "standard";
      playerController.setMode(mode);
      respond({ ok: true, mode });
    }
    if (message?.type === "ytze-request-context" && window.top === window && activeInstanceUrl && configuredPageMatches(location.href, activeInstanceUrl)) {
      document.dispatchEvent(new Event(ENHANCE_BRIDGE_EVENTS.ready));
      respond({ ok: true });
    }
    if (message?.type === "ytze-capture-visibility" && playerController) {
      playerController.setHidden(Boolean(message.hidden));
      respond({ ok: true });
    }
    if (message?.type === "ytze-resolve-frame" && window.top === window) {
      const frames = [...document.querySelectorAll("iframe")];
      const frame = frames.find((item) => youtubeVideoId(item.src) === message.videoId && visible(item)) ?? frames.find((item) => youtubeVideoId(item.src) === message.videoId);
      if (!frame) {
        respond({ rect: null });
        return;
      }
      const outer = frame.getBoundingClientRect();
      const inner = message.innerRect;
      const viewport = message.innerViewport;
      const scaleX = outer.width / Math.max(1, viewport.width);
      const scaleY = outer.height / Math.max(1, viewport.height);
      respond({ rect: {
        x: outer.x + inner.x * scaleX,
        y: outer.y + inner.y * scaleY,
        width: inner.width * scaleX,
        height: inner.height * scaleY
      } });
    }
    if (message?.type === "ytze-crop-download" && window.top === window) {
      cropAndDownload(message).then(() => respond({ ok: true }), (error) => respond({ ok: false, error: error.message }));
      return true;
    }
    if (message?.type === "ytze-exit-fullscreen" && window.top === window) {
      if (document.fullscreenElement)
        document.exitFullscreen?.().catch(() => {});
      respond({ ok: true });
    }
    if (message?.type === "ytze-dispatch-page-shortcut" && window.top === window && ["shorts-prev", "shorts-next"].includes(message.key)) {
      const key = message.key === "shorts-prev" ? "ArrowUp" : "ArrowDown";
      const code = key;
      document.dispatchEvent(new KeyboardEvent("keydown", { key, code, bubbles: true }));
      respond({ ok: true });
    }
    if (message?.type === "ytze-dispatch-player-event" && window.top === window) {
      dispatchPlayerEvent(message.event);
      if (message.event?.type === "captions-toggle-request") {
        document.dispatchEvent(new CustomEvent(ENHANCE_PLAYER_EVENTS.captionsToggleRequest, {
          detail: JSON.stringify({ version: 1, videoId: message.event.videoId, ...message.event.payload })
        }));
      }
      respond({ ok: true });
    }
  });
  function visible(element) {
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && rect.bottom > 0 && rect.right > 0 && rect.top < innerHeight && rect.left < innerWidth;
  }
  async function cropAndDownload(message) {
    const image = new Image;
    image.src = message.imageUrl;
    await image.decode();
    const scaleX = image.naturalWidth / innerWidth;
    const scaleY = image.naturalHeight / innerHeight;
    const rect = message.rect;
    const sx = Math.max(0, Math.round(rect.x * scaleX));
    const sy = Math.max(0, Math.round(rect.y * scaleY));
    const sw = Math.min(image.naturalWidth - sx, Math.max(1, Math.round(rect.width * scaleX)));
    const sh = Math.min(image.naturalHeight - sy, Math.max(1, Math.round(rect.height * scaleY)));
    const canvas = document.createElement("canvas");
    canvas.width = sw;
    canvas.height = sh;
    const context = canvas.getContext("2d");
    if (!context)
      throw new Error(t("canvasUnavailable"));
    context.drawImage(image, sx, sy, sw, sh, 0, 0, sw, sh);
    const mime = message.format === "jpeg" ? "image/jpeg" : message.format === "webp" ? "image/webp" : "image/png";
    const blob = await new Promise((resolve, reject) => canvas.toBlob((value) => value ? resolve(value) : reject(new Error(t("imageEncodingFailed"))), mime, message.quality));
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = message.filename;
    link.style.display = "none";
    document.documentElement.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }
  var CONTROL_STYLES = `
  :host { position: fixed; z-index: 2147483647; inset: 0; pointer-events: none; font: 400 14px "Roboto", -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif; color: #fff; }
  :host(.capture-hidden) { opacity: 0 !important; }
  .controls { position: absolute; left: 0; right: 0; bottom: 0; padding: 26px 12px 8px; background: linear-gradient(to top, rgba(0,0,0,.85), rgba(0,0,0,.4) 60%, transparent); opacity: 0; transition: opacity .2s ease; pointer-events: none; }
  :host(.visible) .controls, .controls:focus-within { opacity: 1; pointer-events: auto; }
  .buttons { display: flex; align-items: center; gap: 4px; margin-top: 2px; }
  button { display: inline-flex; align-items: center; justify-content: center; color: inherit; background: transparent; border: 0; border-radius: 6px; width: 38px; height: 34px; padding: 0; font: inherit; cursor: pointer; opacity: .92; }
  button:hover { opacity: 1; background: rgba(255,255,255,.14); }
  button.active { opacity: 1; background: rgba(255,255,255,.2); }
  button[hidden] { display: none; }
  button:focus-visible, input:focus-visible, .progress:focus-visible { outline: 2px solid #3ea6ff; outline-offset: 2px; }
  button svg { width: 20px; height: 20px; fill: none; stroke: currentColor; stroke-width: 1.8; stroke-linecap: round; stroke-linejoin: round; }
  .play svg path, .play svg rect, .big-play svg path { fill: currentColor; stroke: none; }
  .big-play { position: absolute; left: 50%; top: 50%; transform: translate(-50%,-50%); width: 68px; height: 68px; border-radius: 50%; background: rgba(0,0,0,.65); pointer-events: auto; opacity: 1; transition: background .15s ease, transform .15s ease; }
  .big-play:hover { background: rgba(0,0,0,.85); transform: translate(-50%,-50%) scale(1.06); }
  .big-play svg { width: 30px; height: 30px; }
  .big-play[hidden] { display: none; }
  .time { margin-left: 8px; white-space: nowrap; font-size: 12.5px; font-variant-numeric: tabular-nums; color: rgba(255,255,255,.95); }
  .live-edge { width: auto; min-width: 68px; padding: 0 10px; gap: 7px; color: rgba(255,255,255,.78); font-size: 11px; font-weight: 750; letter-spacing: .04em; }
  .live-edge.active { color: #fff; background: rgba(242,41,58,.24); }
  .live-dot { width: 8px; height: 8px; border-radius: 50%; background: #f2293a; box-shadow: 0 0 0 0 rgba(242,41,58,.7); }
  .live-edge.active .live-dot { animation: live-pulse 1.6s ease-out infinite; }
  @keyframes live-pulse { 70% { box-shadow: 0 0 0 7px rgba(242,41,58,0); } 100% { box-shadow: 0 0 0 0 rgba(242,41,58,0); } }
  .spacer { flex: 1; }
  input[type=range] { accent-color: #fff; cursor: pointer; }
  .progress { position: relative; height: 16px; display: flex; align-items: center; cursor: pointer; touch-action: none; }
  .progress.unavailable { opacity: .35; pointer-events: none; }
  .progress-track { position: relative; width: 100%; height: 3px; border-radius: 2px; background: rgba(255,255,255,.25); overflow: hidden; transition: height .12s ease; }
  .progress:hover .progress-track, .progress:focus-visible .progress-track { height: 5px; }
  .buffered, .played { position: absolute; inset: 0 auto 0 0; }
  .buffered { background: rgba(255,255,255,.35); }
  .played { background: #f2293a; z-index: 2; }
  .markers { position: absolute; inset: 0; pointer-events: none; z-index: 1; }
  .markers i { position: absolute; top: 0; bottom: 0; display: block; pointer-events: auto; }
  .chapter-marker { width: 2px; background: rgba(0,0,0,.7); }
  .sponsor-marker { min-width: 2px; border-radius: 2px; background: #00d400; opacity: .9; }
  .knob { position: absolute; top: 50%; width: 12px; height: 12px; border-radius: 50%; background: #f2293a; transform: translate(-50%,-50%) scale(0); transition: transform .12s ease; pointer-events: none; z-index: 3; }
  .progress:hover .knob, .progress:focus-visible .knob { transform: translate(-50%,-50%) scale(1); }
  .progress-tooltip { position: absolute; bottom: 22px; transform: translateX(-50%); padding: 4px 8px; border-radius: 5px; background: rgba(0,0,0,.85); color: #fff; font-size: 11.5px; white-space: nowrap; display: flex; flex-direction: column; align-items: center; gap: 2px; opacity: 0; pointer-events: none; }
  .progress-tooltip.show { opacity: 1; }
  .chapter { max-width: 220px; overflow: hidden; text-overflow: ellipsis; font-weight: 500; }
  .volume-wrap { display: flex; align-items: center; }
  .volume { width: 0; opacity: 0; transition: width .18s ease, opacity .18s ease; }
  .volume-wrap:hover .volume, .volume:focus-visible { width: 64px; opacity: 1; }
  .caption-menu-wrap { position: relative; display: flex; }
  .caption-menu { position: absolute; right: 0; bottom: 42px; width: 230px; max-height: min(300px, 70vh); padding: 7px; display: flex; flex-direction: column; gap: 8px; color: #fff; background: rgba(22,22,27,.98); border-radius: 14px; box-shadow: 0 18px 42px rgba(0,0,0,.58); pointer-events: auto; overflow: hidden; }
  .caption-menu[hidden] { display: none; }
  .caption-toggle { display: flex; align-items: center; justify-content: space-between; padding: 5px 5px 9px; border-bottom: 1px solid rgba(255,255,255,.09); color: rgba(255,255,255,.72); font-size: 12px; }
  button.caption-switch { position: relative; width: 32px; height: 18px; padding: 0; border-radius: 999px; background: rgba(255,255,255,.22); opacity: 1; }
  button.caption-switch:hover { background: rgba(255,255,255,.3); }
  button.caption-switch.active { background: #3ea6ff; }
  .caption-switch span { position: absolute; left: 3px; top: 3px; width: 12px; height: 12px; border-radius: 50%; background: #fff; transition: transform .16s ease; }
  .caption-switch.active span { transform: translateX(14px); }
  .caption-list { min-height: 0; overflow-y: auto; overscroll-behavior: contain; scrollbar-color: rgba(255,255,255,.28) transparent; padding-top: 4px; }
  .caption-list button { display: flex; align-items: center; justify-content: space-between; gap: 8px; width: 100%; height: auto; min-height: 32px; padding: 7px 8px; border-radius: 8px; color: #fff; font-size: 13px; text-align: left; opacity: 1; }
  .caption-list button:hover { background: rgba(255,255,255,.09); }
  .caption-list button.is-selected { color: #3ea6ff; font-weight: 500; background: color-mix(in srgb, #3ea6ff 14%, transparent); }
  .caption-option-status { display: inline-flex; align-items: center; justify-content: flex-end; min-width: 14px; font-size: 14px; }
  .toast { position: absolute; left: 50%; bottom: 74px; transform: translate(-50%, 5px) scale(.94); padding: 7px 10px; border-radius: 999px; background: rgba(10,10,10,.62); color: #fff; backdrop-filter: blur(7px); opacity: 0; transition: .18s ease; max-width: 80vw; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-size: 13px; font-weight: 650; }
  .toast.show { opacity: 1; transform: translate(-50%, 0); }
  :host(.mode-live) .controls { background: linear-gradient(to top, rgba(8,8,10,.94), rgba(8,8,10,.48) 62%, transparent); }
  :host(.mode-live) .time { display: none; }
  :host(.mode-live) .played, :host(.mode-live) .knob { background: #f2293a; }
  :host(.mode-shorts) .controls { left: calc(var(--ytze-short-left, 0px) + 7px); right: calc(var(--ytze-short-right, 0px) + 7px); bottom: calc(7px + env(safe-area-inset-bottom, 0px)); padding: 38px max(9px, env(safe-area-inset-right, 0px)) max(8px, env(safe-area-inset-bottom, 0px)) max(9px, env(safe-area-inset-left, 0px)); border-radius: 18px; background: linear-gradient(to top, rgba(8,8,10,.92), rgba(8,8,10,.46) 64%, transparent); }
  :host(.mode-shorts) .buttons { gap: 7px; }
  :host(.mode-shorts) .buttons > button, :host(.mode-shorts) .volume-wrap > button, :host(.mode-shorts) .caption-menu-wrap > button { width: 40px; height: 40px; border-radius: 50%; background: rgba(20,20,24,.58); backdrop-filter: blur(8px); }
  :host(.mode-shorts) .buttons > button:hover, :host(.mode-shorts) .volume-wrap > button:hover, :host(.mode-shorts) .caption-menu-wrap > button:hover { background: rgba(255,255,255,.2); }
  :host(.mode-shorts) .volume, :host(.mode-shorts) .time, :host(.mode-shorts) .pip { display: none; }
  :host(.mode-shorts) .progress { height: 12px; }
  :host(.mode-shorts) .progress-track { height: 2px; }
  :host(.mode-shorts) .progress:hover .progress-track, :host(.mode-shorts) .progress:focus-visible .progress-track { height: 4px; }
  :host(.mode-shorts) .caption-menu { bottom: 48px; max-height: min(260px, 58vh); }
  :host(.mode-shorts) .toast { bottom: 78px; }
  :host(.mode-shorts) .big-play { width: 58px; height: 58px; background: rgba(12,12,15,.58); backdrop-filter: blur(8px); }
  :host(.mode-shorts):not(.visible) .big-play { display: none; }
  @media (max-width: 480px) { .time, .pip { display: none; } .buttons { gap: 1px; } button { width: 34px; } .controls { padding-inline: 8px; } }
  @media (prefers-reduced-motion: reduce) { .controls, .toast, .knob, .progress-track { transition: none; } .live-edge.active .live-dot { animation: none; } }
  :host(.mode-preview) .controls {
    align-items: center;
    background:
      linear-gradient(
        to top,
        rgba(0, 0, 0, 0.85),
        rgba(0, 0, 0, 0.4) 60%,
        transparent
      );
    bottom: 0;
    display: flex;
    gap: 8px;
    left: 0;
    opacity: 1;
    padding: 18px 8px 7px;
    pointer-events: auto;
    right: 0;
  }

  :host(.mode-preview) .progress {
    flex: 1;
    height: 16px;
    min-width: 0;
  }

  :host(.mode-preview) .progress-track {
    background: rgba(255, 255, 255, 0.25);
    border-radius: 999px;
    height: 3px;
    overflow: hidden;
    transition: height 0.12s ease;
  }

  :host(.mode-preview) .progress:hover .progress-track,
  :host(.mode-preview) .progress:focus-visible .progress-track {
    height: 5px;
  }

  :host(.mode-preview) .played {
    background: #f2293a;
    border-radius: 999px;
  }

  :host(.mode-preview) .knob {
    background: #f2293a;
    border-radius: 50%;
    height: 12px;
    transform: translate(-50%, -50%) scale(0);
    transition: transform 0.12s ease;
    width: 12px;
  }

  :host(.mode-preview) .progress:hover .knob,
  :host(.mode-preview) .progress:focus-visible .knob {
    transform: translate(-50%, -50%) scale(1);
  }

  :host(.mode-preview) .buttons {
    align-items: center;
    display: flex;
    flex: 0 0 auto;
    gap: 0;
    margin: 0;
  }

  :host(.mode-preview) .buttons > :not(.volume-wrap) {
    display: none;
  }

  :host(.mode-preview) .volume-wrap {
    align-items: center;
    display: flex;
  }

  :host(.mode-preview) .volume {
    display: none;
  }

  :host(.mode-preview) .mute {
    background: transparent;
    border-radius: 6px;
    color: #fff;
    height: 34px;
    min-height: 34px;
    min-width: 38px;
    opacity: 0.92;
    padding: 0;
    width: 38px;
  }

  :host(.mode-preview) .mute:hover,
  :host(.mode-preview) .mute:focus-visible {
    background: rgba(255, 255, 255, 0.14);
    opacity: 1;
  }

  :host(.mode-preview) .mute svg {
    height: 20px;
    width: 20px;
  }

  :host(.mode-preview) .big-play,
  :host(.mode-preview) .play,
  :host(.mode-preview) .time,
  :host(.mode-preview) .live-edge,
  :host(.mode-preview) .spacer,
  :host(.mode-preview) .caption-menu-wrap,
  :host(.mode-preview) .pip,
  :host(.mode-preview) .fullscreen,
  :host(.mode-preview) .volume,
  :host(.mode-preview) .buffered,
  :host(.mode-preview) .markers,
  :host(.mode-preview) .progress-tooltip,
  :host(.mode-preview) .toast {
    display: none !important;
  }

  @media (prefers-reduced-motion: reduce) {
    :host(.mode-preview) .progress-track,
    :host(.mode-preview) .knob {
      transition: none;
    }
  }
`;
})();
