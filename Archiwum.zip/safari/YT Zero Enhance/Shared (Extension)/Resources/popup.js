(() => {
  // src/core.ts
  var DEFAULT_SETTINGS = {
    instanceUrl: "",
    redirectEnabled: false,
    enhancePlayer: true,
    replaceControls: true,
    screenshotFormat: "png",
    screenshotQuality: 0.92,
    screenshotFilename: "{channel}_{title}_{timestamp_ms}",
    seekSeconds: 5,
    frameRate: 30
  };
  var VIDEO_ID = /^[A-Za-z0-9_-]{11}$/;
  var CHANNEL_ID = /^UC[A-Za-z0-9_-]{22}$/;
  var PLAYLIST_ID = /^[A-Za-z0-9_-]{10,80}$/;
  var YT_NO_REDIRECT_MARKER = "ytNoRedirect";
  function youtubeUrl(input) {
    try {
      const url = new URL(input);
      const host = url.hostname.replace(/^www\./, "").toLowerCase();
      if (!["youtube.com", "m.youtube.com", "music.youtube.com", "youtube-nocookie.com", "youtu.be"].includes(host))
        return null;
      return /^https?:$/.test(url.protocol) ? url : null;
    } catch {
      return null;
    }
  }
  function localBase(instanceUrl) {
    try {
      const base = new URL(instanceUrl);
      return /^https?:$/.test(base.protocol) ? base : null;
    } catch {
      return null;
    }
  }
  function withInstancePath(instanceUrl, path, search = "") {
    const base = localBase(instanceUrl);
    if (!base)
      return null;
    const prefix = base.pathname.replace(/\/$/, "");
    base.pathname = `${prefix}${path}`.replace(/\/{2,}/g, "/");
    base.search = search;
    base.hash = "";
    return base.toString();
  }
  function hasNoRedirectMarker(input) {
    const url = youtubeUrl(input);
    return Boolean(url?.hash.slice(1).split("&").includes(YT_NO_REDIRECT_MARKER));
  }
  function embeddedPlayerModeForPage(input) {
    try {
      return /\/shorts(?:\/|$)/.test(new URL(input).pathname) ? "shorts" : "standard";
    } catch {
      return "standard";
    }
  }
  function resolveEmbeddedPlayerMode(requested, authoritative, nativeLive) {
    if (requested === "preview")
      return "preview";
    return requested === "live" || !authoritative && nativeLive ? "live" : requested;
  }
  function isPreviewEmbedUrl(input) {
    try {
      const url = new URL(input);
      const host = url.hostname.replace(/^www\./, "").toLowerCase();
      return ["youtube.com", "youtube-nocookie.com"].includes(host) && /^\/embed\/[A-Za-z0-9_-]{11}$/.test(url.pathname) && url.searchParams.get("ytzero_preview") === "1";
    } catch {
      return false;
    }
  }
  function playerTimeline(currentTime, duration, liveRange) {
    const finiteDuration = Number.isFinite(duration) && duration > 0 ? duration : 0;
    const live = liveRange && Number.isFinite(liveRange.start) && Number.isFinite(liveRange.end) && liveRange.end > liveRange.start ? liveRange : null;
    const start = live?.start ?? 0;
    const end = live?.end ?? finiteDuration;
    const length = Math.max(0, end - start);
    const fraction = length ? Math.min(1, Math.max(0, (currentTime - start) / length)) : 0;
    return { start, end, length, fraction, liveDelay: live ? Math.max(0, live.end - currentTime) : null };
  }
  function playableLiveRange(seekableStart, seekableEnd, currentTime, bufferedEnd, observedPlayableEnd, safetySeconds = 0.5) {
    if (!Number.isFinite(seekableStart) || !Number.isFinite(seekableEnd) || seekableEnd <= seekableStart)
      return null;
    const buffered = bufferedEnd != null && Number.isFinite(bufferedEnd) ? bufferedEnd - Math.max(0, safetySeconds) : seekableStart;
    const playableEnd = Math.min(seekableEnd, Math.max(currentTime, observedPlayableEnd, buffered));
    return playableEnd > seekableStart ? { start: seekableStart, end: playableEnd } : null;
  }
  function parseTimestamp(value) {
    if (!value)
      return 0;
    if (/^\d+$/.test(value))
      return Number(value);
    const match = value.toLowerCase().match(/^(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s?)?$/);
    if (!match)
      return 0;
    return Number(match[1] || 0) * 3600 + Number(match[2] || 0) * 60 + Number(match[3] || 0);
  }
  function youtubeVideoId(input) {
    let url;
    try {
      url = new URL(input);
    } catch {
      return null;
    }
    const host = url.hostname.replace(/^www\./, "").toLowerCase();
    let id = null;
    if (host === "youtu.be")
      id = url.pathname.split("/").filter(Boolean)[0] ?? null;
    if (["youtube.com", "m.youtube.com", "music.youtube.com", "youtube-nocookie.com"].includes(host)) {
      if (url.pathname === "/watch")
        id = url.searchParams.get("v");
      else {
        const match = url.pathname.match(/^\/(?:shorts|live|embed)\/([^/?#]+)/);
        id = match?.[1] ?? null;
      }
    }
    return id && VIDEO_ID.test(id) ? id : null;
  }
  function youtubePlaylistId(input) {
    const url = youtubeUrl(input);
    if (!url)
      return null;
    let id = url.pathname === "/playlist" || url.pathname === "/watch" ? url.searchParams.get("list") : null;
    if (!id)
      id = url.pathname.match(/^\/show\/VL([A-Za-z0-9_-]+)(?:\/|$)/)?.[1] ?? null;
    return id && PLAYLIST_ID.test(id) ? id : null;
  }
  function isRedirectableYouTubeUrl(input) {
    const url = youtubeUrl(input);
    if (!url || hasNoRedirectMarker(input))
      return false;
    if (/^\/embed\//.test(url.pathname))
      return false;
    return youtubeVideoId(input) !== null || youtubePlaylistId(input) !== null;
  }
  function localWatchUrl(input, instanceUrl) {
    if (!isRedirectableYouTubeUrl(input))
      return null;
    const id = youtubeVideoId(input);
    if (!id)
      return null;
    let source;
    try {
      source = new URL(input);
    } catch {
      return null;
    }
    const seconds = parseTimestamp(source.searchParams.get("t") ?? source.searchParams.get("start"));
    const playlistId = youtubePlaylistId(input);
    const path = playlistId ? `/watch/${id}/playlist/${encodeURIComponent(playlistId)}` : `/watch/${id}`;
    return withInstancePath(instanceUrl, path, seconds > 0 ? `?t=${seconds}` : "");
  }
  function localContentUrl(input, instanceUrl, resolvedChannelId) {
    const source = youtubeUrl(input);
    if (!source)
      return null;
    const unmarked = new URL(source);
    unmarked.hash = "";
    const video = youtubeVideoId(unmarked.toString());
    if (video && !/^\/embed\//.test(source.pathname))
      return localWatchUrl(unmarked.toString(), instanceUrl);
    const playlistId = youtubePlaylistId(unmarked.toString());
    if (playlistId)
      return withInstancePath(instanceUrl, `/playlist/${encodeURIComponent(playlistId)}`);
    const directChannelId = source.pathname.match(/^\/channel\/([^/?#]+)/)?.[1] ?? "";
    const channelId = resolvedChannelId && CHANNEL_ID.test(resolvedChannelId) ? resolvedChannelId : directChannelId;
    if (CHANNEL_ID.test(channelId))
      return withInstancePath(instanceUrl, `/channel/${channelId}`);
    const channelPath = source.pathname.match(/^\/(?:@([^/?#]+)|(?:c|user)\/([^/?#]+))(?:\/|$)/);
    const channelQuery = channelPath?.[1] ? `@${channelPath[1]}` : channelPath?.[2];
    if (channelQuery)
      return withInstancePath(instanceUrl, "/search", `?q=${encodeURIComponent(channelQuery)}`);
    return null;
  }
  function formatClock(seconds, milliseconds = false) {
    const safe = Math.max(0, Number.isFinite(seconds) ? seconds : 0);
    const hours = Math.floor(safe / 3600);
    const minutes = Math.floor(safe % 3600 / 60);
    const secs = Math.floor(safe % 60);
    const base = `${hours ? `${String(hours).padStart(2, "0")}-` : ""}${String(minutes).padStart(2, "0")}-${String(secs).padStart(2, "0")}`;
    return milliseconds ? `${base}-${String(Math.floor(safe % 1 * 1000)).padStart(3, "0")}` : base;
  }
  function safeFilename(value) {
    const sanitized = value.replace(/[<>:"/\\|?*\u0000-\u001f]/g, "_").replace(/\s+/g, " ").replace(/[. ]+$/g, "").trim().slice(0, 180) || "ytzero-frame";
    return /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(sanitized) ? `_${sanitized}` : sanitized;
  }
  function screenshotFilename(template, values, extension) {
    const seconds = Math.max(0, values.seconds ?? 0);
    const replacements = {
      channel: values.channel || "YouTube",
      title: values.title || values.videoId || "video",
      video_id: values.videoId || "unknown",
      timestamp: formatClock(seconds),
      timestamp_ms: formatClock(seconds, true)
    };
    const expanded = template.replace(/\{(channel|title|video_id|timestamp|timestamp_ms)\}/g, (_, key) => replacements[key]);
    return `${safeFilename(expanded)}.${extension}`;
  }
  function normalizeSettings(input) {
    const merged = { ...DEFAULT_SETTINGS, ...input ?? {} };
    merged.instanceUrl = String(merged.instanceUrl || DEFAULT_SETTINGS.instanceUrl).replace(/\/$/, "");
    merged.screenshotFormat = merged.screenshotFormat === "jpeg" || merged.screenshotFormat === "webp" ? merged.screenshotFormat : "png";
    merged.screenshotQuality = Math.min(1, Math.max(0.1, Number(merged.screenshotQuality) || 0.92));
    merged.seekSeconds = Math.min(60, Math.max(1, Number(merged.seekSeconds) || 5));
    merged.frameRate = Math.min(120, Math.max(1, Number(merged.frameRate) || 30));
    return merged;
  }
  function containedMediaRect(element, mediaWidth, mediaHeight) {
    if (element.width <= 0 || element.height <= 0 || mediaWidth <= 0 || mediaHeight <= 0)
      return element;
    const elementRatio = element.width / element.height;
    const mediaRatio = mediaWidth / mediaHeight;
    if (elementRatio > mediaRatio) {
      const width = element.height * mediaRatio;
      return { x: element.x + (element.width - width) / 2, y: element.y, width, height: element.height };
    }
    const height = element.width / mediaRatio;
    return { x: element.x, y: element.y + (element.height - height) / 2, width: element.width, height };
  }

  // src/shortcuts.ts
  var SHORTCUT_ACTIONS = [
    "togglePlay",
    "temporaryBoost",
    "seekBack10",
    "seekForward10",
    "previousVideo",
    "nextVideo",
    "previousFrame",
    "nextFrame",
    "speedDown",
    "speedUp",
    "seekPercent",
    "previousChapter",
    "nextChapter",
    "seekBack",
    "seekForward",
    "volumeUp",
    "volumeDown",
    "toggleCaptions",
    "subtitleLarger",
    "subtitleSmaller",
    "toggleFullscreen",
    "toggleTheater",
    "togglePictureInPicture",
    "close",
    "toggleMute",
    "screenshot"
  ];
  var DEFAULT_SHORTCUT_BINDINGS = {
    togglePlay: "KeyK",
    temporaryBoost: "Space",
    seekBack10: "KeyJ",
    seekForward10: "KeyL",
    previousVideo: "Shift+KeyP",
    nextVideo: "Shift+KeyN",
    previousFrame: "Comma",
    nextFrame: "Period",
    speedDown: "Shift+Comma",
    speedUp: "Shift+Period",
    seekPercent: "Digit0-9",
    previousChapter: "Alt+ArrowLeft",
    nextChapter: "Alt+ArrowRight",
    seekBack: "ArrowLeft",
    seekForward: "ArrowRight",
    volumeUp: "ArrowUp",
    volumeDown: "ArrowDown",
    toggleCaptions: "KeyC",
    subtitleLarger: "Shift+Equal",
    subtitleSmaller: "Minus",
    toggleFullscreen: "KeyF",
    toggleTheater: "KeyT",
    togglePictureInPicture: "KeyI",
    close: "Escape",
    toggleMute: "KeyM",
    screenshot: "KeyS"
  };
  var ACTION_IDS = new Set(SHORTCUT_ACTIONS);
  var MODIFIER_ORDER = ["Ctrl", "Alt", "Shift", "Meta"];
  var MODIFIERS = new Set(MODIFIER_ORDER);
  var CODE = /^(?:Key[A-Z]|Digit[0-9]|Digit0-9|F(?:[1-9]|1[0-2])|Numpad(?:Add|Subtract)|Arrow(?:Left|Right|Up|Down)|Space|Escape|Enter|Tab|Backspace|Delete|Home|End|PageUp|PageDown|Comma|Period|Minus|Equal|BracketLeft|BracketRight|Semicolon|Quote|Backslash|Slash|Backquote)$/;
  function normalizeShortcutChord(value) {
    if (value === null)
      return null;
    if (typeof value !== "string" || value.length > 80)
      return;
    const parts = value.split("+");
    const code = parts.pop();
    if (!code || !CODE.test(code) || parts.some((part, index) => !MODIFIERS.has(part) || parts.indexOf(part) !== index))
      return;
    return [...MODIFIER_ORDER.filter((modifier) => parts.includes(modifier)), code].join("+");
  }
  function resolveShortcutBindings(value, diagnostic = (message) => console.warn(message)) {
    if (value === undefined)
      return { ...DEFAULT_SHORTCUT_BINDINGS };
    const bindings = Object.fromEntries(SHORTCUT_ACTIONS.map((action) => [action, null]));
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      diagnostic("YT Zero Enhance ignored a malformed keyboard shortcut map");
      return bindings;
    }
    const input = value;
    for (const [action, rawChord] of Object.entries(input)) {
      if (!ACTION_IDS.has(action))
        continue;
      const chord = normalizeShortcutChord(rawChord);
      if (chord === undefined) {
        diagnostic(`YT Zero Enhance disabled malformed keyboard shortcut: ${action}`);
        continue;
      }
      bindings[action] = chord;
    }
    return bindings;
  }
  function shortcutChordFromEvent(event) {
    if (!CODE.test(event.code) || event.code === "Digit0-9")
      return null;
    return [event.ctrlKey && "Ctrl", event.altKey && "Alt", event.shiftKey && "Shift", event.metaKey && "Meta", event.code].filter(Boolean).join("+");
  }
  function shortcutMatches(event, chord) {
    if (!chord)
      return false;
    const eventChord = shortcutChordFromEvent(event);
    if (chord.endsWith("Digit0-9")) {
      const prefix = chord.slice(0, -"Digit0-9".length);
      return /^Digit[0-9]$/.test(event.code) && eventChord === `${prefix}${event.code}`;
    }
    return eventChord === chord;
  }
  function matchingShortcutAction(event, bindings) {
    for (const action of SHORTCUT_ACTIONS)
      if (shortcutMatches(event, bindings[action]))
        return action;
    return null;
  }

  class ShortcutRegistry {
    #bindings = { ...DEFAULT_SHORTCUT_BINDINGS };
    constructor(value = undefined, diagnostic) {
      this.replace(value, diagnostic);
    }
    replace(value, diagnostic) {
      this.#bindings = resolveShortcutBindings(value, diagnostic);
    }
    match(event) {
      return matchingShortcutAction(event, this.#bindings);
    }
    binding(action) {
      return this.#bindings[action];
    }
  }
  function isEditableShortcutEvent(event) {
    const path = typeof event.composedPath === "function" ? event.composedPath() : [event.target];
    return path.some((target) => {
      const element = target;
      const tag = String(element?.tagName ?? "").toLowerCase();
      return tag === "input" || tag === "textarea" || tag === "select" || Boolean(element?.isContentEditable) || Boolean(element?.closest?.("[contenteditable]"));
    });
  }
  var REPEATABLE_ACTIONS = new Set([
    "seekBack10",
    "seekForward10",
    "seekBack",
    "seekForward",
    "volumeUp",
    "volumeDown"
  ]);
  function shortcutAllowsRepeat(action) {
    return REPEATABLE_ACTIONS.has(action);
  }
  var PARENT_OWNED_SHORTCUT_ACTIONS = new Set([
    "previousVideo",
    "nextVideo",
    "toggleTheater",
    "close"
  ]);
  var TRANSPORT_ACTIONS = new Set([
    "togglePlay",
    "temporaryBoost",
    "seekBack10",
    "seekForward10",
    "previousVideo",
    "nextVideo",
    "previousFrame",
    "nextFrame",
    "speedDown",
    "speedUp",
    "seekPercent",
    "previousChapter",
    "nextChapter",
    "seekBack",
    "seekForward"
  ]);
  var LIVESTREAM_BLOCKED_ACTIONS = new Set([
    "temporaryBoost",
    "previousFrame",
    "nextFrame",
    "speedDown",
    "speedUp",
    "seekPercent"
  ]);
  function shortcutOperationBlocked(action, livestream, transportLocked) {
    return transportLocked && TRANSPORT_ACTIONS.has(action) || livestream && LIVESTREAM_BLOCKED_ACTIONS.has(action);
  }
  function stepShortcutPlaybackRate(current, direction) {
    const safeCurrent = Number.isFinite(current) ? current : 1;
    const stepped = Math.round((safeCurrent + direction * 0.25) / 0.25) * 0.25;
    return Math.min(2, Math.max(0.25, stepped));
  }

  class OwnedPlaybackRate {
    #value = 1;
    constructor(rate = 1, livestream = false) {
      this.reset(rate, livestream);
    }
    get value() {
      return this.#value;
    }
    reset(rate, livestream = false) {
      const safeRate = Number.isFinite(rate) ? rate : 1;
      this.#value = livestream ? 1 : Math.min(4, Math.max(0.25, safeRate));
      return this.#value;
    }
    step(direction) {
      this.#value = stepShortcutPlaybackRate(this.#value, direction);
      return this.#value;
    }
  }
  function advanceOwnedPlaybackRate(ownedRate, direction, applyPlaybackRate) {
    const nextRate = ownedRate.step(direction);
    Promise.resolve(applyPlaybackRate(nextRate)).catch(() => {});
    return nextRate;
  }
  function chapterShortcutTarget(action, currentTime, chapters) {
    if (!Number.isFinite(currentTime) || !chapters.length)
      return null;
    const starts = chapters.map((chapter) => chapter.start).filter(Number.isFinite).sort((a, b) => a - b);
    if (!starts.length)
      return null;
    if (action === "previousChapter")
      return [...starts].reverse().find((start) => start < currentTime - 1) ?? 0;
    return starts.find((start) => start > currentTime + 1) ?? null;
  }
  function shortcutEventPayload(action, event, value) {
    return {
      action,
      key: event.key,
      code: event.code,
      repeat: event.repeat,
      ...typeof value === "number" ? { value } : {},
      modifiers: { alt: event.altKey, ctrl: event.ctrlKey, meta: event.metaKey, shift: event.shiftKey }
    };
  }

  class TemporaryBoostController {
    dependencies;
    #timer = 0;
    #active = false;
    #chord = null;
    #event = null;
    constructor(dependencies) {
      this.dependencies = dependencies;
    }
    get active() {
      return this.#active;
    }
    get pending() {
      return this.#timer !== 0;
    }
    get chord() {
      return this.#chord;
    }
    keydown(event) {
      if (event.repeat || this.#timer || this.#active || this.dependencies.isBlocked())
        return;
      this.#chord = shortcutChordFromEvent(event);
      this.#event = event;
      this.#timer = this.dependencies.schedule(() => {
        this.#timer = 0;
        if (this.dependencies.isBlocked()) {
          this.#chord = null;
          this.#event = null;
          return;
        }
        this.#active = true;
        this.dependencies.setRate(2);
        if (this.#event)
          this.dependencies.applied(this.#event, 2);
      }, 220);
    }
    keyup(event) {
      if (!this.#chord || shortcutChordFromEvent(event) !== this.#chord)
        return false;
      const pressedEvent = this.#event;
      this.#chord = null;
      this.#event = null;
      if (this.#timer) {
        this.dependencies.cancel(this.#timer);
        this.#timer = 0;
        this.dependencies.togglePlay();
        if (pressedEvent)
          this.dependencies.applied(pressedEvent);
      } else if (this.#active) {
        this.#active = false;
        this.dependencies.setRate(this.dependencies.effectiveRate());
      }
      return true;
    }
    reset() {
      if (this.#timer)
        this.dependencies.cancel(this.#timer);
      if (this.#active)
        this.dependencies.setRate(this.dependencies.effectiveRate());
      this.#timer = 0;
      this.#active = false;
      this.#chord = null;
      this.#event = null;
    }
  }

  // src/i18n.ts
  var EN = {
    tagline: "Your videos, your settings",
    extensionState: "Extension status",
    firstRun: "First run",
    connectInstance: "Connect your instance",
    onboardingLead: "Open any page on your YT Zero instance. Once it is loaded, return here and connect the active tab.",
    pairingAria: "How to connect YT Zero",
    stepOpenInstance: "Open your YT Zero instance",
    stepClickBelow: "Click the button below",
    pairThisTab: "Connect this tab",
    defaultInstance: "Default instance",
    settingsSynced: "Settings synchronized",
    quickSettings: "Quick extension settings",
    redirectLinks: "Redirect links",
    redirectLinksDescription: "Supported video and playlist links will open in the default instance",
    redirectTo: "Redirect to",
    enhancePlayer: "Enhance the player",
    enhancePlayerDescription: "Appearance and behavior consistent with YT Zero",
    saveFrame: "Save frame",
    openYtZero: "Open YT Zero",
    pairAnother: "+ Connect the current tab as another instance",
    instancesAndSettings: "Instances and settings",
    browserExtension: "Browser extension",
    optionsIntro: "Connected instances and active profile settings.",
    connectFirstInstance: "Connect your first instance",
    connectFirstHelp: "Open any page on YT Zero, click the extension icon and choose “Connect this tab”.",
    yourYtZero: "Your YT Zero",
    connectedInstances: "Connected instances",
    addAnotherHelp: "To add another one, open it and use the extension icon.",
    playerSettings: "Player settings",
    changeInYtZero: "Change in YT Zero",
    readonlyNote: "These values come from the active YT Zero profile and are read-only here.",
    integration: "Integration",
    ytZeroControls: "YT Zero controls",
    quality: "Quality",
    speed: "Speed",
    seek: "Seeking",
    frameStep: "Frame stepping",
    captions: "Captions",
    screenshots: "Screenshots",
    defaultInstanceTip: "Redirected video links go to this instance. The player on every connected instance uses its own profile.",
    connectYtZero: "Connect to YT Zero",
    enhancementsDisabled: "Enhancements are disabled in YT Zero",
    findingSettings: "Looking for YT Zero settings in this tab…",
    openPageFirst: "Open a page on your YT Zero instance first.",
    openSpecificPage: "Open a page on your YT Zero instance and try again.",
    settingsNotReady: "YT Zero has not exposed its settings yet. Wait for the page to load and try again.",
    permissionNeeded: "Access to this instance is required to synchronize settings.",
    pairFailed: "Could not connect the instance.",
    pairedReloading: "Connected. Reloading the page…",
    saved: "Saved",
    capturing: "Capturing…",
    frameSaved: "Frame saved",
    noActivePlayer: "No active player",
    enabled: "Enabled",
    disabled: "Disabled",
    automatic: "Automatic",
    disabledByDefault: "Disabled by default",
    category: "category",
    categories: "categories",
    defaultBadge: "Default",
    open: "Open",
    makeDefault: "Make default",
    remove: "Remove",
    settings: "Settings",
    seconds: "seconds",
    defaultChanged: "Default instance changed.",
    instanceRemoved: "Instance removed.",
    removeConnection: "Remove connection to",
    play: "Play",
    playPause: "Play or pause",
    mute: "Mute",
    volume: "Volume",
    progress: "Video position",
    playerControls: "YT Zero player",
    captionsShortcut: "Captions (C)",
    saveFrameShortcut: "Save frame (S)",
    firefoxCaptureShortcut: "In Firefox, use Alt+Shift+S (physical Control+Shift+S on macOS) to save a frame.",
    cinemaMode: "Cinema mode",
    cinemaModeShortcut: "Cinema mode (T)",
    pictureInPicture: "Picture in picture",
    fullscreen: "Fullscreen",
    live: "LIVE",
    goLive: "Go live",
    captionsUnavailable: "Captions unavailable",
    invalidCaptionLanguage: "Invalid caption language",
    pipUnavailable: "Picture in picture unavailable",
    captureError: "Capture error",
    unknown: "unknown",
    skipped: "Skipped",
    oneFrameBack: "−1 frame",
    oneFrameForward: "+1 frame",
    canvasUnavailable: "Canvas unavailable",
    imageEncodingFailed: "Image encoding failed",
    embeddedSettingsReadFailed: "Could not read the settings embedded on the YT Zero page.",
    unknownConfigurationFormat: "The instance returned an unknown YT Zero Enhance configuration format.",
    invalidConfigurationVersion: "The instance returned an invalid configuration version.",
    newerExtensionRequired: "This configuration requires a newer extension version.",
    unsupportedBridge: "The instance uses an unsupported YT Zero Enhance bridge version.",
    incompatibleBridgeEvents: "The instance returned incompatible bridge event names.",
    invalidPlayerFrame: "Invalid player frame",
    missingQualityConfiguration: "Missing quality configuration",
    unpairedPage: "This YT Zero page is not connected to the extension",
    pairingOnlyFromExtension: "Pairing can only be started from the extension window",
    invalidInstanceAddress: "Could not recognize the instance address",
    pairedInstanceNotFound: "Connected instance not found",
    invalidBridgeContext: "Invalid bridge context",
    invalidScreenshotRequest: "Invalid bridge screenshot request",
    activeEmbeddedPlayerNotFound: "No active embedded player found",
    activeTabNotFound: "No active tab found",
    captureOutsideYouTubeRejected: "A capture outside the embedded player was rejected",
    playerPositionFailed: "Could not determine the player position"
  };
  function uiLanguage() {
    let language = globalThis.navigator?.language || "en";
    try {
      language = (globalThis.browser ?? globalThis.chrome)?.i18n?.getUILanguage?.() || language;
    } catch {}
    return /^pl\b/i.test(language) ? "pl" : /^de\b/i.test(language) ? "de" : "en";
  }
  function t(key) {
    try {
      const localized = (globalThis.browser ?? globalThis.chrome)?.i18n?.getMessage?.(key);
      return localized || EN[key] || key;
    } catch {
      return EN[key] || key;
    }
  }
  function localizeDocument(root = document) {
    if (typeof document !== "undefined")
      document.documentElement.lang = uiLanguage();
    root.querySelectorAll("[data-i18n]").forEach((element) => {
      element.textContent = t(element.dataset.i18n);
    });
    root.querySelectorAll("[data-i18n-aria]").forEach((element) => {
      element.setAttribute("aria-label", t(element.dataset.i18nAria));
    });
    root.querySelectorAll("[data-i18n-title]").forEach((element) => {
      element.title = t(element.dataset.i18nTitle);
    });
  }

  // src/contract.ts
  var ENHANCE_CONFIGURATION_FORMAT = "ytzero.enhance-configuration";
  var ENHANCE_CONFIGURATION_VERSION = 1;
  var MAX_CONFIGURATION_DETAIL_LENGTH = 256000;
  var MAX_CONTEXT_DETAIL_LENGTH = 256000;
  var MAX_SCREENSHOT_DETAIL_LENGTH = 16384;
  var MAX_COMMAND_DETAIL_LENGTH = 8192;
  var ENHANCE_BRIDGE_EVENTS = {
    ready: "ytzero:enhance:ready",
    context: "ytzero:enhance:context",
    screenshotRequest: "ytzero:enhance:screenshot-request",
    screenshotResult: "ytzero:enhance:screenshot-result"
  };
  var ENHANCE_PLAYER_EVENTS = {
    captionsToggleRequest: "ytzero:enhance:captions-toggle-request",
    event: "ytzero:enhance:player-event",
    command: "ytzero:enhance:player-command"
  };
  var ENHANCE_PLAYER_COMMANDS = [
    "play",
    "pause",
    "toggle-play",
    "seek-by",
    "seek-to",
    "set-volume",
    "set-muted",
    "toggle-muted",
    "set-playback-rate",
    "set-captions",
    "toggle-captions",
    "set-caption-size",
    "capture-frame",
    "toggle-fullscreen",
    "enter-fullscreen",
    "exit-fullscreen",
    "toggle-picture-in-picture",
    "request-state"
  ];
  var CONTENT_TYPES = ["default", "short", "livestream"];
  function playerPresentationState(localEnabled, localReplaceControls, configuration, nativeControlsVisible) {
    const active = localEnabled && configuration?.enabled === true;
    return { active, replaceControls: active && localReplaceControls && configuration.player.replaceControls && !nativeControlsVisible };
  }
  function embeddedPlayerParameters(configuration) {
    return {
      hl: configuration.player.language,
      controls: configuration.player.replaceControls ? "0" : "1",
      disablekb: configuration.player.replaceControls ? "1" : "0",
      iv_load_policy: "3",
      playsinline: "1",
      modestbranding: "1",
      rel: "0"
    };
  }
  var PLAYBACK_QUALITY_ORDER = ["highres", "hd4320", "hd2880", "hd2160", "hd1440", "hd1080", "hd720", "large", "medium", "small", "tiny"];
  function highestQualityAtOrBelow(available, maximum) {
    if (!Array.isArray(available))
      return null;
    const levels = available.filter((value) => typeof value === "string" && PLAYBACK_QUALITY_ORDER.includes(value));
    if (!levels.length)
      return null;
    const maximumIndex = maximum === "auto" ? 0 : PLAYBACK_QUALITY_ORDER.indexOf(maximum);
    const threshold = maximumIndex < 0 ? 0 : maximumIndex;
    return PLAYBACK_QUALITY_ORDER.slice(threshold).find((quality) => levels.includes(quality)) ?? null;
  }
  var VIDEO_ID2 = /^[A-Za-z0-9_-]{11}$/;
  var COLOR = /^#[0-9a-f]{6}$/i;
  var QUALITY = /^[A-Za-z0-9_-]{1,32}$/;
  var object = (value) => value && typeof value === "object" && !Array.isArray(value) ? value : null;
  function isContentType(value) {
    return CONTENT_TYPES.includes(value);
  }
  function normalizeContentType(value, legacyFallback) {
    return isContentType(value) ? value : legacyFallback;
  }
  function validatePlayerCommand(value) {
    const root = object(value);
    if (root?.version !== 1 || typeof root.requestId !== "string" || !root.requestId.trim() || root.requestId.length > 120 || typeof root.videoId !== "string" || !VIDEO_ID2.test(root.videoId) || !ENHANCE_PLAYER_COMMANDS.includes(root.command))
      return null;
    const input = object(root.payload) ?? {};
    let payload = {};
    if (root.command === "seek-by" || root.command === "seek-to")
      payload = { seconds: finite(input.seconds, 0, -86400 * 30, 86400 * 30) };
    else if (root.command === "set-volume")
      payload = { volume: finite(input.volume, 1, 0, 1) };
    else if (root.command === "set-muted" || root.command === "set-captions")
      payload = { enabled: input.enabled === true };
    else if (root.command === "set-playback-rate")
      payload = { rate: finite(input.rate, 1, 0.25, 4) };
    else if (root.command === "set-caption-size")
      payload = { pixels: finite(input.pixels, 19, 12, 48) };
    return { version: 1, requestId: root.requestId.trim(), videoId: root.videoId, command: root.command, payload };
  }
  function validatePlayerEvent(value) {
    const root = object(value);
    const types = ["ready", "state", "shortcut", "captions-toggle-request", "ended", "command-result"];
    if (root?.version !== 1 || typeof root.videoId !== "string" || !VIDEO_ID2.test(root.videoId) || typeof root.type !== "string" || !types.includes(root.type))
      return null;
    return { version: 1, videoId: root.videoId, type: root.type, timestamp: finite(root.timestamp, Date.now(), 0, Number.MAX_SAFE_INTEGER), payload: object(root.payload) ?? {} };
  }
  var finite = (value, fallback, min, max) => {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? Math.min(max, Math.max(min, parsed)) : fallback;
  };
  var text = (value, fallback, max = 200) => typeof value === "string" && value.trim() ? value.trim().slice(0, max) : fallback;
  var format = (value, fallback = "png") => value === "jpeg" || value === "webp" || value === "png" ? value : fallback;
  var style = (value) => {
    const input = object(value) ?? {};
    return {
      fontSizePx: finite(input.fontSizePx, 19, 12, 48),
      color: typeof input.color === "string" && COLOR.test(input.color) ? input.color : "#ffffff",
      backgroundOpacityPercent: finite(input.backgroundOpacityPercent, 75, 0, 100)
    };
  };
  function captionLanguages(value) {
    return Array.isArray(value) ? value.flatMap((entry) => {
      if (!entry || typeof entry !== "object")
        return [];
      const language = entry;
      if (typeof language.code !== "string" || typeof language.label !== "string")
        return [];
      const code = language.code.trim().slice(0, 32);
      const label = language.label.trim().slice(0, 120);
      return code && label ? [{ code, label }] : [];
    }).slice(0, 250) : [];
  }
  function configuredPageMatches(pageUrl, instanceUrl) {
    try {
      const page = new URL(pageUrl);
      const instance = new URL(instanceUrl);
      const prefix = instance.pathname.replace(/\/$/, "");
      return page.origin === instance.origin && (page.pathname === prefix || page.pathname.startsWith(`${prefix}/`));
    } catch {
      return false;
    }
  }
  function hostPermissionPattern(instanceUrl) {
    try {
      const url = new URL(instanceUrl);
      return /^https?:$/.test(url.protocol) ? `${url.origin}/*` : null;
    } catch {
      return null;
    }
  }
  function validateEnhanceConfiguration(value) {
    const root = object(value);
    if (!root || root.format !== ENHANCE_CONFIGURATION_FORMAT)
      return { ok: false, diagnostic: t("unknownConfigurationFormat") };
    const version = Number(root.version);
    if (!Number.isInteger(version) || version < 1)
      return { ok: false, diagnostic: t("invalidConfigurationVersion") };
    if (version > ENHANCE_CONFIGURATION_VERSION)
      return { ok: false, diagnostic: `${t("newerExtensionRequired")} (v${version})`, unsupportedVersion: version };
    const player = object(root.player) ?? {};
    const captions = object(player.captions) ?? {};
    const screenshots = object(root.screenshots) ?? {};
    const sponsorBlock = object(root.sponsorBlock) ?? {};
    const bridge = object(root.bridge) ?? {};
    if (bridge.version !== 1 || bridge.detailEncoding !== "json-string")
      return { ok: false, diagnostic: t("unsupportedBridge") };
    const eventInput = object(bridge.events) ?? {};
    if (Object.entries(ENHANCE_BRIDGE_EVENTS).some(([key, name]) => eventInput[key] !== name))
      return { ok: false, diagnostic: t("incompatibleBridgeEvents") };
    return { ok: true, value: {
      format: ENHANCE_CONFIGURATION_FORMAT,
      version: 1,
      enabled: root.enabled === true,
      player: {
        replaceControls: player.replaceControls === true,
        language: text(player.language, "en", 16),
        preferredQuality: typeof player.preferredQuality === "string" && QUALITY.test(player.preferredQuality) ? player.preferredQuality : "auto",
        defaultPlaybackRate: finite(player.defaultPlaybackRate, 1, 0.25, 4),
        keyboardSeekSeconds: finite(player.keyboardSeekSeconds, 5, 1, 120),
        frameStepFps: finite(player.frameStepFps, 30, 1, 240),
        autoFullscreenLandscape: player.autoFullscreenLandscape === true,
        captions: {
          enabledByDefault: captions.enabledByDefault === true,
          language: text(captions.language, text(player.language, "en", 16), 16),
          availableLanguages: captionLanguages(captions.availableLanguages),
          style: style(captions.style)
        }
      },
      screenshots: {
        format: format(screenshots.format),
        jpegQuality: finite(screenshots.jpegQuality, 0.92, 0.1, 1),
        filenameTemplate: text(screenshots.filenameTemplate, "{channel}_{title}_{timestamp_ms}", 300),
        templateFields: Array.isArray(screenshots.templateFields) ? screenshots.templateFields.filter((item) => typeof item === "string").slice(0, 20) : []
      },
      sponsorBlock: {
        enabled: sponsorBlock.enabled === true,
        categories: Array.isArray(sponsorBlock.categories) ? sponsorBlock.categories.filter((item) => typeof item === "string" && item.length <= 40).slice(0, 20) : []
      },
      bridge: { version: 1, detailEncoding: "json-string", events: ENHANCE_BRIDGE_EVENTS }
    } };
  }
  function validateEnhanceContext(value, legacyFallback = "default") {
    const root = object(value), video = object(root?.video), playback = object(root?.playback), captions = object(playback?.captions), screenshot = object(root?.screenshot);
    if (root?.version !== 1 || root.active !== true || !video || !VIDEO_ID2.test(String(video.id ?? "")) || !playback || !captions || !screenshot)
      return null;
    const chapters = Array.isArray(playback.chapters) ? playback.chapters.flatMap((item) => {
      const chapter = object(item), start = Number(chapter?.start);
      return chapter && typeof chapter.title === "string" && Number.isFinite(start) && start >= 0 ? [{ title: chapter.title.slice(0, 200), start }] : [];
    }).slice(0, 500) : [];
    const sponsorBlockSegments = Array.isArray(playback.sponsorBlockSegments) ? playback.sponsorBlockSegments.flatMap((item) => {
      const segment = object(item), bounds = segment?.segment;
      const start = Number(bounds?.[0]), end = Number(bounds?.[1]);
      return segment && Array.isArray(bounds) && Number.isFinite(start) && Number.isFinite(end) && start >= 0 && end > start && typeof segment.category === "string" ? [{ category: segment.category.slice(0, 40), actionType: text(segment.actionType, "skip", 40), segment: [start, end], UUID: text(segment.UUID, `${start}-${end}`, 200) }] : [];
    }).slice(0, 500) : [];
    return {
      version: 1,
      active: true,
      video: {
        id: String(video.id),
        title: text(video.title, "YouTube", 300),
        channelId: text(video.channelId, "", 200),
        channelTitle: text(video.channelTitle, "YouTube", 200),
        duration: finite(video.duration, 0, 0, 86400 * 30),
        contentType: normalizeContentType(video.contentType, legacyFallback)
      },
      playback: {
        rate: finite(playback.rate, 1, 0.25, 4),
        keyboardSeekSeconds: finite(playback.keyboardSeekSeconds, 5, 1, 120),
        frameStepFps: finite(playback.frameStepFps, 30, 1, 240),
        keyboardShortcuts: resolveShortcutBindings(playback.keyboardShortcuts),
        transportLocked: playback.transportLocked === true,
        captions: { enabledByDefault: captions.enabledByDefault === true, language: text(captions.language, "en", 16), style: style(captions.style) },
        chapters,
        sponsorBlockSegments
      },
      screenshot: { format: format(screenshot.format), quality: finite(screenshot.quality, 0.92, 0.1, 1), filenameTemplate: text(screenshot.filenameTemplate, "{channel}_{title}_{timestamp_ms}", 300) }
    };
  }
  function parseBridgeDetail(event, maxLength = MAX_CONTEXT_DETAIL_LENGTH) {
    if (typeof event.detail !== "string" || event.detail.length > maxLength)
      return null;
    try {
      return JSON.parse(event.detail);
    } catch {
      return null;
    }
  }
  function validateScreenshotRequest(value) {
    const root = object(value), video = object(root?.video), screenshot = object(root?.screenshot);
    if (root?.version !== 1 || !video || !VIDEO_ID2.test(String(video.id ?? "")) || !screenshot)
      return null;
    return {
      version: 1,
      video: { id: String(video.id), title: text(video.title, "YouTube", 300), channelTitle: text(video.channelTitle, "YouTube", 200), seconds: finite(video.seconds, 0, 0, 86400 * 30) },
      screenshot: { format: format(screenshot.format), quality: finite(screenshot.quality, 0.92, 0.1, 1), filenameTemplate: text(screenshot.filenameTemplate, "{channel}_{title}_{timestamp_ms}", 300) }
    };
  }
  function claimScreenshotRequest(event, pageUrl, instanceUrl) {
    if (!configuredPageMatches(pageUrl, instanceUrl))
      return null;
    const request = validateScreenshotRequest(parseBridgeDetail(event, MAX_SCREENSHOT_DETAIL_LENGTH));
    if (!request)
      return null;
    event.preventDefault();
    return request;
  }
  function frameStepSeconds(fps) {
    return 1 / finite(fps, 30, 1, 240);
  }

  // src/instances.ts
  var PAIRED_INSTANCES_KEY = "ytzePairedInstances";
  var EMBEDDED_CONFIGURATION_ID = "ytzero-enhance-configuration";
  function parseEmbeddedConfigurationText(value) {
    if (value.length > MAX_CONFIGURATION_DETAIL_LENGTH)
      return { ok: false, diagnostic: t("configurationPayloadTooLarge") };
    try {
      return validateEnhanceConfiguration(JSON.parse(value));
    } catch {
      return { ok: false, diagnostic: t("embeddedSettingsReadFailed") };
    }
  }
  function inferInstanceUrl(pageUrl, applicationResourceUrl = "") {
    try {
      const url = new URL(pageUrl);
      if (!/^https?:$/.test(url.protocol))
        return null;
      if (applicationResourceUrl) {
        const resource = new URL(applicationResourceUrl, url);
        if (resource.origin === url.origin && /^https?:$/.test(resource.protocol)) {
          const resourcePath = resource.pathname.match(/^(.*)\/(?:manifest\.webmanifest|favicon\.svg)$/);
          if (resourcePath) {
            url.pathname = resourcePath[1] || "/";
            url.search = "";
            url.hash = "";
            return url.toString().replace(/\/$/, "");
          }
        }
      }
      const pathname = url.pathname.replace(/\/+$/, "");
      const route = pathname.match(/^(.*)\/(?:search|discovery|shorts|live|watch|channel|subscriptions|playlists|playlist|followed-playlists|watchlist|downloads|liked|history|archive|cleanup|insights|settings|import|restore)(?:\/.*)?$/);
      url.pathname = route ? route[1] || "/" : pathname || "/";
      url.search = "";
      url.hash = "";
      return url.toString().replace(/\/$/, "");
    } catch {
      return null;
    }
  }
  function friendlyInstanceName(pageTitle, instanceUrl) {
    const cleaned = pageTitle.replace(/\s*[—|·-]\s*YT Zero.*$/i, "").trim();
    if (cleaned && !/^(watch|ustawienia|settings)$/i.test(cleaned))
      return cleaned.slice(0, 60);
    try {
      return new URL(instanceUrl).hostname;
    } catch {
      return "YT Zero";
    }
  }
  function pairedInstanceForPage(instances, pageUrl) {
    return Object.values(instances).filter((instance) => configuredPageMatches(pageUrl, instance.url)).sort((a, b) => b.url.length - a.url.length)[0] ?? null;
  }
  function defaultPairedInstance(instances, defaultUrl) {
    return instances[defaultUrl] ?? Object.values(instances).sort((a, b) => a.pairedAt - b.pairedAt)[0] ?? null;
  }
  function instanceSettingsUrl(instanceUrl) {
    const url = new URL(instanceUrl);
    url.pathname = `${url.pathname.replace(/\/$/, "")}/settings`.replace(/\/{2,}/g, "/");
    url.search = "?tab=display";
    url.hash = "";
    return url.toString();
  }

  // src/webext.ts
  var ext = globalThis.browser ?? globalThis.chrome;
  var isFirefox = typeof globalThis.browser !== "undefined";
  var INVALIDATED_MESSAGE = "Extension context invalidated";
  var invalidationListeners = new Set;
  var contextInvalidated = false;
  function isInvalidation(error) {
    return String(error?.message ?? error).toLowerCase().includes("extension context invalidated");
  }
  function markContextInvalidated() {
    if (contextInvalidated)
      return;
    contextInvalidated = true;
    for (const listener of invalidationListeners) {
      try {
        listener();
      } catch {}
    }
    invalidationListeners.clear();
  }
  function onExtensionContextInvalidated(listener) {
    if (contextInvalidated) {
      queueMicrotask(listener);
      return () => {};
    }
    invalidationListeners.add(listener);
    return () => invalidationListeners.delete(listener);
  }
  function extensionContextAvailable() {
    try {
      const available = Boolean(ext?.runtime?.id);
      if (!available)
        markContextInvalidated();
      return available;
    } catch {
      markContextInvalidated();
      return false;
    }
  }
  function callApi(owner, method, ...args) {
    return new Promise((resolve, reject) => {
      try {
        if (!extensionContextAvailable() || !owner || typeof owner[method] !== "function") {
          markContextInvalidated();
          reject(new Error(INVALIDATED_MESSAGE));
          return;
        }
        if (isFirefox) {
          Promise.resolve(owner[method](...args)).then(resolve, (error) => {
            if (isInvalidation(error))
              markContextInvalidated();
            reject(error);
          });
          return;
        }
        owner[method](...args, (result) => {
          try {
            const error = ext?.runtime?.lastError;
            if (error) {
              const runtimeError = new Error(error.message);
              if (isInvalidation(runtimeError))
                markContextInvalidated();
              reject(runtimeError);
            } else
              resolve(result);
          } catch (error) {
            if (isInvalidation(error))
              markContextInvalidated();
            reject(error);
          }
        });
      } catch (error) {
        if (isInvalidation(error))
          markContextInvalidated();
        reject(error);
      }
    });
  }
  function addApiListener(event, listener) {
    try {
      if (!extensionContextAvailable() || typeof event?.addListener !== "function")
        return false;
      event.addListener(listener);
      return true;
    } catch {
      return false;
    }
  }

  // src/popup.ts
  localizeDocument();
  var onboarding = document.querySelector("#onboarding");
  var connected = document.querySelector("#connected");
  var stateDot = document.querySelector("#state");
  var subtitle = document.querySelector("#subtitle");
  var message = document.querySelector("#message");
  var onboardingMessage = document.querySelector("#onboarding-message");
  var redirect = document.querySelector('input[name="redirectEnabled"]');
  var enhance = document.querySelector('input[name="enhancePlayer"]');
  var redirectCurrent = document.querySelector("#redirect-current");
  var defaultInstance = null;
  var activeRedirect = null;
  var pairingCandidate = null;
  var pairingCandidateError = null;
  function instanceAddress(value) {
    try {
      const url = new URL(value);
      return `${url.host}${url.pathname.replace(/\/$/, "")}`;
    } catch {
      return value;
    }
  }
  async function sourceChannelId(tabId, tabUrl) {
    if (!/^https:\/\/www\.youtube\.com\/(?:@|c\/|user\/)/i.test(tabUrl))
      return null;
    const results = await callApi(ext.scripting, "executeScript", {
      target: { tabId },
      func: () => document.querySelector('meta[itemprop="channelId"]')?.content ?? null
    }).catch(() => []);
    const value = results?.[0]?.result;
    return typeof value === "string" ? value : null;
  }
  async function loadActiveRedirect() {
    activeRedirect = null;
    redirectCurrent.hidden = true;
    if (!defaultInstance)
      return;
    const tabs = await callApi(ext.tabs, "query", { active: true, currentWindow: true }).catch(() => []);
    const tab = tabs[0];
    if (tab?.id == null || !tab.url)
      return;
    const channelId = await sourceChannelId(tab.id, tab.url);
    const destination = localContentUrl(tab.url, defaultInstance.url, channelId);
    if (!destination)
      return;
    activeRedirect = { tabId: tab.id, url: destination };
    redirectCurrent.textContent = `${t("redirectTo")} ${instanceAddress(defaultInstance.url)}`;
    redirectCurrent.title = destination;
    redirectCurrent.hidden = false;
  }
  async function load() {
    const [stored, registry] = await Promise.all([
      callApi(ext.storage.sync, "get", DEFAULT_SETTINGS),
      callApi(ext.runtime, "sendMessage", { type: "ytze-list-instances" }).catch(() => ({ instances: [] }))
    ]);
    const settings = normalizeSettings(stored);
    defaultInstance = registry.instances?.find((item) => item.url === registry.defaultUrl) ?? registry.instance ?? null;
    const paired = Boolean(defaultInstance);
    onboarding.hidden = paired;
    connected.hidden = !paired;
    stateDot.classList.toggle("on", paired && (settings.redirectEnabled || settings.enhancePlayer && !defaultInstance.blocked && defaultInstance.configuration.enabled));
    subtitle.textContent = paired ? defaultInstance.name : t("connectYtZero");
    if (!paired)
      return;
    document.querySelector("#instance-name").textContent = defaultInstance.name;
    document.querySelector("#instance-url").textContent = defaultInstance.url;
    const sync = document.querySelector("#sync-status");
    sync.textContent = defaultInstance.diagnostic || (defaultInstance.configuration.enabled ? t("settingsSynced") : t("enhancementsDisabled"));
    sync.classList.toggle("off", !defaultInstance.configuration.enabled || Boolean(defaultInstance.diagnostic));
    redirect.checked = settings.redirectEnabled;
    enhance.checked = settings.enhancePlayer;
    await loadActiveRedirect();
  }
  async function inspectActiveTabForPairing() {
    const tabs = await callApi(ext.tabs, "query", { active: true, currentWindow: true });
    const tab = tabs[0];
    if (tab?.id == null || !tab.url)
      throw new Error(t("openPageFirst"));
    const results = await callApi(ext.scripting, "executeScript", {
      target: { tabId: tab.id },
      func: () => ({
        configuration: document.body?.querySelector("#ytzero-enhance-configuration")?.textContent ?? "",
        appName: document.querySelector('meta[name="application-name"]')?.content ?? "",
        manifestUrl: document.querySelector('link[rel="manifest"]')?.href ?? ""
      })
    });
    const raw = results?.[0]?.result?.configuration;
    if (!raw)
      throw new Error(t("settingsNotReady"));
    const validation = parseEmbeddedConfigurationText(raw);
    if (!validation.ok)
      throw new Error(validation.diagnostic);
    const instanceUrl = inferInstanceUrl(tab.url, results?.[0]?.result?.manifestUrl);
    if (!instanceUrl)
      throw new Error(t("openSpecificPage"));
    return {
      tabId: tab.id,
      instanceUrl,
      name: friendlyInstanceName(results?.[0]?.result?.appName || "", instanceUrl),
      configuration: validation.value,
      permission: hostPermissionPattern(instanceUrl)
    };
  }
  async function finishPairing(candidate, permissionRequest, button, output) {
    try {
      if (!await permissionRequest)
        throw new Error(t("permissionNeeded"));
      const response = await callApi(ext.runtime, "sendMessage", {
        type: "ytze-pair-instance",
        url: candidate.instanceUrl,
        name: candidate.name,
        configuration: candidate.configuration
      });
      if (!response?.ok)
        throw new Error(response?.error || t("pairFailed"));
      output.textContent = t("pairedReloading");
      await callApi(ext.tabs, "reload", candidate.tabId);
      await load();
    } catch (error) {
      output.textContent = error?.message || String(error);
      output.className = "error";
    } finally {
      button.disabled = false;
    }
  }
  function beginPairingFromUserGesture(button, output) {
    button.disabled = true;
    output.className = "";
    output.textContent = t("findingSettings");
    if (!pairingCandidate) {
      output.textContent = pairingCandidateError?.message || t("settingsNotReady");
      output.className = "error";
      button.disabled = false;
      return;
    }
    const permissionRequest = pairingCandidate.permission && ext.permissions ? callApi(ext.permissions, "request", { origins: [pairingCandidate.permission] }) : Promise.resolve(true);
    finishPairing(pairingCandidate, permissionRequest, button, output);
  }
  for (const id of ["pair-first", "pair-another"]) {
    const button = document.querySelector(`#${id}`);
    button.disabled = true;
    button.addEventListener("click", () => beginPairingFromUserGesture(button, id === "pair-first" ? onboardingMessage : message));
  }
  inspectActiveTabForPairing().then((candidate) => {
    pairingCandidate = candidate;
  }).catch((error) => {
    pairingCandidateError = error instanceof Error ? error : new Error(String(error));
  }).finally(() => {
    for (const id of ["pair-first", "pair-another"])
      document.querySelector(`#${id}`).disabled = false;
  });
  async function saveToggle(key, value) {
    await callApi(ext.storage.sync, "set", { [key]: value });
    message.textContent = t("saved");
    message.className = "";
    window.setTimeout(() => {
      message.textContent = "";
    }, 1200);
    load();
  }
  redirect.addEventListener("change", () => void saveToggle("redirectEnabled", redirect.checked));
  enhance.addEventListener("change", () => void saveToggle("enhancePlayer", enhance.checked));
  redirectCurrent.addEventListener("click", () => {
    if (activeRedirect)
      callApi(ext.tabs, "update", activeRedirect.tabId, { url: activeRedirect.url });
    window.close();
  });
  document.querySelector("#capture")?.addEventListener("click", async () => {
    message.textContent = t("capturing");
    const response = await callApi(ext.runtime, "sendMessage", { type: "ytze-trigger-active-capture" }).catch((error) => ({ ok: false, error: error.message }));
    message.textContent = response?.ok ? t("frameSaved") : response?.error || t("noActivePlayer");
    message.className = response?.ok ? "" : "error";
  });
  document.querySelector("#open-instance")?.addEventListener("click", () => {
    if (defaultInstance)
      callApi(ext.tabs, "create", { url: defaultInstance.url });
    window.close();
  });
  document.querySelector("#options")?.addEventListener("click", () => {
    ext.runtime.openOptionsPage();
    window.close();
  });
  load();
  addApiListener(ext?.storage?.onChanged, () => void load());
})();
