import { expect, test } from "bun:test";

const css = await Bun.file(new URL("../src/player.css", import.meta.url)).text();
const content = await Bun.file(new URL("../src/content.ts", import.meta.url)).text();
const background = await Bun.file(new URL("../src/background.ts", import.meta.url)).text();
const shortcuts = await Bun.file(new URL("../src/shortcuts.ts", import.meta.url)).text();

test("replacement CSS structurally removes native player layers", () => {
  const structuralRule = css.slice(
    css.indexOf("html.ytze-replace-controls .html5-video-player > :not("),
    css.indexOf(") {", css.indexOf("html.ytze-replace-controls .html5-video-player > :not(")),
  );
  expect(structuralRule).toContain("video,");
  expect(structuralRule).toContain(".html5-video-container,");
  expect(structuralRule).toContain("#ytp-caption-window-container,");
  expect(structuralRule).toContain(".ytp-spinner,");
  expect(structuralRule).toContain('[class*="ytp-ad-"],');
  expect(structuralRule).not.toMatch(/\)\s+:not\(/);
});

test("player CSS is inserted only after the parent tab is authorized as paired", () => {
  expect(background).toContain('message?.type === "ytze-authorize-player-frame"');
  expect(background).toContain('ext.scripting, "insertCSS"');
  expect(background.indexOf("await pairedPlayerFrame(message, sender)")).toBeLessThan(background.indexOf('ext.scripting, "insertCSS"'));
  expect(content.indexOf('type: "ytze-authorize-player-frame"')).toBeLessThan(content.indexOf("playerController = enhanceYouTubePlayer(video)"));
});

test("player startup retries transient frame authorization failures", () => {
  expect(content).toContain("const retryDelays = [0, 100, 250, 500, 1_000, 2_000]");
  expect(content).toContain("if (authorization?.authorized) return authorization");
  expect(content).toContain("token !== playerBootToken");
});

test("replacement CSS covers both classic and experimental embedded controls", () => {
  expect(css).toContain(".ytp-chrome-bottom");
  expect(css).toContain(".ytwPlayerMiddleControlsHost");
  expect(css).toContain("[class*=\"ytwPlayer\"][class*=\"Controls\"]");
  expect(css).toContain(".player-controls-bottom");
  expect(css).toContain("player-fullscreen-action-menu");
  expect(css).toContain("yt-sheet-view-model");
});

test("custom player controls do not create native title tooltips", () => {
  expect(content).not.toMatch(/\.title\s*=/);
  expect(content).toContain('iconButton("captions", t("captionsShortcut")');
  expect(content).toContain('liveEdgeElement.setAttribute("aria-label"');
});

test("the custom control bar omits cinema and capture buttons without removing their commands", () => {
  expect(content).not.toContain('class="cinema"');
  expect(content).not.toContain('class="capture"');
  expect(content).toContain('action === "screenshot"');
  expect(content).toContain('command.command === "capture-frame"');
  expect(content).toContain('type: "ytze-player-event"');
  expect(content).toContain('emitPlayerEvent("captions-toggle-request"');
  expect(content).toContain("ENHANCE_PLAYER_EVENTS.captionsToggleRequest");
});

test("configured screenshot shortcuts retain the privileged flow and Firefox command fallback", () => {
  expect(content).toContain('action === "screenshot"');
  expect(content).toContain("void requestCapture().then");
  expect(content).toContain('if (isFirefox)');
  expect(content).toContain('type: "ytze-capture-frame"');
});

test("the iframe has one configurable shortcut listener without the legacy fixed lookup", () => {
  const handler = content.slice(content.indexOf("const onKey ="), content.indexOf("const onSurfaceClick"));
  expect(handler).toContain("matchingShortcutAction(event, shortcutBindings)");
  expect(handler).toContain("PARENT_OWNED_SHORTCUT_ACTIONS.has(action)");
  expect(handler).toContain("shortcutOperationBlocked(action");
  expect(handler).not.toContain("event.key.toLowerCase()");
  expect(handler).not.toContain("const actions: Record<string, string>");
  expect(handler).not.toContain('"cinema-mode"');
  expect(handler).not.toContain('"seek-back"');
  expect(handler).not.toContain('"toggle-muted"');
  expect(handler).not.toContain("toggleMiniplayer");
  expect(shortcuts).not.toContain("toggleMiniplayer");
  expect(`${handler}\n${shortcuts}`).not.toMatch(/spherical|sphereVideo|video360/i);
});

test("rapid speed steps use owned state and emit the computed value without rereading the player", () => {
  const handler = content.slice(content.indexOf("const onKey ="), content.indexOf("const onKeyUp ="));
  expect(handler).toContain("advanceOwnedPlaybackRate(ownedRate");
  expect(handler).toContain("emitShortcut(action, event, nextRate)");
  expect(handler).not.toContain("stepShortcutPlaybackRate(video.playbackRate");
  expect(handler).not.toContain("emitShortcut(action, event, video.playbackRate)");
  expect(content).toContain("ownedRate.reset(Number(payload.rate))");
  expect(content).toContain("effectiveRate: () => ownedRate.value");
});

test("KeyI and the command toggle only native picture-in-picture", () => {
  expect(shortcuts).toContain('"togglePictureInPicture"');
  expect(content).toContain('action === "togglePictureInPicture"');
  expect(content).toContain("video.requestPictureInPicture()");
  expect(content).toContain("document.exitPictureInPicture()");
  expect(content).toContain('command.command === "toggle-picture-in-picture"');
  expect(content).not.toContain("webkitSetPresentationMode");
  expect(content).not.toContain("webkitSupportsPresentationMode");
});

test("double-click toggles fullscreen across the iframe surface", () => {
  const handler = content.slice(content.indexOf("const onSurfaceDoubleClick"), content.indexOf("play.addEventListener"));
  expect(handler).toContain('target.closest("#ytze-player-controls")');
  expect(handler).not.toContain('target.closest(".html5-video-player")');
  expect(handler).toContain("toggleFullscreen()");
  expect(content).toContain("safariVideo.webkitExitFullscreen?.()");
});

test("caption control opens a language menu and applies the selection in YouTube", () => {
  expect(content).toContain('create("div", "caption-menu")');
  expect(content).toContain('create("button", "caption-switch")');
  expect(content).toContain("availableLanguages");
  expect(content).toContain('type: "ytze-set-youtube-captions"');
  expect(content).toContain("setCaptionMenuOpen(!captionMenuOpen)");
  expect(background).toContain('world: "MAIN"');
  expect(background).toContain("operateYouTubeCaptions");
});

test("production content avoids innerHTML assignments rejected by AMO", () => {
  expect(content).not.toContain(".innerHTML");
  expect(content).toContain("button.replaceChildren");
});

test("extension teardown restores iframe parameters owned by the bridge", () => {
  expect(content).toContain("ownedIframeParameters");
  expect(content).toContain("restoreEmbeddedParameters()");
  expect(content).toContain("onExtensionContextInvalidated(() => shutdown(true))");
  expect(content).toContain("window.setInterval(extensionContextAvailable, 2_000)");
  expect(content).toContain("url.searchParams.get(key) !== value.applied");
  expect(content).toContain('setAttribute("data-extension-status", "inactive")');
});

test("player icons are created as SVG namespace elements", () => {
  expect(content).toContain('document.createElementNS(SVG_NAMESPACE, "svg")');
  expect(content).toContain('document.createElementNS(SVG_NAMESPACE, tag)');
  expect(content).not.toContain("new DOMParser()");
});

test("caption switch tracks the result of player operations instead of hidden YouTube controls", () => {
  expect(content).toContain("captionsEnabled = response.enabled");
  expect(content).toContain("const captionsAreEnabled = () => captionsEnabled");
  expect(content).toContain("setYouTubeCaptions(!captionsAreEnabled())");
  expect(content).toContain("captionOperationQueue.then(operation, operation)");
  expect(content).toContain("scheduleCaptionDefaults(800)");
  expect(content).not.toContain("window.setTimeout(() => void setYouTubeCaptions(context.playback.captions.enabledByDefault");
});

test("live and short-form players receive purpose-built controls", () => {
  expect(content).toContain('classList.toggle("mode-live"');
  expect(content).toContain('classList.toggle("mode-shorts"');
  expect(content).toContain('create("button", "live-edge")');
  expect(content).toContain("liveSeekRange()");
  expect(content).toContain('shortcutOperationBlocked(action, playerMode === "live"');
  expect(content).toContain(":host(.mode-shorts) .controls");
  expect(content).toContain(":host(.mode-shorts) .volume");
  expect(content).toContain(":host(.mode-live) .time");
  expect(background).toContain('"ytze-authorize-player-frame"');
  expect(background).toContain("embeddedPlayerModeForPage");
  expect(background).toContain("getVideoData?.()?.isLive");
  expect(content).toContain('"shorts-prev"');
  expect(content).toContain('"shorts-next"');
  expect(content).toContain('chord === "ArrowUp" ? "shorts-prev" : "shorts-next"');
  expect(content).toContain("setContentType(context.video.contentType");
  expect(content).toContain("contentTypeAuthoritative");
  expect(content).toContain("set-playback-rate is unavailable for livestreams");
  expect(content).toContain("env(safe-area-inset-bottom");
  expect(content).toContain(".live-edge.active .live-dot { animation: none; }");
  expect(content).toContain('if (playerMode !== "shorts") showControls()');
  expect(content).toContain('if (requestedPlayerMode === "shorts")');
  expect(content).toContain(":host(.mode-shorts):not(.visible) .big-play");
});

test("preview players expose only seeking and pointer-based mute controls", () => {
  expect(content).toContain('classList.toggle("mode-preview", mode === "preview")');
  expect(content).toContain('const previewEmbed = isPreviewEmbedUrl(location.href)');
  expect(content).toContain('previewEmbed\n        ? "preview"');
  expect(content).toContain('mute.addEventListener("pointerdown"');
  expect(content).toContain('if (playerMode === "preview") {\n      event.preventDefault();');
  expect(content).toContain('const onSurfaceClick = (event: MouseEvent) => {\n    if (playerMode === "preview") return;');
  expect(content).toContain('const onSurfaceDoubleClick = (event: MouseEvent) => {\n    if (playerMode === "preview") return;');
  expect(content).toContain('if (playerMode !== "preview") showProgressTooltip(event.clientX)');
  expect(content).toContain('video.muted || video.volume === 0 ? PLAYER_ICONS.muted : PLAYER_ICONS.volume');
});

test("preview controls match the VideoCard hover layout", () => {
  expect(content).toContain(":host(.mode-preview) .controls");
  expect(content).toContain("padding: 18px 8px 7px");
  expect(content).toContain("gap: 8px");
  expect(content).toContain("border-radius: 999px");
  expect(content).toContain("min-width: 38px");
  expect(content).toContain("width: 38px");
  expect(content).toContain("min-height: 34px");
  expect(content).toContain("height: 34px");
  for (const selector of [".play", ".caption-menu-wrap", ".pip", ".fullscreen"]) {
    expect(content).toContain(`:host(.mode-preview) ${selector}`);
  }
});
